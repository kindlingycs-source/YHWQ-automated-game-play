package featurecat.lizzie.analysis;

import featurecat.lizzie.Lizzie;
import featurecat.lizzie.multi.MultiRoomClient;
import featurecat.lizzie.multi.RoomMove;
import featurecat.lizzie.multi.RoomSeat;
import featurecat.lizzie.multi.RoomState;
import featurecat.lizzie.rules.Board;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/**
 * 多人约战的 provider 侧引擎适配器。
 *
 * <p>只接管“我提供的 AI 座位”用到的 Leelaz；数字 ID 通道复用 Leelaz.sendPairCommand，
 * 不碰原生命令队列。和本地联棋（PairGo）完全独立。
 */
public final class MultiEngine {
  private static volatile MultiEngine SESSION;
  private static final boolean DEBUG = "true".equals(System.getProperty("multi.debug", ""));

  private static void dbg(String s) {
    if (DEBUG) System.out.println("[multi-engine] " + s);
  }

  public static boolean handleLine(Leelaz engine, String line) {
    MultiEngine s = SESSION;
    return s != null && s.consume(engine, line);
  }

  public static void sync(RoomState room, int myPlayerId, MultiRoomClient client) {
    if (client == null || myPlayerId <= 0 || room == null) return;
    MultiEngine s = SESSION;
    if (s == null || s.client != client || s.myPlayerId != myPlayerId) {
      if (s != null) s.close();
      s = new MultiEngine(client, myPlayerId);
      SESSION = s;
    }
    s.update(room);
  }

  public static void closeSession() {
    MultiEngine s = SESSION;
    SESSION = null;
    if (s != null) s.close();
  }

  private interface Reply {
    void done(boolean ok, String value);
  }

  private static final class Req {
    final String cmd;
    final boolean streaming;
    final Reply reply;
    int id;

    Req(String cmd, boolean streaming, Reply reply) {
      this.cmd = cmd;
      this.streaming = streaming;
      this.reply = reply;
    }
  }

  private static final class Channel {
    final Leelaz engine;
    final ArrayDeque<Req> queue = new ArrayDeque<Req>();
    volatile Req pending;
    volatile boolean streaming;
    volatile boolean genmovePending;
    volatile boolean moveApplied;
    volatile boolean armed;
    volatile String bestMove;
    volatile double winrate = -1;
    int nextId = 1;

    Channel(Leelaz engine) {
      this.engine = engine;
    }
  }

  private static final class Binding {
    final String seatId;
    final boolean black;
    final int engineIndex;
    Leelaz engine;
    Channel channel;
    boolean checking;
    boolean checked;
    boolean ready;
    long checkDeadline;
    long checkStarted;
    boolean moveInFlight;
    boolean moveResign;
    long moveStarted;
    int sentMoves;
    int resignConsec;

    Binding(String seatId, boolean black, int engineIndex) {
      this.seatId = seatId;
      this.black = black;
      this.engineIndex = engineIndex;
    }
  }

  private final MultiRoomClient client;
  private final int myPlayerId;
  private final Map<Leelaz, Channel> channels = new HashMap<Leelaz, Channel>();
  private final List<Binding> bindings = new ArrayList<Binding>();
  private final ArrayDeque<Binding> startQueue = new ArrayDeque<Binding>();
  private final Timer ticker;
  private RoomState room;
  private Binding starting;
  private long startingSince;
  private int startAttempts;
  private long retryAt;
  private boolean gameStarted;
  private boolean closed;

  private MultiEngine(MultiRoomClient client, int myPlayerId) {
    this.client = client;
    this.myPlayerId = myPlayerId;
    ticker =
        new Timer(
            100,
            e -> {
              tick();
            });
    ticker.start();
  }

  private void update(RoomState st) {
    if (closed) return;
    if (!SwingUtilities.isEventDispatchThread()) {
      SwingUtilities.invokeLater(() -> update(st));
      return;
    }
    room = st;
    // 1) 同步我自己提供的 AI 座位
    for (RoomSeat s : st.seats) {
      if (!s.isAi() || s.playerId != myPlayerId) continue;
      Binding b = find(s.id);
      if (b == null || b.engineIndex != s.engineId) {
        if (b != null) removeBinding(b);
        b = new Binding(s.id, s.black, s.engineId);
        bindings.add(b);
        ensureReady(b);
      } else if (!b.checked && !b.checking) {
        ensureReady(b);
      }
    }
    // 2) 清掉已经不属于我的座位
    for (Binding b : new ArrayList<Binding>(bindings)) {
      RoomSeat s = st.seat(b.seatId);
      if (s == null || !s.isAi() || s.playerId != myPlayerId) removeBinding(b);
    }
    // 3) 对局开始：重置所有 AI 引擎的盘面，并把已有棋谱补上
    if (RoomState.PLAYING.equals(st.phase) && !gameStarted) {
      gameStarted = true;
      resetBoards();
    }
    if (gameStarted) {
      syncMoves();
      maybeRequestMove();
    }
  }

  private Binding find(String seatId) {
    for (Binding b : bindings) if (b.seatId.equals(seatId)) return b;
    return null;
  }

  private void removeBinding(Binding b) {
    bindings.remove(b);
    if (b.engine != null) {
      try {
        b.engine.sendPairCommand(0, "stop");
      } catch (Exception e) {
        // ignore
      }
      channels.remove(b.engine);
    }
  }

  // ------------------------------------------------------------------ 启动 / 自检

  private void ensureReady(Binding b) {
    if (b.engine == null) {
      if (Lizzie.engineManager == null
          || Lizzie.engineManager.engineList == null
          || b.engineIndex < 0
          || b.engineIndex >= Lizzie.engineManager.engineList.size()) {
        failSelfCheck(b, "引擎索引无效");
        return;
      }
      b.engine = Lizzie.engineManager.engineList.get(b.engineIndex);
      b.channel = new Channel(b.engine);
      channels.put(b.engine, b.channel);
    }
    dbg("ensure " + b.seatId + " idx=" + b.engineIndex + " loaded=" + b.engine.isLoaded()
        + " started=" + b.engine.isStarted() + " checkingName=" + b.engine.isCheckingName);
    if (b.engine.isLoaded() && !b.engine.isCheckingName && !b.engine.isCheckingVersion) {
      startSelfCheck(b);
      return;
    }
    if (b.engine.isStarted() && !b.engine.isDownWithError) return; // 等 tick
    if (!startQueue.contains(b) && starting != b) startQueue.addLast(b);
  }

  private void tick() {
    if (closed) return;
    long now = System.nanoTime();
    // 等待加载/等待开始自检的座位
    for (Binding b : new ArrayList<Binding>(bindings)) {
      if (b.checked || b.checking || b.engine == null) continue;
      if (b.engine.isLoaded() && !b.engine.isCheckingName && !b.engine.isCheckingVersion) {
        startSelfCheck(b);
      } else if (!b.engine.isStarted()
          && !startQueue.contains(b)
          && starting != b
          && !b.engine.isDownWithError) {
        startQueue.addLast(b);
      }
    }
    // 自检超时
    for (Binding b : new ArrayList<Binding>(bindings)) {
      if (b.checking && b.checkDeadline > 0 && now > b.checkDeadline) {
        failSelfCheck(b, "自检超时");
      }
      if (b.moveInFlight && (now - b.moveStarted) / 1000000L > 90000L) {
        b.moveInFlight = false;
        if (b.channel != null) {
          b.channel.pending = null;
          b.channel.streaming = false;
          b.channel.genmovePending = false;
        }
        client.sendEngineDown(b.seatId);
      }
    }
    tickStartup(now);
  }

  private void tickStartup(long now) {
    if (starting != null) {
      dbg("startup wait " + starting.seatId + " loaded=" + starting.engine.isLoaded()
          + " checkingName=" + starting.engine.isCheckingName + " checkingVersion="
          + starting.engine.isCheckingVersion + " down=" + starting.engine.isDownWithError);
      if (starting.engine.isLoaded()
          && !starting.engine.isCheckingName
          && !starting.engine.isCheckingVersion) {
        Binding b = starting;
        starting = null;
        startAttempts = 0;
        startSelfCheck(b);
        return;
      }
      if (starting.engine.isDownWithError) {
        if (startAttempts >= 1 || now < retryAt) {
          if (now >= retryAt && startAttempts >= 1) failSelfCheck(starting, "引擎启动失败");
          return;
        }
        startAttempts++;
        retryAt = now + 3000000000L;
        try {
          starting.engine.startEngine(starting.engineIndex);
          startingSince = now;
        } catch (Exception e) {
          failSelfCheck(starting, "启动失败: " + e.getMessage());
        }
        return;
      }
      if ((now - startingSince) / 1000000L > 120000L) {
        failSelfCheck(starting, "启动超时");
        starting = null;
      }
      return;
    }
    if (startQueue.isEmpty()) return;
    Binding b = startQueue.pollFirst();
    if (b.engine == null) {
      ensureReady(b);
      return;
    }
    if (b.engine.isLoaded() && !b.engine.isCheckingName && !b.engine.isCheckingVersion) {
      startSelfCheck(b);
      return;
    }
    if (b.engine.isStarted() && !b.engine.isDownWithError) {
      starting = b;
      startingSince = now;
      return;
    }
    try {
      starting = b;
      startingSince = now;
      startAttempts = 0;
      dbg("start engine " + b.seatId + " idx=" + b.engineIndex + " started=" + b.engine.isStarted()
          + " loaded=" + b.engine.isLoaded());
      b.engine.startEngine(b.engineIndex);
      dbg("start engine returned " + b.seatId + " started=" + b.engine.isStarted());
    } catch (Exception e) {
      starting = null;
      dbg("start engine exception " + b.seatId + " " + e);
      failSelfCheck(b, "启动失败: " + e.getMessage());
    }
  }

  private void startSelfCheck(Binding b) {
    if (b.checked || b.checking || b.engine == null) return;
    dbg("selfcheck start " + b.seatId + " idx=" + b.engineIndex + " katago=" + b.engine.isKatago);
    b.checking = true;
    b.channel.armed = true;
    b.checkDeadline = System.nanoTime() + 30000000000L;
    b.checkStarted = System.nanoTime();
    Channel c = b.channel;
    c.genmovePending = false;
    c.bestMove = null;
    c.winrate = -1;
    try {
      b.engine.setResponseUpToDate();
      b.engine.notPondering();
      b.engine.clearBestMoves();
      if (b.engine.isKatago) {
        nowait(b, "stop");
        nowait(b, "kata-set-param maxTime 1");
        nowait(b, "kata-set-param maxVisits 50");
        nowait(b, "kata-set-param maxPlayouts 50");
        nowait(b, "kata-set-param lagBuffer 0");
      } else {
        nowait(b, "time_settings 0 1 1");
      }
      nowait(b, "boardsize 19");
      nowait(b, "komi 7.5");
      nowait(b, "clear_board");
      nowait(b, "play B Q16");
      nowait(b, "play W D4");
      nowait(b, "play B Q4");
      send(
          b,
          b.engine.isKatago ? "kata-genmove_analyze W 20" : "genmove W",
          b.engine.isKatago,
          new Reply() {
            @Override
            public void done(boolean ok, String value) {
              completeSelfCheck(b, ok, value);
            }
          });
    } catch (Exception e) {
      failSelfCheck(b, e.getMessage());
    }
  }

  private void completeSelfCheck(Binding b, boolean ok, String value) {
    if (b == null || closed) return;
    dbg("selfcheck done " + b.seatId + " ok=" + ok + " value=" + value);
    b.checking = false;
    b.checked = true;
    if (!ok || value == null || value.trim().isEmpty()) {
      failSelfCheck(b, "自检失败: " + value);
      return;
    }
    String mv = value.trim().split("\\s+")[0];
    if (!legalSelfCheckPoint(mv)) {
      failSelfCheck(b, "自检返回非法点: " + mv);
      return;
    }
    b.ready = true;
    try {
      nowait(b, "clear_board");
    } catch (Exception e) {
      // ignore
    }
    long ms = (System.nanoTime() - b.checkStarted) / 1000000L;
    client.sendEngineReady(b.seatId, true, engineName(b), ms);
    b.sentMoves = -1; // 正式开局时强制 reset
  }

  private void failSelfCheck(Binding b, String msg) {
    if (b == null) return;
    dbg("selfcheck fail " + b.seatId + " " + msg);
    b.checking = false;
    b.checked = true;
    b.ready = false;
    try {
      if (b.engine != null) b.engine.sendPairCommand(0, "stop");
    } catch (Exception e) {
      // ignore
    }
    client.sendEngineReady(b.seatId, false, engineName(b), 0);
  }

  private boolean legalSelfCheckPoint(String mv) {
    if ("pass".equals(mv) || "resign".equals(mv)) return false;
    java.util.Optional<int[]> c = Board.asCoordinates(mv, 19);
    if (!c.isPresent()) return false;
    int x = c.get()[0], y = c.get()[1];
    if (x < 0 || y < 0 || x >= 19 || y >= 19) return false;
    int[][] occupied = {{15, 3}, {3, 15}, {15, 15}}; // Q16 D4 Q4
    for (int[] o : occupied) if (o[0] == x && o[1] == y) return false;
    return true;
  }

  private String engineName(Binding b) {
    if (b == null || b.engine == null) return "AI";
    return b.engine.oriEnginename == null || b.engine.oriEnginename.isEmpty()
        ? "AI"
        : b.engine.oriEnginename;
  }

  // ------------------------------------------------------------------ 盘面同步 / AI 落子

  private void resetBoards() {
    for (Binding b : bindings) {
      if (b.engine == null || !b.ready) continue;
      try {
        if (b.engine.isKatago) nowait(b, "stop");
        nowait(b, "boardsize 19");
        nowait(b, "komi " + fmtKomi(room.rules.komi));
        sendKataRules(b);
        nowait(b, "clear_board");
        if (room.rules.handicap >= 2) {
          for (int[] pt : handicapPoints(room.rules.handicap)) {
            nowait(b, "play B " + Board.convertCoordinatesToName(pt[0], pt[1]));
          }
        }
        for (RoomMove m : room.moves) nowait(b, playCommand(m));
        b.sentMoves = room.moves.size();
      } catch (Exception e) {
        b.ready = false;
        client.sendEngineDown(b.seatId);
      }
    }
  }

  private void syncMoves() {
    if (room == null) return;
    for (Binding b : bindings) {
      if (!b.ready) continue;
      if (b.sentMoves < 0) {
        // 引擎刚自检完：整盘重置
        b.sentMoves = 0;
        try {
          if (b.engine.isKatago) nowait(b, "stop");
          nowait(b, "boardsize 19");
          nowait(b, "komi " + fmtKomi(room.rules.komi));
          sendKataRules(b);
          nowait(b, "clear_board");
          if (room.rules.handicap >= 2) {
            for (int[] pt : handicapPoints(room.rules.handicap)) {
              nowait(b, "play B " + Board.convertCoordinatesToName(pt[0], pt[1]));
            }
          }
        } catch (Exception e) {
          b.ready = false;
          client.sendEngineDown(b.seatId);
          continue;
        }
      }
      while (b.sentMoves < room.moves.size()) {
        RoomMove m = room.moves.get(b.sentMoves);
        try {
          nowait(b, playCommand(m));
          b.sentMoves++;
        } catch (Exception e) {
          b.ready = false;
          client.sendEngineDown(b.seatId);
          break;
        }
      }
    }
  }

  private static String playCommand(RoomMove m) {
    String color = m.black ? "B" : "W";
    String v = m.pass ? "pass" : Board.convertCoordinatesToName(m.x, m.y);
    return "play " + color + " " + v;
  }

  private void maybeRequestMove() {
    if (room == null || !RoomState.PLAYING.equals(room.phase)) return;
    RoomSeat seat = room.seat(room.turnSeat);
    if (seat == null || !seat.isAi() || seat.playerId != myPlayerId) return;
    Binding b = find(seat.id);
    if (b == null || !b.ready || b.moveInFlight) return;
    if (b.sentMoves != room.moves.size()) return;
    Channel c = b.channel;
    if (c == null) return;
    dbg("genmove request " + b.seatId + " katago=" + b.engine.isKatago + " moves=" + room.moves.size());
    b.moveInFlight = true;
    b.moveResign = false;
    b.moveStarted = System.nanoTime();
    c.genmovePending = true;
    c.moveApplied = false;
    c.bestMove = null;
    c.winrate = -1;
    try {
      if (b.engine.isKatago) {
        if (room.rules.aiUseVisits) {
          nowait(b, "kata-set-param maxTime 1000000000");
          nowait(b, "kata-set-param maxVisits " + Math.max(1, room.rules.aiVisits));
        } else {
          nowait(b, "kata-set-param maxTime " + Math.max(1, room.rules.aiSec));
          nowait(b, "kata-set-param maxVisits 1000000000");
        }
        nowait(b, "kata-set-param maxPlayouts 1000000000");
        nowait(b, "kata-set-param lagBuffer 0");
        nowait(b, "kata-set-param allowResignation false");
        send(
            b,
            "kata-genmove_analyze " + (b.black ? "B" : "W") + " 20",
            true,
            new Reply() {
              @Override
              public void done(boolean ok, String value) {
                completeMove(b, ok, value);
              }
            });
      } else {
        if (!room.rules.aiUseVisits) nowait(b, "time_settings 0 " + Math.max(1, room.rules.aiSec) + " 1");
        send(
            b,
            "genmove " + (b.black ? "B" : "W"),
            false,
            new Reply() {
              @Override
              public void done(boolean ok, String value) {
                completeMove(b, ok, value);
              }
            });
      }
    } catch (Exception e) {
      b.moveInFlight = false;
      b.ready = false;
      client.sendEngineDown(b.seatId);
    }
  }

  private void completeMove(Binding b, boolean ok, String value) {
    if (b == null || closed) return;
    dbg("genmove done " + b.seatId + " ok=" + ok + " value=" + value
        + " winrate=" + (b.channel == null ? -1 : b.channel.winrate));
    b.moveInFlight = false;
    Channel c = b.channel;
    c.genmovePending = false;
    if (!ok || value == null || value.trim().isEmpty()) {
      b.ready = false;
      client.sendEngineDown(b.seatId);
      return;
    }
    String mv = value.trim().split("\\s+")[0];
    long ms = (System.nanoTime() - b.moveStarted) / 1000000L;
    boolean low =
        room.rules.aiResign
            && room.moves.size() >= room.rules.aiResignMinMove
            && c.winrate >= 0
            && c.winrate * 100.0 < room.rules.aiResignWinrate;
    if (low) {
      b.resignConsec++;
      if (b.resignConsec >= room.rules.aiResignConsec) {
        client.sendResign(b.seatId);
        return;
      }
    } else {
      b.resignConsec = 0;
    }
    if ("resign".equals(mv)) {
      if (c.bestMove != null && !c.bestMove.isEmpty()) {
        mv = c.bestMove;
      } else if (room.rules.aiResign) {
        // 非 KataGo 的 genmove 没有胜率：引擎自己说认输就按房规认输
        client.sendResign(b.seatId);
        return;
      } else {
        client.sendMove(b.seatId, room.moves.size() + 1, -1, -1, true, ms);
        return;
      }
    }
    int n = room.moves.size() + 1;
    if ("pass".equals(mv)) {
      client.sendMove(b.seatId, n, -1, -1, true, ms);
      return;
    }
    java.util.Optional<int[]> coords = Board.asCoordinates(mv, 19);
    if (!coords.isPresent()) {
      b.ready = false;
      client.sendEngineDown(b.seatId);
      return;
    }
    client.sendMove(b.seatId, n, coords.get()[0], coords.get()[1], false, ms);
  }

  // ------------------------------------------------------------------ 回执解析

  private boolean consume(Leelaz engine, String line) {
    Channel c = channels.get(engine);
    if (c == null) return false;
    if (!c.armed) return false; // 启动握手（name/version/list_commands）必须交给原生解析器
    String s = line.trim();
    if (s.isEmpty()) return true;
    if (s.startsWith("info ")) {
      if (c.genmovePending) {
        parseInfo(c, s);
      }
      return true;
    }
    if (s.startsWith("play ")) {
      if (c.genmovePending) {
        String mv = s.substring(5).trim().split("\\s+")[0];
        c.moveApplied = true;
        final Req r;
        synchronized (c) {
          r = c.pending;
          c.pending = null;
          c.streaming = false;
          c.genmovePending = false;
        }
        if (r != null) {
          SwingUtilities.invokeLater(
              new Runnable() {
                @Override
                public void run() {
                  r.reply.done(true, mv);
                  pump(c);
                }
              });
        }
      }
      return true;
    }
    if (s.charAt(0) != '=' && s.charAt(0) != '?') return true;
    int p = 1;
    while (p < s.length() && Character.isDigit(s.charAt(p))) p++;
    Integer id =
        (p > 1 && (p == s.length() || Character.isWhitespace(s.charAt(p))))
            ? Integer.valueOf(s.substring(1, p))
            : null;
    int end = id == null ? 1 : p;
    while (end < s.length() && Character.isWhitespace(s.charAt(end))) end++;
    boolean ok = s.charAt(0) == '=';
    String value = s.substring(Math.min(end, s.length())).trim();
    Req r = c.pending;
    if (r == null) return true; // 被接管的引擎，非 pending 回执直接吞
    // 只接受带匹配数字 ID 的回执。启动阶段的 list_commands/version 等回执没有 ID，
    // 不能拿来当 pending 的结果（否则会把 "boardsize clear_board ..." 当成落子）。
    if (id == null || id.intValue() != r.id) return true;
    if (r.streaming && ok && value.isEmpty()) return true; // 等 play 行
    synchronized (c) {
      if (c.pending != r) return true;
      c.pending = null;
      c.streaming = false;
      c.genmovePending = false;
    }
    final Req req = r;
    final boolean fok = ok;
    final String fv = value;
    SwingUtilities.invokeLater(
        new Runnable() {
          @Override
          public void run() {
            req.reply.done(fok, fv);
            pump(c);
          }
        });
    return true;
  }

  private Binding bindingFor(Channel c) {
    for (Binding b : bindings) if (b.channel == c) return b;
    return null;
  }

  private void parseInfo(Channel c, String s) {
    String[] tok = s.split("\\s+");
    for (int i = 0; i + 1 < tok.length; i++) {
      if ("move".equals(tok[i])) {
        c.bestMove = tok[i + 1];
        break;
      }
    }
    for (int i = 0; i + 1 < tok.length; i++) {
      if ("winrate".equals(tok[i])) {
        try {
          c.winrate = Double.parseDouble(tok[i + 1]);
        } catch (Exception e) {
          // ignore
        }
        break;
      }
    }
  }

  // ------------------------------------------------------------------ 发送

  private void nowait(Binding b, String cmd) throws IOException {
    b.engine.sendPairCommand(0, cmd);
  }

  private void send(Binding b, String cmd, boolean streaming, Reply reply) throws IOException {
    Channel c = b.channel;
    synchronized (c) {
      if (c.pending != null) {
        c.queue.addLast(new Req(cmd, streaming, reply));
        return;
      }
      Req r = new Req(cmd, streaming, reply);
      r.id = c.nextId++;
      c.pending = r;
      c.streaming = streaming;
      c.genmovePending = streaming;
      try {
        b.engine.sendPairCommand(r.id, cmd);
      } catch (IOException e) {
        c.pending = null;
        c.streaming = false;
        c.genmovePending = false;
        throw e;
      }
    }
  }

  private void pump(Channel c) {
    synchronized (c) {
      if (c.pending != null) return;
      Req r = c.queue.pollFirst();
      if (r == null) return;
      r.id = c.nextId++;
      c.pending = r;
      c.streaming = r.streaming;
      c.genmovePending = r.streaming;
      try {
        r.reply.toString();
        // 找到引擎：通过 binding
        Binding b = bindingFor(c);
        if (b != null) b.engine.sendPairCommand(r.id, r.cmd);
      } catch (Exception e) {
        c.pending = null;
        c.streaming = false;
        c.genmovePending = false;
      }
    }
  }

  private void close() {
    closed = true;
    ticker.stop();
    for (Binding b : bindings) {
      try {
        if (b.engine != null) b.engine.sendPairCommand(0, "stop");
      } catch (Exception e) {
        // ignore
      }
    }
    bindings.clear();
    channels.clear();
    startQueue.clear();
  }

  /** 房间规则只有中国/日本：直接套用 Lizzie 原生 kata-set-rules，贴目仍单独由 komi 发。 */
  private void sendKataRules(Binding b) throws IOException {
    if (b == null || b.engine == null || !b.engine.isKatago || room == null) return;
    boolean japanese = "japanese".equals(room.rules.ruleSet);
    b.engine.usingSpecificRules = japanese ? 3 : 1;
    dbg("rules " + b.seatId + " " + (japanese ? "japanese" : "chinese"));
    nowait(b, "kata-set-rules " + (japanese ? "japanese" : "chinese"));
  }

  private static String fmtKomi(double komi) {
    return String.format(Locale.ROOT, "%.1f", komi);
  }

  private static int[][] handicapPoints(int n) {
    int[][] pts = {
      {3, 15}, {15, 3}, {3, 3}, {15, 15}, {9, 9}, {3, 9}, {15, 9}, {9, 3}, {9, 15}
    };
    if (n == 6) return new int[][] {pts[0], pts[1], pts[2], pts[3], pts[5], pts[6]};
    if (n == 7) return new int[][] {pts[0], pts[1], pts[2], pts[3], pts[5], pts[6], pts[7]};
    if (n == 8)
      return new int[][] {pts[0], pts[1], pts[2], pts[3], pts[5], pts[6], pts[7], pts[8]};
    return java.util.Arrays.copyOf(pts, Math.max(2, Math.min(9, n)));
  }
}
