package featurecat.lizzie.analysis;

import featurecat.lizzie.Lizzie;
import featurecat.lizzie.gui.LizzieFrame;
import featurecat.lizzie.rules.Board;
import featurecat.lizzie.rules.BoardData;
import featurecat.lizzie.rules.BoardHistoryNode;
import featurecat.lizzie.rules.Stone;
import featurecat.lizzie.util.Utils;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/**
 * 联棋(自定义房间)控制器。
 *
 * <p>黑/白各 1~2 位，每位可以是人类(可设限时)或某个引擎(可设每手时间/计算量/认输条件)。
 * 行棋顺序：黑方第 k 手由 blackSeats[k % n] 下，白方同理。
 *
 * <p>所有棋盘/对局状态变更都在 Swing EDT 上执行。引擎指令使用带数字编号的独立通道，
 * 与 Lizzie 原有的命令队列分离，因此 play/参数回执不会被误认成落子，也不会打乱原生响应计数。
 */
public final class PairGo {
  public static final String VERSION = "3.0.4";

  /** 一个座位 */
  public static class Seat {
    public boolean isAi = false;
    public int engineIndex = -1;
    public String name = "人类";
    // 人类限时：每手固定秒数，超时判负（和 AI 的每手时间同一格式）
    public boolean timeLimit = true;
    public int humanTimeSec = 30;
    public double humanLeft = 30;
    // 兼容旧配置字段，不再参与计时
    public int mainSec = 1200;
    public int byoSec = 20;
    public int byoCount = 3;
    public double mainLeft = 0;
    public double byoRemain = 0;
    public int byoUsed = 0;
    // AI：按时间或按计算量二选一
    public boolean aiUseVisits = false;
    public int aiTimeSec = 3;
    public int aiVisits = 10000;
    public int resignMinMove = 0;
    public int resignConsec = 3;
    public double resignWinrate = 5.0;
    public int resignCounts = 0;

    public String typeName() {
      if (isAi) return name.isEmpty() ? "引擎" : name;
      return "人类";
    }
  }

  /** 某一方 AI 自己给出的判断（不是另一方的互补值）。 */
  public static final class Sample {
    public final int moveNumber;
    public final int visits;
    public final boolean black;
    public final boolean hasScore;
    public final String seatName;
    public final String engineName;
    public final double winrate;
    public final double scoreMean;
    public final double scoreStdev;
    public final long elapsedMillis;
    /** 结束后用当前引擎分析重建曲线时，scoreMean 已换算成白方视角。 */
    public final boolean scoreWhitePerspective;

    public Sample(
        int moveNumber,
        boolean black,
        String seatName,
        String engineName,
        MoveData best,
        boolean hasScore,
        long elapsedMillis,
        int visits) {
      this.moveNumber = moveNumber;
      this.black = black;
      this.seatName = seatName;
      this.engineName = engineName;
      this.winrate = best.winrate;
      this.scoreMean = best.scoreMean;
      this.scoreStdev = best.scoreStdev;
      this.hasScore = hasScore;
      this.elapsedMillis = elapsedMillis;
      this.visits = visits;
      this.scoreWhitePerspective = false;
    }

    /** 结束后从 BoardData 重建曲线用：winrate 保持该手引擎的视角。 */
    public Sample(
        int moveNumber,
        boolean black,
        double winrate,
        boolean hasScore,
        double scoreMean,
        boolean scoreWhitePerspective) {
      this.moveNumber = moveNumber;
      this.black = black;
      this.winrate = winrate;
      this.hasScore = hasScore;
      this.scoreMean = scoreMean;
      this.scoreWhitePerspective = scoreWhitePerspective;
      this.visits = 0;
      this.scoreStdev = 0;
      this.elapsedMillis = 0;
      this.seatName = "";
      this.engineName = "";
    }
  }

  public static volatile boolean active = false;
  public static volatile boolean paused = false;
  public static volatile boolean pureMode = false;

  // ---- 联棋模式：顺序（旧行为）/ 概率
  public static final int MODE_SEQUENCE = 0;
  public static final int MODE_PROBABILITY = 1;
  private static volatile int mode = MODE_SEQUENCE;
  /** 概率模式下“该方第一个座位”的百分比（1~99），黑/白各一套。 */
  private static final int[] probPercent = {50, 50};
  /** 概率种子：同一局同一手永远得到同一个座位，保证复盘/悔棋稳定。 */
  private static volatile long probSeed = 0L;
  /** 座位手数统计缓存（避免每帧重算整条路径）。 */
  private static int[] seatCountCache = new int[0];
  private static int seatCountCacheMove = -1;

  public static List<Seat> blackSeats = new ArrayList<Seat>();
  public static List<Seat> whiteSeats = new ArrayList<Seat>();

  private static BoardHistoryNode gameRoot;
  private static BoardHistoryNode turnNode;
  private static Leelaz originalEngine;
  private static Leelaz movingEngine;
  private static boolean savedNames;
  private static boolean namesOverridden;
  private static boolean starting;
  private static boolean applying;
  private static long generation;
  private static long turnStarted;
  private static long pauseStarted;
  private static long pausedNanos;
  private static long lastTick;
  private static long lastMoveMillis;
  private static long lastPublish;
  private static long lastUi;
  private static String status = "";
  private static int completedMove;
  private static Timer timer;
  private static Timer closeTimer;
  private static Timer switchTimer;
  private static Timer nativeResumeTimer;
  /** 联棋实际用过的引擎。结束后切到别的引擎复盘时，要把它们全部停掉。 */
  private static final List<Leelaz> pairEngines = new ArrayList<Leelaz>();
  /** 已经切走/换引擎时，取消结束对局后延迟恢复的原生分析。 */
  private static volatile boolean nativeResumeCancelled;
  private static final ArrayList<Sample> history = new ArrayList<Sample>();
  private static volatile Sample liveSample;
  /** 结束对局时冻结的“最后一手分析”，让左侧信息块结束后保持联棋格式。 */
  private static volatile TurnInfo frozenTurn;
  private static final ArrayList<String> moveLog = new ArrayList<String>();
  private static final Map<Leelaz, Channel> channels = new ConcurrentHashMap<Leelaz, Channel>();

  // 引擎启动必须串行：多个 KataGo 同时初始化 OpenCL，会触发 nvopencl64.dll 的
  // 0xc0000005 访问冲突（进程直接崩溃，界面报“引擎异常关闭/加载引擎失败”）。
  // 这里用一条队列逐个启动，前一台 isLoaded 之后再启动下一台。
  private static final ArrayDeque<Integer> pendingEngineStarts = new ArrayDeque<Integer>();
  /** 云端引擎（ikatago/SSH 代理）不初始化本地 GPU，可以并行启动；本地 KataGo 仍串行。 */
  private static final List<Leelaz> startingCloud = new ArrayList<Leelaz>();
  private static final Map<Leelaz, Integer> cloudTries = new ConcurrentHashMap<Leelaz, Integer>();
  private static final Map<Leelaz, Long> cloudSince = new ConcurrentHashMap<Leelaz, Long>();
  private static Leelaz startingEngine;
  private static long startingSince;
  private static long startRetryAt;
  private static int startAttempts;
  private static int startBatchDone;
  private static int startBatchTotal;
  private static double currentKomi = Double.NaN;
  private static long lastKomiCheck;
  /** 当前规则 JSON（KataGo）；新开/重同步引擎时补发，保证日本规则等设置也生效。 */
  private static volatile String rulesJson = "";

  // ---- 临时诊断日志（-Dpairgo.debug=<file> 时启用；不影响正常运行）
  private static final java.io.PrintWriter DEBUG = openDebug();

  private static java.io.PrintWriter openDebug() {
    try {
      String path = System.getProperty("pairgo.debug", "");
      if (path.isEmpty()) return null;
      return new java.io.PrintWriter(new java.io.FileWriter(path, true), true);
    } catch (Exception e) {
      return null;
    }
  }

  private static void dbg(String msg) {
    java.io.PrintWriter w = DEBUG;
    if (w == null) return;
    w.println(
        new java.text.SimpleDateFormat("HH:mm:ss.SSS").format(new java.util.Date())
            + " "
            + msg);
  }

  private static String engName(Leelaz e) {
    return e == null ? "null" : "E" + System.identityHashCode(e);
  }

  /** 一条待回执的联棋命令（引擎一次只处理一条，忙时排队而不是丢弃）。 */
  private static final class Req {
    final int id;
    final String cmd;
    final Reply reply;

    Req(int id, String cmd, Reply reply) {
      this.id = id;
      this.cmd = cmd;
      this.reply = reply;
    }
  }

  private static final class Channel {
    final java.util.ArrayDeque<Req> queue = new java.util.ArrayDeque<Req>();
    final java.util.HashMap<String, String> paramCache = new java.util.HashMap<String, String>();
    final java.util.HashSet<String> badParams = new java.util.HashSet<String>();
    boolean preparing;
    boolean ready;
    boolean closing;
    boolean generated;
    boolean inFlight;
    boolean moveApplied; // genmove 的落子已经由 play 行处理过
    boolean restoring;
    boolean abandoned;
    /** 新通道先做一次 stop+name 屏障，把上一局迟到的回执全部吃掉再发 setup。 */
    boolean barrier;
    Runnable barrierNext;
    long barrierSince;
    long generation;
    volatile String info;
    String result;
    volatile Reply pending;
    volatile int skipReplies;
    long skipSince;
    String pendingCommand;
    volatile long pendingSince;
    final Map<String, String> saved = new java.util.LinkedHashMap<String, String>();
  }

  private interface Reply {
    void done(boolean ok, String value);
  }

  // ------------------------------------------------------------------ 座位

  public static List<Seat> allSeats() {
    ArrayList<Seat> seats = new ArrayList<Seat>(blackSeats);
    seats.addAll(whiteSeats);
    return seats;
  }

  private static int moveCountOfColor(BoardHistoryNode node, boolean black) {
    int count = 0;
    BoardHistoryNode n = node;
    while (n.previous().isPresent()) {
      BoardData data = n.getData();
      if (!data.dummy && data.lastMoveColor == (black ? Stone.BLACK : Stone.WHITE)) count++;
      n = n.previous().get();
    }
    return count;
  }

  public static Seat seatForTurn() {
    if (Lizzie.board == null) return null;
    boolean black = Lizzie.board.getHistory().isBlacksTurn();
    List<Seat> list = black ? blackSeats : whiteSeats;
    if (list.isEmpty()) return null;
    int count = moveCountOfColor(Lizzie.board.getHistory().getCurrentHistoryNode(), black);
    return list.get(pickSeatIndex(list, black, count));
  }

  private static Seat seatForNode(BoardHistoryNode node) {
    if (node == null) return null;
    boolean black = node.getData().blackToPlay;
    List<Seat> list = black ? blackSeats : whiteSeats;
    if (list.isEmpty()) return null;
    return list.get(pickSeatIndex(list, black, moveCountOfColor(node, black)));
  }

  /**
   * 第 index 手（该色从 0 开始的序号）归哪个座位。
   * 顺序模式：轮流；概率模式：用 (种子, 颜色, 手数) 做确定性掷点，
   * 同一局的同一手永远得到同一个座位——悔棋、前进、复盘、换引擎重放都不会变。
   */
  private static int pickSeatIndex(List<Seat> list, boolean black, int index) {
    int size = list.size();
    if (size <= 1) return 0;
    if (mode != MODE_PROBABILITY) return Math.floorMod(index, size);
    int p = clampPercent(probPercent[black ? 0 : 1]);
    long h = probMix(probSeed, black ? 1 : 2, index);
    int r = (int) Math.floorMod(h, 100L);
    return r < p ? 0 : 1;
  }

  /** 概率只接受 1~99 的整数；空、乱码、0、100、负数一律按 50。 */
  public static int clampPercent(int value) {
    return value < 1 || value > 99 ? 50 : value;
  }

  private static long probMix(long seed, int color, int index) {
    long z = seed + 0x9E3779B97F4A7C15L * (index + 1L) + color * 0xBF58476D1CE4E5B9L;
    z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
    z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
    return z ^ (z >>> 31);
  }

  public static boolean isProbabilityMode() {
    return mode == MODE_PROBABILITY;
  }

  /** 概率模式下每个座位实际下了多少手，顺序与 allSeats() 一致。 */
  public static int[] seatMoveCounts() {
    List<Seat> seats = allSeats();
    int[] counts = new int[Math.max(1, seats.size())];
    if (Lizzie.board == null) return counts;
    int moveNo = Lizzie.board.getHistory().getMoveNumber();
    if (seatCountCacheMove == moveNo && seatCountCache.length == counts.length) {
      return seatCountCache.clone();
    }
    BoardHistoryNode node = Lizzie.board.getHistory().getCurrentHistoryNode();
    while (node != null && node.previous().isPresent()) {
      BoardHistoryNode parent = node.previous().get();
      if (!node.getData().dummy) {
        Seat s = seatForNode(parent);
        int i = s == null ? -1 : seats.indexOf(s);
        if (i >= 0 && i < counts.length) counts[i]++;
      }
      node = parent;
    }
    seatCountCache = counts.clone();
    seatCountCacheMove = moveNo;
    return counts;
  }

  /** 形如「12手黑方① 3手黑方②」；只在概率模式显示。 */
  public static String seatMoveCountText() {
    if (!active || mode != MODE_PROBABILITY) return "";
    int[] counts = seatMoveCounts();
    List<Seat> seats = allSeats();
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < seats.size(); i++) {
      if (i > 0) sb.append(' ');
      sb.append(counts[i]).append("手").append(seatLabelFor(seats.get(i)));
    }
    return sb.toString();
  }

  public static String seatLabelFor(Seat seat) {
    boolean black = blackSeats.contains(seat);
    List<Seat> list = black ? blackSeats : whiteSeats;
    int i = list.indexOf(seat);
    return (black ? "黑方" : "白方") + (i <= 0 ? "①" : "②");
  }

  /** 只有棋盘同步完成、且停在最新局面时人类才能落子。 */
  public static boolean isHumanTurn() {
    Seat seat = seatForTurn();
    if (!active || paused || starting || applying || seat == null || seat.isAi) return false;
    if (Lizzie.board.getHistory().getCurrentHistoryNode() != turnNode) return false;
    for (Channel c : channels.values())
      if (c.generation == generation && !c.ready) return false;
    return true;
  }

  public static boolean allAi() {
    for (Seat s : allSeats()) if (!s.isAi) return false;
    return true;
  }

  public static boolean isCurrent(Seat s) {
    return active && seatForTurn() == s;
  }

  public static String turnText() {
    Seat s = seatForTurn();
    String who = s == null ? "" : seatLabelFor(s) + "(" + s.typeName() + ")";
    return "联棋 " + who + (paused ? " 已暂停" : " 落子");
  }

  public static boolean ownsEngine(Leelaz engine) {
    return channels.containsKey(engine);
  }

  /**
   * 接管后，通道就绪期间原生代码不要再往这台引擎发任何命令。
   * 之前只按白名单拦 play/komi/kata-analyze，像 kata-get-rules / kata-get-param
   * 这类“只写不等”的命令仍会挤进同一个 stdin，回执被联棋通道当成别的命令的回执，
   * 一旦用户在联棋中改规则/贴目，整个引擎的应答就错位了。
   * 启动和收尾阶段（未就绪 / closing / abandoned）必须放行，否则引擎起不来。
   */
  public static boolean blocksNativeCommand(Leelaz engine, String command) {
    // 联棋结束后必须完全放行原生命令（人机对弈的 time_settings 等）。
    // 之前只看通道是否存在，收尾中的旧通道会把人机对弈调时间静默吞掉。
    if (!active) return false;
    Channel c = channels.get(engine);
    if (c == null || command == null) return false;
    if (c.closing || c.abandoned) return false; // 正在收尾，原生分析要能立刻恢复
    String s = command.trim().toLowerCase(Locale.ROOT);
    if (s.equals("quit")) return false;
    if (!c.ready) return false; // 启动/同步期的探查命令保持放行
    return true;
  }

  // ------------------------------------------------------------------ 数据显示

  public static boolean hasGameHistory() {
    // 结束联棋（active=false）后立即回到原生界面：左侧统计、胜率图、候选表都按普通对局显示，
    // 不能等用户清空棋盘才恢复。
    return active
        && gameRoot != null
        && Lizzie.board != null
        && Lizzie.board.getHistory().getStart() == gameRoot;
  }

  public static boolean isPureDisplay() {
    return active && pureMode;
  }

  /** 这盘棋是不是联棋（不管是否已经结束），用于结束后继续画联棋胜率图。 */
  public static boolean hasPairRecord() {
    return gameRoot != null
        && Lizzie.board != null
        && Lizzie.board.getHistory().getStart() == gameRoot;
  }

  public static boolean hasSamples() {
    if (!hasPairRecord()) return false;
    synchronized (history) {
      return !history.isEmpty();
    }
  }

  public static List<Sample> samples() {
    if (!hasPairRecord()) return Collections.emptyList();
    ArrayList<Sample> result;
    synchronized (history) {
      result = new ArrayList<Sample>(history);
    }
    Sample live = liveSample;
    if (live != null) result.add(live);
    return Collections.unmodifiableList(result);
  }

  /**
   * 胜率曲线数据：联棋进行中用 PairGo 自己采样的黑白视角数据；
   * 结束后改成从 BoardData 重建，这样换引擎分析时节点被引擎覆盖，曲线也跟着覆盖，
   * 但仍然是联棋的曲线格式。
   */
  public static List<Sample> graphSamples() {
    if (active) return samples();
    if (!hasPairRecord() || Lizzie.board == null) return Collections.emptyList();
    ArrayList<Sample> out = new ArrayList<Sample>();
    BoardHistoryNode end = Lizzie.board.getHistory().getMainEnd();
    BoardHistoryNode node = Lizzie.board.getHistory().getStart();
    while (node != null) {
      BoardData d = node.getData();
      if (d.getPlayouts() > 0
          && Double.isFinite(d.winrate)
          && d.winrate >= 0
          && d.winrate <= 100) {
        boolean black = d.blackToPlay;
        boolean hasScore = d.isKataData && Double.isFinite(d.scoreMean);
        // 目差统一成白方视角：黑方节点取反，白方节点原样。
        double scoreWhite = hasScore ? (black ? -d.scoreMean : d.scoreMean) : 0;
        // 联棋样本按“下一手”编号（根节点分析画在第 1 手位置），这里保持同样的横坐标，
        // 结束后曲线不会整体左移一格。
        out.add(new Sample(d.moveNumber + 1, black, d.winrate, hasScore, scoreWhite, true));
      }
      if (node == end) break;
      node = node.next().orElse(null);
    }
    return out;
  }

  public static Sample latest(boolean black) {
    int view = Lizzie.board == null ? Integer.MAX_VALUE : Lizzie.board.getHistory().getMoveNumber() + 1;
    Sample found = null;
    for (Sample sample : samples())
      if (sample.black == black && sample.moveNumber <= view) found = sample;
    return found;
  }

  /** 同一方（同一套引擎判断）上一步的分析，用于日志里的“比上一步 ±x”。 */
  private static Sample previousOf(Sample current) {
    if (current == null) return null;
    synchronized (history) {
      for (int i = history.size() - 1; i >= 0; i--) {
        Sample s = history.get(i);
        if (s.black == current.black && s.moveNumber < current.moveNumber) return s;
      }
    }
    return null;
  }

  /** 当前轮次（即将落子的一方）的展示信息，供左侧信息块和左下角状态行使用。 */
  public static final class TurnInfo {
    public final String label;
    public final boolean ai;
    public final boolean hasData;
    public final double winrate;
    public final double scoreMean;
    public final double scoreStdev;
    public final int visits;
    public final long elapsedMillis;
    /** 同一方上一步是否有可比数据（黑白是两套独立判断，不能跨方比较）。 */
    public final boolean hasPrev;
    public final double prevWinrate;
    public final double prevScoreMean;

    TurnInfo(String label, boolean ai, Sample s, long elapsed) {
      this.label = label;
      this.ai = ai;
      this.hasData = s != null;
      this.winrate = s == null ? 0 : s.winrate;
      this.scoreMean = s == null ? 0 : s.scoreMean;
      this.scoreStdev = s == null ? 0 : s.scoreStdev;
      this.visits = s == null ? 0 : s.visits;
      this.elapsedMillis = elapsed;
      Sample prev = previousOf(s);
      this.hasPrev = prev != null;
      this.prevWinrate = prev == null ? 0 : prev.winrate;
      this.prevScoreMean = prev == null ? 0 : prev.scoreMean;
    }
  }

  public static TurnInfo turnInfo() {
    if (!active) return frozenTurn;
    return buildTurnInfo();
  }

  private static TurnInfo buildTurnInfo() {
    if (turnNode == null) return null;
    Seat seat = seatForTurn();
    if (seat == null) return null;
    String name = seat.typeName();
    if (name.length() > 16) name = name.substring(0, 15) + "…";
    String label = seatLabelFor(seat) + " " + name;
    if (!seat.isAi) return new TurnInfo(label, false, null, currentMoveMillis());
    // 正在思考的这手，info 行就是“将要落子”这一手的判断。
    Sample live = liveSample;
    return new TurnInfo(label, true, live, currentMoveMillis());
  }

  public static long currentMoveMillis() {
    if (!active) return lastMoveMillis;
    if (starting || turnStarted == 0) return 0;
    long now = paused ? pauseStarted : System.nanoTime();
    return Math.max(0, (now - turnStarted - pausedNanos) / 1000000L);
  }

  public static String sideText(List<Seat> list) {
    StringBuilder text = new StringBuilder();
    for (int i = 0; i < list.size(); i++) {
      Seat s = list.get(i);
      if (i > 0) text.append("  ");
      String n = s.typeName();
      if (n.length() > 16) n = n.substring(0, 15) + "…";
      text.append(i == 0 ? "①" : "②").append(n).append(clockText(s));
    }
    return text.toString();
  }

  public static String playersText() {
    return "黑 " + sideText(blackSeats) + "   VS   白 " + sideText(whiteSeats);
  }

  public static String bottomText() {
    return playersText();
  }

  public static String movesText() {
    StringBuilder text = new StringBuilder();
    for (int i = Math.max(0, moveLog.size() - 2); i < moveLog.size(); i++) {
      if (text.length() > 0) text.append(" ｜ ");
      text.append(moveLog.get(i));
    }
    return text.toString();
  }

  public static String statusText() {
    StringBuilder text = new StringBuilder();
    text.append(active ? turnText() : "联棋已结束");
    if (active) text.append("  此手用时 ").append(String.format(Locale.ROOT, "%.1f秒", currentMoveMillis() / 1000.0));
    if (!status.isEmpty()) text.append("  ").append(status);
    if (!moveLog.isEmpty()) text.append("  ").append(movesText());
    return text.toString();
  }

  public static String clockText(Seat s) {
    if (s == null) return "";
    if (s.isAi) {
      return s.aiUseVisits
          ? " 计算量" + Math.max(0, s.aiVisits)
          : " " + Math.max(0, s.aiTimeSec) + "秒";
    }
    return " " + Math.max(0, (int) Math.ceil(s.humanLeft)) + "秒";
  }

  // ------------------------------------------------------------------ 启动

  public static void start(List<Seat> black, List<Seat> white) {
    start(black, white, 0, false);
  }

  public static void start(
      final List<Seat> black,
      final List<Seat> white,
      final int handicap,
      final boolean continuation) {
    start(black, white, handicap, continuation, MODE_SEQUENCE, 50, 50, 0L);
  }

  public static void start(
      final List<Seat> black,
      final List<Seat> white,
      final int handicap,
      final boolean continuation,
      final int gameMode,
      final int blackPercent,
      final int whitePercent,
      final long seed) {
    if (!SwingUtilities.isEventDispatchThread()) {
      SwingUtilities.invokeLater(
          () ->
              start(
                  black,
                  white,
                  handicap,
                  continuation,
                  gameMode,
                  blackPercent,
                  whitePercent,
                  seed));
      return;
    }
    mode = gameMode == MODE_PROBABILITY ? MODE_PROBABILITY : MODE_SEQUENCE;
    probPercent[0] = clampPercent(blackPercent);
    probPercent[1] = clampPercent(whitePercent);
    probSeed = seed != 0L ? seed : new java.util.Random().nextLong();
    seatCountCache = new int[0];
    seatCountCacheMove = -1;
    if (active) stop();
    if (!channels.isEmpty()) {
      // 收尾是异步的；开新局时直接释放旧通道，让 prepare 重新建立局面。
      for (Channel c : channels.values()) {
        c.closing = true;
        c.abandoned = true;
        c.inFlight = false;
      }
      channels.clear();
    }
    generation++;
    if (closeTimer != null) {
      closeTimer.stop();
      closeTimer = null;
    }
    originalEngine = Lizzie.leelaz;
    dbg("START original=" + engName(originalEngine));
    if (originalEngine != null) {
      originalEngine.nameCmdfornoponder();
      originalEngine.notPondering();
    }
    blackSeats = new ArrayList<Seat>(black);
    whiteSeats = new ArrayList<Seat>(white);
    // 先关掉原生人机/引擎对战标记，后面的清盘与让子落子就不会走原生调度。
    Lizzie.frame.isPlayingAgainstLeelaz = false;
    Lizzie.frame.isAnaPlayingAgainstLeelaz = false;
    double komi = Lizzie.board.getHistory().getGameInfo().getKomi();
    if (!continuation) {
      Lizzie.board.clear(false);
      Lizzie.board.getHistory().getGameInfo().setKomi(komi);
      Lizzie.board.getHistory().getGameInfo().setHandicap(handicap >= 2 ? handicap : 0);
      if (handicap >= 2) {
        int[][] points = handicapPoints(handicap);
        for (int[] pt : points) Lizzie.board.place(pt[0], pt[1], Stone.BLACK);
        Lizzie.board.flatten();
        // 让子不是普通落子，必须记成“起始棋子”。否则结束对局后换一台引擎复盘时，
        // 原生 resendMoveToEngine() 只重放 getMoveList()，新引擎看到的是空盘，
        // 分析会和棋盘上的让子盘面冲突。
        if (Lizzie.board.startStonelist == null) {
          Lizzie.board.startStonelist = new ArrayList<featurecat.lizzie.rules.Movelist>();
        } else {
          Lizzie.board.startStonelist.clear();
        }
        Lizzie.board.hasStartStone = true;
        for (int[] pt : points) Lizzie.board.setStartListStone(pt, true);
        if (Lizzie.board.getData() != null) Lizzie.board.getData().blackToPlay = false;
      }
    }
    gameRoot = Lizzie.board.getHistory().getStart();
    synchronized (history) {
      history.clear();
    }
    liveSample = null;
    moveLog.clear();
    status = "引擎同步中…";
    for (Seat s : allSeats()) {
      s.humanLeft = s.humanTimeSec > 0 ? s.humanTimeSec : 30;
      s.resignCounts = 0;
    }
    savedNames = Lizzie.config.showNameInBoard;
    namesOverridden = true;
    Lizzie.config.showNameInBoard = true;
    Lizzie.board.getHistory().getGameInfo().setPlayerBlack(teamName(blackSeats));
    Lizzie.board.getHistory().getGameInfo().setPlayerWhite(teamName(whiteSeats));
    try {
      Lizzie.frame.setPlayers(teamName(whiteSeats), teamName(blackSeats));
    } catch (Exception e) {
      // 标题只是辅助信息，失败不影响对局
    }
    LizzieFrame.boardRenderer.changedName = true;

    active = true;
    paused = false;
    starting = true;
    frozenTurn = null;
    movingEngine = null;
    turnNode = null;
    turnStarted = 0;
    pausedNanos = 0;
    lastMoveMillis = 0;
    completedMove = Lizzie.board.getHistory().getMoveNumber();
    currentKomi = Lizzie.board.getHistory().getGameInfo().getKomi();
    if (rulesJson == null || rulesJson.isEmpty()) {
      if (Lizzie.config.autoLoadKataRules
          && Lizzie.config.kataRules != null
          && !Lizzie.config.kataRules.isEmpty()) rulesJson = Lizzie.config.kataRules;
    }
    pendingEngineStarts.clear();
    startingCloud.clear();
    cloudTries.clear();
    cloudSince.clear();
    startingEngine = null;
    startAttempts = 0;
    startRetryAt = 0;
    startBatchDone = 0;
    startBatchTotal = 0;
    nativeResumeCancelled = false;
    if (nativeResumeTimer != null) {
      nativeResumeTimer.stop();
      nativeResumeTimer = null;
    }
    pairEngines.clear();
    // 引擎必须一台一台启动（见字段注释）：先把所有通道建好，再按队列逐个拉起。
    List<Integer> startup = new ArrayList<Integer>();
    for (int index : usedEngines()) {
      Leelaz engine = engineAt(index);
      if (engine == null) {
        fail("引擎不存在: " + index);
        return;
      }
      if (!pairEngines.contains(engine)) pairEngines.add(engine);
      dbg("CH engine=" + engName(engine) + " index=" + index);
      Channel channel = new Channel();
      channel.generation = generation;
      engine.notPondering();
      engine.clearBestMoves();
      channels.put(engine, channel);
      if (engine.isStarted() && engine.isLoaded()) {
        // 不要走原生 nameCmdfornoponder：它会往原生队列插一条回执，
        // 新通道的 stop+name 屏障容易把两条 name 回执搞混。停分析交给屏障里的 stop。
        engine.notPondering();
      } else if (isCloudEngine(engine)) {
        // 云引擎只是连远端代理，没有本地 OpenCL 初始化，可以并行拉起。
        try {
          engine.startEngine(index);
          startingCloud.add(engine);
          cloudTries.put(engine, 0);
          cloudSince.put(engine, System.nanoTime());
        } catch (Exception e) {
          fail("启动引擎失败: " + e.getMessage());
          return;
        }
      } else {
        // 包括 Lizzie 已经在后台启动、但还没加载完的引擎：只等它，不能重复起进程。
        startup.add(index);
      }
    }
    startBatchTotal = startup.size() + startingCloud.size();
    for (int index : startup) pendingEngineStarts.add(index);
    if (!pendingEngineStarts.isEmpty()) {
      status = "引擎启动中 1/" + startBatchTotal + "…";
      startNextEngine();
    }
    timer = new Timer(100, e -> tick());
    timer.start();
    lastTick = System.nanoTime();
    lastUi = 0;
    lastPublish = 0;
    LizzieFrame.menu.setPairGameMode(true);
    try {
      Lizzie.frame.reSetLoc();
    } catch (Exception e) {
      // 布局刷新失败不影响对局
    }
    updateUi();
    check();
  }

  /**
   * 棋盘下方双方名字。概率模式下把「手数」放在最前面（如 `15手①智子 1x`）：
   * 原生绘制会按像素宽度截断过长的名字，放在开头才不会被截掉。
   */
  private static String teamName(List<Seat> seats) {
    boolean prob = mode == MODE_PROBABILITY;
    int[] counts = prob ? seatMoveCounts() : null;
    List<Seat> all = prob ? allSeats() : null;
    StringBuilder text = new StringBuilder();
    for (int i = 0; i < seats.size(); i++) {
      if (i > 0) text.append(" / ");
      if (prob) {
        Seat seat = seats.get(i);
        int idx = all.indexOf(seat);
        int count = idx >= 0 && idx < counts.length ? counts[idx] : 0;
        text.append(count).append("手");
      }
      text.append(i == 0 ? "①" : "②").append(seats.get(i).typeName());
    }
    return text.toString();
  }

  /** 每落一手刷新棋盘下方的双方名字（概率模式里带手数）。 */
  private static void updatePlayerNames() {
    try {
      if (blackSeats.isEmpty() && whiteSeats.isEmpty()) return;
      Lizzie.board.getHistory().getGameInfo().setPlayerBlack(teamName(blackSeats));
      Lizzie.board.getHistory().getGameInfo().setPlayerWhite(teamName(whiteSeats));
    } catch (Exception e) {
      // 名字只是显示，失败不影响对局
    }
  }

  private static List<Integer> usedEngines() {
    LinkedHashSet<Integer> ids = new LinkedHashSet<Integer>();
    for (Seat s : allSeats()) if (s.isAi) ids.add(s.engineIndex);
    return new ArrayList<Integer>(ids);
  }

  private static Leelaz engineAt(int index) {
    try {
      return Lizzie.engineManager.engineList.get(index);
    } catch (Exception e) {
      return null;
    }
  }

  private static int engineIndexOf(Leelaz engine) {
    try {
      return Lizzie.engineManager.engineList.indexOf(engine);
    } catch (Exception e) {
      return -1;
    }
  }

  /**
   * 联棋把某台引擎设为当前主引擎时，同步原生引擎索引。
   *
   * <p>原生 switchEngine 用 EngineManager.currentEngineNo 找“当前引擎”来停止分析；联棋只改
   * Lizzie.leelaz 不改索引时，结束后启动另一台引擎复盘，原生代码会去停一台无关的引擎，
   * 真正的对局引擎继续分析并和新引擎抢同一块棋盘 —— 用户看到的就是画面一闪一闪。
   */
  private static void setMainEngine(Leelaz engine) {
    if (engine == null) return;
    Lizzie.leelaz = engine;
    int index = engineIndexOf(engine);
    if (index >= 0) EngineManager.currentEngineNo = index;
  }

  /**
   * 用户启动/切换到另一台引擎复盘时由 EngineManager 调用。
   *
   * <p>1) 取消联棋结束后延迟恢复原生分析；2) 停掉所有联棋用过的引擎，只保留即将启用的这台。
   * 这样新引擎和旧对局引擎不会同时往同一个棋盘写分析，画面不再闪烁。
   */
  public static void beforeNativeEngineSwitch(Leelaz nextEngine) {
    nativeResumeCancelled = true;
    if (nativeResumeTimer != null) {
      nativeResumeTimer.stop();
      nativeResumeTimer = null;
    }
    if (Lizzie.board != null) {
      dbg(
          "SWITCH moves="
              + Lizzie.board.getMoveList().size()
              + " startStone="
              + Lizzie.board.hasStartStone
              + "/"
              + (Lizzie.board.startStonelist == null
                  ? 0
                  : Lizzie.board.startStonelist.size()));
    }
    if (active) return; // 联棋进行中不允许换引擎，交给原逻辑处理
    LinkedHashSet<Leelaz> engines = new LinkedHashSet<Leelaz>(pairEngines);
    engines.addAll(channels.keySet());
    // 当前主引擎由 EngineManager 自己的 curEng 逻辑停止，这里不重复发 stop。
    for (Leelaz engine : engines) {
      if (engine == null || engine == nextEngine || !engine.isStarted()) continue;
      try {
        engine.notPondering();
        // KataGo 收到 stop 会结束正在跑的 kata-analyze；这一步必须在切主引擎前发。
        engine.sendCommand(engine.isKatago ? "stop" : "name");
        engine.clearBestMoves();
        dbg("SWITCHSTOP " + engName(engine) + " -> " + engName(nextEngine));
      } catch (Exception e) {
        // 单台引擎停不下来不影响切换
      }
    }
  }

  /** 联棋结束后，不能参与原生显示的对局引擎（防止迟到 info 行闪屏）。 */
  public static boolean isForeignPairEngine(Leelaz engine) {
    if (active || engine == null || EngineManager.isEngineGame) return false;
    if (engine == Lizzie.leelaz || engine == Lizzie.leelaz2) return false;
    return pairEngines.contains(engine);
  }

  /** 云端引擎（ikatago / SSH 代理）没有本地 GPU 初始化冲突，可并行启动。 */
  private static boolean isCloudEngine(Leelaz engine) {
    String cmd =
        engine.engineCommand == null ? "" : engine.engineCommand.toLowerCase(Locale.ROOT);
    return cmd.contains("ikatago") || cmd.contains("ssh") || cmd.contains("plink")
        || cmd.contains("http");
  }

  /** 轮询并行启动中的云引擎。 */
  private static void pollCloudStartup(long now) {
    if (startingCloud.isEmpty()) return;
    for (java.util.Iterator<Leelaz> it = startingCloud.iterator(); it.hasNext(); ) {
      Leelaz engine = it.next();
      if (engine.isLoaded() && !engine.isCheckingName) {
        it.remove();
        startBatchDone++;
        dbg("STARTED cloud " + engName(engine));
        continue;
      }
      if (engine.isDownWithError) {
        int tries = cloudTries.containsKey(engine) ? cloudTries.get(engine) : 0;
        if (tries >= 2) {
          it.remove();
          fail("引擎启动失败：" + engName(engine) + "（已重试 2 次，请检查账号/网络/显存）");
          return;
        }
        cloudTries.put(engine, tries + 1);
        cloudSince.put(engine, now);
        try {
          engine.startEngine(engineIndexOf(engine));
        } catch (Exception e) {
          // 下一拍继续判断
        }
        continue;
      }
      Long since = cloudSince.get(engine);
      if (since != null && (now - since) / 1000000L > 120000L) {
        it.remove();
        fail("引擎启动超时：" + engName(engine));
        return;
      }
    }
  }

  /**
   * 启动启动队列里的下一台引擎。同一时刻只允许一台 KataGo 在初始化 OpenCL，
   * 否则多台并发会把 NV 驱动顶崩（0xc0000005）。
   */
  private static void startNextEngine() {
    if (startingEngine != null || pendingEngineStarts.isEmpty()) return;
    final int index = pendingEngineStarts.pollFirst();
    Leelaz engine = engineAt(index);
    if (engine == null) {
      startBatchDone++;
      startNextEngine();
      return;
    }
    startingEngine = engine;
    startingSince = System.nanoTime();
    startAttempts = 0;
    startRetryAt = 0;
    dbg(
        "STARTENGINE "
            + engName(engine)
            + " index="
            + index
            + " "
            + (startBatchDone + 1)
            + "/"
            + startBatchTotal);
    // 进程已退出/状态坏了（上一局结束后常见）：isStarted 仍为 true 但 isLoaded false，
    // 必须重新拉起，否则第二局会一直卡在“引擎同步中”。
    if (!engine.isStarted()
        || (engine.isDownWithError && !engine.isCheckingName)
        || (!engine.isLoaded() && !engine.isCheckingName && !engine.isCheckingVersion)) {
      try {
        // 通道建立前先把原生启动/探测命令发完，回执照常走原解析器，计数器不会错位。
        engine.startEngine(index);
      } catch (Exception e) {
        startingEngine = null;
        fail("启动引擎失败: " + e.getMessage());
        return;
      }
    }
    status =
        "引擎启动中 " + (startBatchDone + 1) + "/" + Math.max(1, startBatchTotal) + "…";
    updateUi();
  }

  /** 由 tick() 驱动：等上一台 isLoaded 后，才启动下一台；失败时重试一次。 */
  private static void pollEngineStartup(long now) {
    pollCloudStartup(now);
    if (startingEngine != null) {
      if (startingEngine.isLoaded() && !startingEngine.isCheckingName) {
        dbg("STARTED " + engName(startingEngine));
        startingEngine = null;
        startBatchDone++;
        startNextEngine();
        return;
      }
      if (startingEngine.isDownWithError) {
        if (now < startRetryAt) return;
        if (startAttempts >= 2) {
          String name = engName(startingEngine);
          startingEngine = null;
          fail("引擎启动失败：" + name + "（已重试 2 次，请检查显卡/显存/驱动）");
          return;
        }
        startAttempts++;
        startRetryAt = now + 3000000000L;
        status = "引擎启动失败，3 秒后重试（" + startAttempts + "/2）…";
        dbg("STARTFAIL " + engName(startingEngine) + " retry=" + startAttempts);
        updateUi();
        try {
          startingEngine.startEngine(engineIndexOf(startingEngine));
        } catch (Exception e) {
          // 下一拍继续判断
        }
        startingSince = now;
        return;
      }
      if ((now - startingSince) / 1000000L > 120000L) {
        String name = engName(startingEngine);
        startingEngine = null;
        fail("引擎启动超时：" + name);
      }
      return;
    }
    if (!pendingEngineStarts.isEmpty()) startNextEngine();
  }

  private static boolean anyChannelPreparing() {
    for (Channel c : channels.values()) if (c.preparing) return true;
    return false;
  }

  /**
   * 贴目等设置在对局中改变后，不结束对局，而是让所有联棋引擎按新设置重新同步。
   * 原生命令会被 blocksNativeCommand 拦住，引擎只认联棋通道里的 komi。
   *
   * @return true 表示已经发起重同步；false 表示当前正在启动/同步，稍后再试。
   */
  private static boolean resyncAll(String reason) {
    if (!active || starting || applying) return false;
    if (startingEngine != null || anyChannelPreparing()) return false;
    Leelaz thinking = movingEngine;
    movingEngine = null;
    if (thinking != null) {
      try {
        thinking.sendPairCommand(0, "stop");
      } catch (Exception e) {
        // ignore
      }
    }
    for (Map.Entry<Leelaz, Channel> en : channels.entrySet()) {
      Channel c = en.getValue();
      if (c.generation != generation) continue;
      c.ready = false;
      c.preparing = false;
      c.inFlight = false;
      c.generated = false;
      c.barrier = false;
      c.barrierNext = null;
      c.info = null;
      c.paramCache.clear();
      synchronized (c) {
        c.pending = null;
        c.pendingCommand = null;
        c.pendingSince = 0;
      }
      while (!c.queue.isEmpty()) {
        Req r = c.queue.pollFirst();
        try {
          r.reply.done(false, "resync");
        } catch (Exception e) {
          // ignore
        }
      }
    }
    status = reason + "，正在重新同步引擎…";
    lastKomiCheck = System.nanoTime();
    updateUi();
    return true;
  }

  /** 记录当前 KataGo 规则（SetKataRules 应用时调用），下次同步/新开引擎会补发。 */
  public static void setRules(String json) {
    rulesJson = json == null ? "" : json;
    int type = classifyRules(rulesJson);
    if (type > 0) {
      for (Leelaz e : channels.keySet()) e.usingSpecificRules = type;
    }
    if (active) resyncAll("规则已修改");
  }

  /** 把 KataGo rules JSON 归类成原生界面的规则编号（1 中国 / 2 中古 / 3 日本 / 4 TT / 5 其他）。 */
  private static int classifyRules(String json) {
    if (json == null || json.isEmpty()) return -1;
    String s = json.replaceAll("\\s+", "");
    boolean area = s.contains("\"scoring\":\"AREA\"");
    boolean terr = s.contains("\"scoring\":\"TERRITORY\"");
    boolean positional = s.contains("\"ko\":\"POSITIONAL\"");
    boolean suicide = s.contains("\"suicide\":true");
    boolean taxNone = s.contains("\"tax\":\"NONE\"");
    boolean taxAll = s.contains("\"tax\":\"ALL\"");
    boolean taxSeki = s.contains("\"tax\":\"SEKI\"");
    boolean whbN = s.contains("\"whiteHandicapBonus\":\"N\"");
    boolean button = s.contains("\"hasButton\":true");
    if (area && positional && suicide && taxNone && whbN && !button) return 4;
    if (area && taxNone && !button) return 1;
    if (area && taxAll && !button) return 2;
    if (terr && taxSeki) return 3;
    if (area || terr) return 5;
    return -1;
  }

  public static String rulesJson() {
    return rulesJson;
  }

  /** 标准让子点(19 路)，非 19 路时取前 n 个角/边星。 */
  public static int[][] handicapPoints(int n) {
    int[][] pts = {
      {3, 15}, {15, 3}, {3, 3}, {15, 15}, {9, 9}, {3, 9}, {15, 9}, {9, 3}, {9, 15}
    };
    if (Board.boardWidth != 19 || Board.boardHeight != 19) {
      int max = Math.min(Board.boardWidth, Board.boardHeight) - 1;
      int lo = Math.max(1, Board.boardWidth / 4);
      int hi = Math.max(lo, Board.boardWidth - 1 - lo);
      int mid = Board.boardWidth / 2;
      int maxy = Math.min(Board.boardHeight - 1, max);
      int midy = Board.boardHeight / 2;
      int[][] generic = {
        {lo, hi}, {hi, lo}, {lo, 1}, {hi, maxy}, {mid, midy},
        {lo, midy}, {hi, midy}, {mid, lo}, {mid, hi}
      };
      return java.util.Arrays.copyOf(generic, Math.max(2, Math.min(9, n)));
    }
    if (n == 6) return new int[][] {pts[0], pts[1], pts[2], pts[3], pts[5], pts[6]};
    if (n == 7) return new int[][] {pts[0], pts[1], pts[2], pts[3], pts[5], pts[6], pts[7]};
    if (n == 8)
      return new int[][] {pts[0], pts[1], pts[2], pts[3], pts[5], pts[6], pts[7], pts[8]};
    return java.util.Arrays.copyOf(pts, Math.max(2, Math.min(9, n)));
  }

  // ------------------------------------------------------------------ 引擎同步

  private static void prepare(Leelaz engine, Channel channel) {
    channel.preparing = true;
    // 联棋独占这台引擎：原生命令计数可能因为被拦截/迟到回执而错位，
    // 先对齐计数，免得重同步被 isResponseUpToDate() 永远挡住。
    engine.setResponseUpToDate();
    // 引擎有可能被重启/重连，参数缓存作废，下一次落子前重新下发。
    channel.paramCache.clear();
    List<String> setup = new ArrayList<String>();
    List<String> plays = new ArrayList<String>();
    // 先打断上一局可能残留的搜索，避免迟到的 play 混进新棋局。
    if (engine.isKatago) setup.add("stop");
    setup.add(
        Board.boardWidth == Board.boardHeight
            ? "boardsize " + Board.boardWidth
            : "rectangular_boardsize " + Board.boardWidth + " " + Board.boardHeight);
    setup.add("clear_board");
    setup.add("komi " + Lizzie.board.getHistory().getGameInfo().getKomi());
    // KataGo 的日本规则等设置必须显式同步到每一台联棋引擎；否则新启动的引擎
    // 会退回配置里的默认规则（例如中国规则），胜率/目差和点目都会不对。
    String rules = rulesJson;
    if (rules == null || rules.isEmpty()) {
      if (Lizzie.config.autoLoadKataRules
          && Lizzie.config.kataRules != null
          && !Lizzie.config.kataRules.isEmpty()) rules = Lizzie.config.kataRules;
    }
    if (engine.isKatago && rules != null && !rules.isEmpty()) {
      setup.add("kata-set-rules " + rules);
      int ruleType = classifyRules(rules);
      if (ruleType > 0) engine.usingSpecificRules = ruleType;
    }
    // 没有显式规则时按原生默认显示“中国规则”（大多数用户的底线设置），
    // 否则左上角会比原生界面少一行规则文字。
    if (engine.isKatago && engine.usingSpecificRules <= 0) engine.usingSpecificRules = 1;
    BoardHistoryNode root = gameRoot;
    if (root == null) {
      fail("棋谱起点丢失，无法同步引擎");
      return;
    }
    Stone[] stones = root.getData().stones;
    for (int x = 0; x < Board.boardWidth; x++)
      for (int y = 0; y < Board.boardHeight; y++) {
        Stone stone = stones[Board.getIndex(x, y)];
        if (stone == Stone.BLACK || stone == Stone.WHITE)
          plays.add(
              "play " + (stone == Stone.BLACK ? "B " : "W ") + Board.convertCoordinatesToName(x, y));
      }
    List<BoardHistoryNode> path = new ArrayList<BoardHistoryNode>();
    BoardHistoryNode node = Lizzie.board.getHistory().getCurrentHistoryNode();
    while (node.previous().isPresent()) {
      path.add(node);
      node = node.previous().get();
    }
    Collections.reverse(path);
    for (BoardHistoryNode n : path) {
      if (n.getData().dummy) continue;
      BoardData d = n.getData();
      plays.add(
          "play "
              + (d.lastMoveColor == Stone.BLACK ? "B " : "W ")
              + (d.lastMove.isPresent()
                  ? Board.convertCoordinatesToName(d.lastMove.get()[0], d.lastMove.get()[1])
                  : "pass"));
    }
    final long token = channel.generation;
    final List<String> replay = plays;
    Runnable beginSetup =
        () ->
            sequence(
                engine,
                setup,
                0,
                token,
                () -> {
                  if (!valid(token)) return;
                  // 棋谱重放一次性发出、不逐条等回执：云引擎经常不回 play，
                  // 逐条等会把长棋谱的重同步拖成几分钟。GTP 是 FIFO，紧跟其后的
                  // kata-get-param 回执天然就是“前面全部处理完”的屏障。
                  channel.skipSince = System.nanoTime();
                  for (String move : replay) {
                    channel.skipReplies++;
                    try {
                      engine.sendPairCommand(0, move);
                    } catch (Exception e) {
                      channel.skipReplies--;
                    }
                  }
                  if (engine.isKatago) {
                    saveParams(
                        engine, channel, new String[] {"maxTime", "maxVisits", "maxPlayouts"}, 0);
                  } else {
                    channel.preparing = false;
                    channel.ready = true;
                    check();
                  }
                });
    startWithBarrier(engine, channel, token, beginSetup);
  }

  /**
   * 新一局同步前先发 stop + name：stop 让上一局残留的搜索结束，name 的回执作为屏障。
   * 屏障期间收到的空回执/数字回执（上一局的 stop、kata-get-param 等）全部丢弃，
   * 否则它们会被新通道误当成 setup 命令的回执，整串错位后第二局会一直卡在“引擎同步中”。
   */
  private static void startWithBarrier(
      Leelaz engine, Channel channel, long token, Runnable next) {
    channel.barrier = true;
    channel.barrierNext = next;
    channel.barrierSince = System.nanoTime();
    try {
      if (engine.isKatago) engine.sendPairCommand(0, "stop");
    } catch (Exception e) {
      // 引擎连接有问题时交给 name 超时兜底
    }
    command(
        engine,
        BARRIER_ID,
        "name",
        (ok, value) -> {
          if (!valid(token)) return;
          finishBarrier(channel, token);
        });
  }

  private static void finishBarrier(Channel channel, long token) {
    if (!channel.barrier) return;
    channel.barrier = false;
    synchronized (channel) {
      if ("name".equals(channel.pendingCommand)) {
        channel.pending = null;
        channel.pendingCommand = null;
        channel.pendingSince = 0;
      }
    }
    Runnable next = channel.barrierNext;
    channel.barrierNext = null;
    if (valid(token) && next != null) next.run();
  }

  private static void saveParams(Leelaz engine, Channel channel, String[] keys, int i) {
    if (!valid(channel.generation)) return;
    if (i == keys.length) {
      channel.preparing = false;
      channel.ready = true;
      check();
      return;
    }
    command(
        engine,
        "kata-get-param " + keys[i],
        (ok, value) -> {
          if (ok
              && (value.matches("[-+0-9.eE]+")
                  || "true".equalsIgnoreCase(value)
                  || "false".equalsIgnoreCase(value))) {
            channel.saved.put(keys[i], value);
          }
          if (valid(channel.generation)) saveParams(engine, channel, keys, i + 1);
        });
  }

  private static boolean valid(long token) {
    return active && token == generation;
  }

  private static void sequence(
      Leelaz engine, List<String> commands, int i, long token, Runnable done) {
    if (!valid(token)) return;
    if (i == commands.size()) {
      done.run();
      return;
    }
    String cmd = commands.get(i);
    command(
        engine,
        cmd,
        (ok, value) -> {
          if (!valid(token)) return;
          if (!ok && !cmd.equals("stop")) {
            if (cmd.startsWith("kata-set-rules ")) {
              // 部分云端代理不支持规则命令：跳过它，不能把整盘棋判成同步失败。
              status = "引擎不支持该规则设置，已跳过";
            } else {
              retryTurn(engine, channels.get(engine), "引擎同步失败 (" + cmd + "): " + value);
              return;
            }
          }
          sequence(engine, commands, i + 1, token, done);
        });
  }

  private static void pump(Leelaz engine, Channel c) {
    if (c.pending != null || c.closing) return;
    Req next = c.queue.pollFirst();
    if (next == null) return;
    command(engine, next.id, next.cmd, next.reply);
  }

  private static void command(Leelaz engine, String cmd, Reply reply) {
    command(engine, 0, cmd, reply);
  }

  private static void command(Leelaz engine, int id, String cmd, Reply reply) {
    Channel c = channels.get(engine);
    dbg("SEND " + engName(engine) + " pending=" + (c == null ? "-" : String.valueOf(c.pending != null)) + " cmd=" + cmd);
    if (c == null) {
      reply.done(false, "engine not in pair mode");
      return;
    }
    // 每条引擎同一时刻只保留一个待回执请求。忙时排队，等前一条回执到了再发，
    // 这样既不会丢回调，也不会把两条命令的回执张冠李戴。stop 例外（要立刻打断）。
    if (c.pending != null) {
      if (cmd.equals("stop")) {
        try {
          engine.sendPairCommand(0, cmd);
        } catch (Exception e) {
          // ignore
        }
        return;
      }
      c.queue.addLast(new Req(id, cmd, reply));
      return;
    }
    c.pending = reply;
    c.pendingCommand = cmd;
    try {
      engine.sendPairCommand(id, cmd);
    } catch (Exception e) {
      c.pending = null;
      c.pendingCommand = null;
      reply.done(false, String.valueOf(e.getMessage()));
    }
  }

  // ------------------------------------------------------------------ GTP 输出

  /** 由 Leelaz 读取线程调用，返回 true 表示这条输出已由联棋消费。 */
  /** 屏障命令使用的 GTP 数字编号；正常联棋命令不带编号，因此不会误伤数值回执。 */
  private static final int BARRIER_ID = 987654321;

  public static boolean handleLine(final Leelaz engine, String line) {
    if (line == null) return false;
    String s = line.trim();
    dbg("LINE " + (line.length() > 120 ? line.substring(0, 120) : line));
    if (s.startsWith("=") || s.startsWith("?")) {
      final Channel c = channels.get(engine);
      if (c == null) return false;
      // 先识别数字编号：只有 "=123 ..." 这种“等号后紧跟数字”的才是编号；
      // "= 3" 是 kata-get-param 的数值回执，不能当编号剥掉。
      int p = 1;
      int idStart = p;
      while (p < s.length() && Character.isDigit(s.charAt(p))) p++;
      final Integer replyId =
          (p > idStart && (p == s.length() || Character.isWhitespace(s.charAt(p))))
              ? Integer.valueOf(s.substring(idStart, p))
              : null;
      int end = replyId == null ? 1 : p;
      while (end < s.length() && Character.isWhitespace(s.charAt(end))) end++;
      final boolean ok = s.charAt(0) == '=';
      final String value = s.substring(Math.min(end, s.length())).trim();
      // 新通道屏障：只认带 BARRIER_ID 的 name 回执；上一局残留的 stop/参数回执
      // （无论空、数字还是引擎名）全部吞掉，否则 setup 命令会整体错位一条。
      if (c.barrier) {
        boolean barrierIdReply = replyId != null && replyId.intValue() == BARRIER_ID;
        // 兼容会剥掉 GTP 编号的代理：无编号的 name 非空回执也认。
        boolean barrierFallback =
            replyId == null
                && ok
                && !value.isEmpty()
                && !value.matches("[-+0-9.eE]+");
        boolean barrierReply = barrierIdReply || barrierFallback;
        if (!barrierReply) {
          // 少数代理不支持 GTP 数字编号：引擎会回 "? unknown command"。
          // 这时说明它已经处理到屏障命令了，直接放行 setup，等满超时太慢。
          if (!ok && value.toLowerCase(Locale.ROOT).contains("unknown")) {
            SwingUtilities.invokeLater(() -> finishBarrier(c, c.generation));
          }
          return true;
        }
      } else if (replyId != null && replyId.intValue() == BARRIER_ID) {
        // 屏障曾经超时，迟到的 name 回执不能再被后一条 setup 命令当成自己的回执。
        return true;
      }
      final Reply reply;
      synchronized (c) {
        reply = c.pending;
        if (reply != null) {
          boolean genmovePending =
              c.pendingCommand != null && c.pendingCommand.contains("genmove");
          if (!ok && genmovePending && !c.moveApplied && value.contains("param")) {
            return true; // 参数被拒的回执，不是这一手的落子失败
          }
          boolean completeGenmoveTrailer =
              ok && value.isEmpty() && genmovePending && c.moveApplied;
          if (!completeGenmoveTrailer) {
            if (ok && value.isEmpty() && genmovePending) {
              // 落子还没出现，这个空回执只可能是参数/补 play 的，不能拿来顶掉 genmove。
              if (c.skipReplies > 0) c.skipReplies--;
              return true;
            }
            if (ok
                && value.isEmpty()
                && c.pendingCommand != null
                && c.pendingCommand.startsWith("kata-get-param")) {
              // 数值答复不可能是空的。
              if (c.skipReplies > 0) c.skipReplies--;
              return true;
            }
            if (ok && value.isEmpty() && c.skipReplies > 0) {
              c.skipReplies--;
              return true;
            }
          }
          c.pending = null;
          c.pendingCommand = null;
          c.pendingSince = 0;
        }
      }
      if (reply == null) {
        if (c.skipReplies > 0 && System.nanoTime() - c.skipSince < 5000000000L) {
          c.skipReplies--;
          return true; // 参数类/重放命令的回执，直接丢弃
        }
        c.skipReplies = 0;
        return false; // 原生启动/参数回执，交回原解析器
      }
      SwingUtilities.invokeLater(() -> reply.done(ok, value));
      SwingUtilities.invokeLater(() -> pump(engine, c));
      return true;
    }
    final Channel c = channels.get(engine);
    if (c == null) return active && (s.startsWith("info ") || s.startsWith("play "));
    if (s.startsWith("info ")) {
      // 联棋已经结束：把 info 行交回原解析器，否则结束对局后原生分析
      // （kata-analyze/winrate）会被联棋通道一直吞掉，左侧胜率停在旧值。
      if (!active) return false;
      if (engine == movingEngine && !c.closing) c.info = s;
      return true;
    }
    if (s.startsWith("play ")) {
      if (!active) return false;
      final String move = s.substring(5).trim();
      if (c.pendingCommand != null && c.pendingCommand.contains("genmove")) c.moveApplied = true;
      SwingUtilities.invokeLater(() -> generated(engine, c, move));
      return true;
    }
    // 启动/原生回执仍交给原解析器，保持原有命令计数一致。
    return false;
  }

  private static void publishInfo(Leelaz engine, Channel channel) {
    String raw = channel.info;
    channel.info = null;
    if (raw == null || !active || isPureDisplay() || movingEngine != engine || turnNode == null) return;
    try {
      ArrayList<MoveData> moves = new ArrayList<MoveData>();
      String body = raw.substring(5).split(" ownership ")[0];
      for (String variation : body.split(" info ")) {
        if (variation.trim().isEmpty()) continue;
        MoveData move =
            engine.isKatago
                ? MoveData.fromInfoKatago(variation)
                : (engine.isSai
                    ? MoveData.fromInfoSai(variation, engine.pairIsSayuri())
                    : MoveData.fromInfo(variation));
        if (move.coordinate != null && Double.isFinite(move.winrate)) moves.add(move);
      }
      if (moves.isEmpty()) return;
      Collections.sort(
          moves,
          new Comparator<MoveData>() {
            public int compare(MoveData a, MoveData b) {
              return Integer.compare(a.order, b.order);
            }
          });
      Seat seat = seatForTurn();
      if (seat == null) return;
      int visits = MoveData.getPlayouts(moves);
      boolean hasScore =
          raw.contains("scoreMean ") || raw.contains("scoreLead ") || raw.contains("areas ");
      engine.pairSetBestMoves(moves);
      liveSample =
          new Sample(
              turnNode.getData().moveNumber + 1,
              turnNode.getData().blackToPlay,
              seatLabelFor(seat) + " " + seat.typeName(),
              seat.typeName(),
              moves.get(0),
              hasScore,
              currentMoveMillis(),
              visits);
      if (Lizzie.board.getHistory().getCurrentHistoryNode() == turnNode) {
        setMainEngine(engine);
        BoardData data = turnNode.getData();
        data.isChanged = true;
        data.tryToSetBestMoves(new ArrayList<MoveData>(moves), seat.typeName(), true, visits);
      }
    } catch (Exception e) {
      status = "分析数据解析失败: " + e.getMessage();
    }
  }

  /** 人类落子后由 LizzieFrame.refresh() 触发；不做事时立即返回，避免 EDT 抖动。 */
  private static boolean checkQueued;

  public static void onRefresh() {
    if (!active || applying || checkQueued || Lizzie.board == null) return;
    if (Lizzie.board.getHistory().getCurrentHistoryNode() == turnNode) return;
    checkQueued = true;
    SwingUtilities.invokeLater(
        () -> {
          checkQueued = false;
          check();
        });
  }

  private static void tick() {
    if (!active) return;
    long now = System.nanoTime();
    pollEngineStartup(now);
    if (!active) return;
    // 贴目被用户改动（顶部输入框/加减按钮/棋子菜单）时，不结束对局，
    // 而是让所有联棋引擎按新贴目重新同步。原生 komi 指令已被通道拦截。
    if (!starting && !applying && now - lastKomiCheck > 500000000L) {
      double komi = Lizzie.board.getHistory().getGameInfo().getKomi();
      if (!Double.isNaN(komi)
          && !Double.isNaN(currentKomi)
          && Math.abs(komi - currentKomi) > 1e-9) {
        if (resyncAll("贴目已改为 " + String.format(Locale.ROOT, "%.1f", komi))) {
          currentKomi = komi;
          lastKomiCheck = now;
        }
      }
    }
    double delta = Math.max(0, Math.min(1.0, (now - lastTick) / 1e9));
    lastTick = now;
    for (Map.Entry<Leelaz, Channel> entry : channels.entrySet()) {
      Channel c = entry.getValue();
      Leelaz engine = entry.getKey();
      if (c.generation != generation || c.closing || c.preparing || c.ready || c.inFlight) continue;
      if (engine == movingEngine) continue; // 正在思考的引擎不能重同步
      if (c.pending != null) continue; // 还有回执没到，等它落地再开屏障
      // 不要用 isResponseUpToDate 挡住启动：上一局结束后的原生 ponoder/stop 回执
      // 会让计数暂时落后，第二局就会永远停在“引擎同步中”。prepare() 自己会先对齐计数。
      if (engine.isLoaded() && !engine.isCheckingName) prepare(engine, c);
    }
    for (Map.Entry<Leelaz, Channel> en : channels.entrySet()) {
      Leelaz engine = en.getKey();
      Channel c = en.getValue();
      if (c.pending != null && c.pendingSince == 0) c.pendingSince = now;
      if (c.pending == null) continue;
      long waitedMs = (now - c.pendingSince) / 1000000L;
      String cmd = c.pendingCommand == null ? "" : c.pendingCommand;
      // 云引擎/远端代理不保证回执每条命令：非关键命令超时直接放行，避免整局卡死。
      if (cmd.startsWith("play ")
          || cmd.startsWith("kata-set-param")
          || cmd.startsWith("time_settings")
          || cmd.startsWith("kata-get-param")
          || cmd.equals("stop")) {
        long ackLimit =
            cmd.startsWith("play ")
                ? 1500L
                : (cmd.startsWith("kata-get-param") ? 2500L : 2000L);
        if (waitedMs > ackLimit) {
          dbg("TIMEOUT8 " + cmd + " waited=" + waitedMs);
          Reply reply;
          synchronized (c) {
            reply = c.pending;
            c.pending = null;
            c.pendingCommand = null;
            c.pendingSince = 0;
          }
          if (reply == null) continue;
          SwingUtilities.invokeLater(() -> reply.done(false, "timeout"));
          SwingUtilities.invokeLater(() -> pump(engine, c));
        }
        continue;
      }
      if (cmd.equals("name") && c.barrier) {
        // 引擎理论上支持数字编号，name 一定回；给上一局排队的命令留足 20 秒，
        // 还回不来就放行 setup，不能把整局卡死在同步阶段。
        if (waitedMs > 20000) {
          Reply reply;
          synchronized (c) {
            reply = c.pending;
            c.pending = null;
            c.pendingCommand = null;
            c.pendingSince = 0;
          }
          if (reply != null) reply.done(false, "barrier timeout");
          finishBarrier(c, c.generation);
        }
        continue;
      }
      if (cmd.contains("genmove")) {
        // 超时只当作“引擎还在算”，绝不补发第二条 genmove（会一手算两次）。
        long limit = currentSeatMillisLimit() + 45000L;
        dbg("WAITGEN " + cmd + " " + waitedMs + "/" + limit);
        if (waitedMs > softLimitFor()) status = "引擎仍在思考（已 " + (waitedMs / 1000) + " 秒）";
        if (waitedMs > limit) {
          Reply reply;
          synchronized (c) {
            reply = c.pending;
            c.pending = null;
            c.pendingCommand = null;
            c.pendingSince = 0;
          }
          if (reply == null) continue;
          retryTurn(engine, c, "引擎思考超时");
        }
        continue;
      }
      if (waitedMs > 45000) {
        String pendingName = cmd;
        c.pending = null;
        c.pendingCommand = null;
        c.pendingSince = 0;
        fail("引擎 45 秒没有回复: " + pendingName);
        return;
      }
    }
    if (!paused && !starting && turnNode != null) {
      Seat s = seatForTurn();
      if (s != null && !s.isAi) charge(s, delta);
      if (!active) return;
    }
    if (movingEngine != null) {
      Channel c = channels.get(movingEngine);
      Seat thinking = seatForTurn();
      if (thinking != null) {
        status = seatLabelFor(thinking) + " " + thinking.typeName() + " 思考中 "
            + String.format(Locale.ROOT, "%.0f秒", currentMoveMillis() / 1000.0);
      }
      if (c != null && now - lastPublish >= 100000000L) {
        publishInfo(movingEngine, c);
        lastPublish = now;
      }
    }
    check();
    if (now - lastUi >= 100000000L) {
      lastUi = now;
      updateUi();
    }
  }

  private static void sendParams(
      Leelaz engine, Channel c, List<String> params, int i, long token, Runnable done) {
    if (!valid(token)) return;
    while (i < params.size()) {
      final String param = params.get(i);
      final String key = paramKey(param);
      final int next = i + 1;
      if (c.badParams.contains(key) || param.equals(c.paramCache.get(key))) {
        i++;
        continue;
      }
      command(
          engine,
          param,
          (ok, value) -> {
            if (!valid(token)) return;
            if (ok) {
              c.paramCache.put(key, param);
            } else {
              // 引擎不认这条参数：本局不再发它，也不影响落子。
              c.badParams.add(key);
              status = "引擎不支持参数 " + key + "，已跳过";
            }
            sendParams(engine, c, params, next, token, done);
          });
      return;
    }
    done.run();
  }

  private static String paramKey(String param) {
    // kata-set-param 的参数名在第二个词，其余命令用整条命令做键（含数值）。
    if (!param.startsWith("kata-set-param ")) return param;
    int first = param.indexOf(' ');
    int second = param.indexOf(' ', first + 1);
    return second < 0 ? param : param.substring(0, second);
  }

  private static long currentSeatMillisLimit() {
    Seat seat = seatForTurn();
    long per =
        seat == null
            ? 3000
            : (seat.aiUseVisits ? 120000 : Math.max(1000, seat.aiTimeSec * 1000L));
    return per + 10000L;
  }

  /** 只是提示用的软超时：每手时间 + 3 秒；计算量模式给足 120 秒。 */
  private static long softLimitFor() {
    Seat seat = seatForTurn();
    long per =
        seat == null
            ? 3000
            : (seat.aiUseVisits ? 120000 : Math.max(1000, seat.aiTimeSec * 1000L));
    return per + 3000L;
  }

  private static void charge(Seat seat, double seconds) {
    if (seconds <= 0 || seat == null || seat.isAi) return;
    seat.humanLeft -= seconds;
    if (seat.humanLeft > 1e-9) return;
    seat.humanLeft = 0;
    boolean black = blackSeats.contains(seat);
    Lizzie.board.getHistory().getGameInfo().setResult(black ? "W+T" : "B+T");
    String message = (black ? "黑方" : "白方") + "超时，对局结束";
    stop();
    status = message;
    updateUi();
    Utils.showMsgNoModal("联棋：" + message);
  }

  private static void check() {
    dbg("CHECK active=" + active + " paused=" + paused + " applying=" + applying + " starting=" + starting + " turnNode=" + (turnNode == null ? "null" : turnNode.getData().moveNumber) + " moving=" + engName(movingEngine));
    if (!active || paused || applying) return;
    if (!hasGameHistory()) {
      stop();
      return;
    }
    for (Channel c : channels.values()) if (c.generation == generation && !c.ready) return;
    if (starting) {
      starting = false;
      status = "";
      lastTick = System.nanoTime();
    }
    BoardHistoryNode current = Lizzie.board.getHistory().getCurrentHistoryNode();
    if (current != Lizzie.board.getHistory().getMainEnd()) {
      status = "正在查看历史，回到最新局面后继续";
      return;
    }
    if (turnNode != current) {
      if (turnNode != null && current.getData().moveNumber > completedMove) {
        recordMove(current);
        if (!active) return;
      }
      beginTurn(current);
    }
    if (movingEngine == null) {
      Seat seat = seatForTurn();
      if (seat != null && seat.isAi) advance(seat);
    }
  }

  private static void beginTurn(BoardHistoryNode node) {
    turnNode = node;
    turnRetries = 0;
    completedMove = node.getData().moveNumber;
    turnStarted = System.nanoTime();
    pausedNanos = 0;
    pauseStarted = 0;
    lastTick = turnStarted;
    liveSample = null;
    status = "";
    Seat seat = seatForTurn();
    if (seat != null && !seat.isAi) {
      seat.humanLeft = seat.humanTimeSec > 0 ? seat.humanTimeSec : 30;
    }
    if (seat == null || !seat.isAi || isPureDisplay()) {
      // 人类回合（以及纯净对弈）不发分析请求，也不伪造新样本。
      if (Lizzie.leelaz != null) Lizzie.leelaz.clearBestMoves();
      BoardData data = node.getData();
      data.bestMoves = new ArrayList<MoveData>();
      data.setPlayouts(0);
    }
    updateUi();
  }

  private static void recordMove(BoardHistoryNode current) {
    dbg("RECORD move=" + current.getData().moveNumber + " by=" + engName(movingEngine));
    Seat played = seatForNode(turnNode);
    lastMoveMillis = currentMoveMillis();
    if (liveSample != null) {
      synchronized (history) {
        history.add(liveSample);
      }
      liveSample = null;
    }
    BoardData data = current.getData();
    String move =
        data.lastMove.isPresent()
            ? Board.convertCoordinatesToName(data.lastMove.get()[0], data.lastMove.get()[1])
            : "pass";
    String who = played == null ? "" : seatLabelFor(played) + " " + played.typeName();
    String seconds = String.format(Locale.ROOT, "%.1f", lastMoveMillis / 1000.0);
    String entry = data.moveNumber + " " + who + " " + move + " (" + seconds + "秒)";
    moveLog.add(entry);
    updatePlayerNames();
    String timeText = Lizzie.resourceBundle.getString("SGFParse.moveTime");
    data.comment =
        (data.comment.isEmpty() ? "" : data.comment + "\n")
            + entry
            + "\n"
            + timeText
            + seconds
            + "秒";
    String color = data.lastMoveColor == Stone.WHITE ? "W" : "B";
    for (Map.Entry<Leelaz, Channel> en : channels.entrySet()) {
      Leelaz engine = en.getKey();
      Channel c = en.getValue();
      if (c.generation != generation || c.closing) continue;
      if (engine == movingEngine) continue; // genmove 自己已经落过这手
      final long token = generation;
      // 仅仅是给闲置引擎补一手 play：不回执也绝不能把通道判成“未就绪”，
      // 否则主循环会对思考中的引擎反复整盘重同步，把它正在算的那手结果丢掉。
      // 补 play 只写不等回执：云引擎常常不回 play，占用回执通道会把整局拖死。
      c.skipSince = System.nanoTime();
      c.skipReplies++;
      try {
        engine.sendPairCommand(0, "play " + color + " " + move);
      } catch (Exception e) {
        c.skipReplies--;
      }
    }
    movingEngine = null;
    if (data.lastMove.isPresent()) return;
    BoardHistoryNode prev = current.previous().orElse(null);
    if (prev != null && prev != gameRoot && !prev.getData().lastMove.isPresent()) {
      status = "双方连续停一手，对局结束";
      stop();
    }
  }

  // ------------------------------------------------------------------ AI 落子

  private static void advance(Seat seat) {
    dbg("ADVANCE seat=" + (seat == null ? "null" : seatLabelFor(seat)) + " moving=" + engName(movingEngine));
    final Leelaz engine = engineAt(seat.engineIndex);
    final Channel c = channels.get(engine);
    if (c == null || !c.ready) return;
    movingEngine = engine;
    setMainEngine(engine);
    engine.notPondering();
    engine.clearBestMoves();
    turnNode.getData().isChanged = true;
    c.generated = false;
    c.result = null;
    c.info = null;
    final long token = generation;
    List<String> params = new ArrayList<String>();
    if (engine.isKatago) {
      // 按时间/按计算量二选一：未选中的那一项发一个极大的上限，避免两个条件同时生效。
      // 引擎自己的 allowResignation 会绕过联棋的“手数/连续/胜率”设置，先关掉它；
      // 不支持该参数的云端会在 sendParams 里自动跳过，后面的 resign 门禁仍会兜底。
      params.add("kata-set-param allowResignation false");
      if (seat.aiUseVisits) {
        params.add("kata-set-param maxTime 1000000000");
        params.add(
            "kata-set-param maxVisits "
                + (seat.aiVisits > 0 ? seat.aiVisits : 10000));
      } else {
        params.add(
            "kata-set-param maxTime "
                + (seat.aiTimeSec > 0 ? seat.aiTimeSec : 3));
        params.add("kata-set-param maxVisits 1000000000");
      }
      params.add("kata-set-param maxPlayouts 1000000000");
      params.add("kata-set-param lagBuffer 0");
    } else if (!seat.aiUseVisits && seat.aiTimeSec > 0) {
      params.add("time_settings 0 " + seat.aiTimeSec + " 1");
    }
    // 参数逐条发、逐条收：被引擎拒绝的参数只在当次记下来并停发，
    // 绝不会把拒绝回执算成“落子失败”。已发过的参数不重复发。
    sendParams(
        engine,
        c,
        params,
        0,
        token,
        () -> {
          requestStarted = System.nanoTime();
          turnStarted = requestStarted;
          pausedNanos = 0;
          engine.pkMoveStartTime = System.currentTimeMillis();
          String color = turnNode.getData().blackToPlay ? "B" : "W";
          String cmd;
          // 纯净模式只影响显示，不改变对引擎说的话：换命令会让云端直接不回。
          if (engine.isKatago && !engine.noAnalyze) cmd = "kata-genmove_analyze " + color + " 20";
          else if (engine.pairIsSayuri()) cmd = "genmove_analyze " + color + " 20";
          else if (engine.pairIsLeela() || engine.isSai) cmd = "lz-genmove_analyze " + color + " 20";
          else cmd = "genmove " + color;
          c.inFlight = true;
          c.moveApplied = false;
          command(
              engine,
              cmd,
              (ok, value) -> {
                c.inFlight = false;
                if (!ok) {
                  if (cmd.contains("analyze")
                      && (value.equals("timeout")
                          || value.toLowerCase().contains("unknown")
                          || value.toLowerCase().contains("unsupported")
                          || value.toLowerCase().contains("error"))) {
                    status = "引擎不支持实时分析，改用普通落子";
                    c.inFlight = true;
                    command(
                        engine,
                        "genmove " + color,
                        (ok2, v2) -> {
                          c.inFlight = false;
                          if (!valid(token)) {
                            finishClosing(engine, c);
                            return;
                          }
                          if (ok2) generated(engine, c, v2);
                          else retryTurn(engine, c, "引擎落子失败: " + v2);
                        });
                  } else if (valid(token)) {
                    retryTurn(engine, c, "引擎落子失败: " + value);
                  }
                } else if (!value.isEmpty()) {
                  generated(engine, c, value);
                }
                // analyze 的空回执表示实时分析结束；真正的落子在 play 行。
              });
        });
  }

  private static long requestStarted;
  private static int turnRetries;

  private static void configure(
      Leelaz engine, List<String> commands, int i, long token, Runnable done) {
    if (!valid(token)) return;
    if (i == commands.size()) {
      done.run();
      return;
    }
    command(
        engine,
        commands.get(i),
        (ok, value) -> {
          if (!valid(token)) return;
          if (!ok) status = "引擎不接受参数 " + commands.get(i) + ": " + value;
          configure(engine, commands, i + 1, token, done);
        });
  }

  private static void generated(Leelaz engine, Channel c, String value) {
    dbg("GEN enter engine=" + engName(engine) + " moving=" + engName(movingEngine) + " generated=" + c.generated + " preparing=" + c.preparing + " value=" + value);
    c.inFlight = false;
    if (c.closing || !active || c.generation != generation) {
      finishClosing(engine, c);
      return;
    }
    // 棋盘还在重建时，任何 play 行都属于上一局，直接丢弃；
    // 但要释放本轮，等同步完成后重新请求，否则整局会永远停在这一手。
    if (c.preparing) {
      movingEngine = null;
      status = "引擎重新同步，正在重试落子";
      return;
    }
    if (engine != movingEngine || c.generated || value.isEmpty()) return;
    // 落子行已经到了，这一手的 genmove 就算完成；引擎随后补发的空回执只当作多余回执吞掉。
    // 否则这条迟到回执会被当成“落子还没出现”，把下一手的 genmove 堵在队列里，整局永久停住。
    if (c.pending != null
        && c.pendingCommand != null
        && c.pendingCommand.contains("genmove")) {
      synchronized (c) {
        c.pending = null;
        c.pendingCommand = null;
        c.pendingSince = 0;
        c.skipReplies++;
        c.skipSince = System.nanoTime();
      }
    }
    String mv = value.trim().split("\\s+")[0];
    if (!mv.equalsIgnoreCase("pass")
        && !mv.equalsIgnoreCase("resign")
        && !mv.matches("[A-Za-z][0-9]{1,2}")) {
      retryTurn(engine, c, "引擎返回了无法识别的落子: " + value);
      return;
    }
    publishInfo(engine, c);
    if (paused) {
      c.result = mv;
      return;
    }
    c.generated = true;
    if (Lizzie.board.getHistory().getCurrentHistoryNode() != turnNode) {
      fail("引擎结果对应的局面已改变，请回到最新局面继续");
      return;
    }
    Seat seat = seatForTurn();
    Sample sample = liveSample;
    MoveData best = engine.pairBestMove();
    if (sample != null && best != null) {
      liveSample =
          new Sample(
              sample.moveNumber,
              sample.black,
              sample.seatName,
              sample.engineName,
              best,
              sample.hasScore,
              currentMoveMillis(),
              sample.visits);
    }
    // 引擎（尤其 KataGo 配置 allowResignation=true 时）会按自己的阈值直接回 resign，
    // 不能把这个回执直接当对局结束——否则联棋里设置的“手数≥N / 胜率<X / 连续M手”永远不生效。
    // 只有满足联棋设置才结束；否则让引擎改下它分析出的最佳点。
    boolean engineResigned = mv.equalsIgnoreCase("resign");
    boolean eligible =
        seat != null
            && sample != null
            && seat.resignConsec > 0
            && (sample.moveNumber - 1) >= seat.resignMinMove;
    if (eligible && (engineResigned || sample.winrate < seat.resignWinrate)) {
      seat.resignCounts++;
      if (seat.resignCounts >= seat.resignConsec) {
        finishResign(seat);
        return;
      }
    } else if (eligible) {
      seat.resignCounts = 0;
    }
    if (engineResigned) {
      MoveData bestMove = engine.pairBestMove();
      if (bestMove != null
          && bestMove.coordinate != null
          && !bestMove.coordinate.isEmpty()
          && bestMove.coordinate.matches("[A-Za-z][0-9]{1,2}")) {
        mv = bestMove.coordinate;
        status = "引擎建议认输，但未达到联棋认输条件，改下最佳点";
      } else {
        retryTurn(engine, c, "引擎认输，但没有可用的最佳点");
        return;
      }
    }
    applying = true;
    int before = turnNode.getData().moveNumber;
    try {
      if (mv.equalsIgnoreCase("pass")) Lizzie.board.pass();
      else {
        int[] xy = Board.convertNameToCoordinates(mv);
        if (xy != null && Board.isValid(xy[0], xy[1])) Lizzie.board.place(xy[0], xy[1]);
      }
    } finally {
      applying = false;
    }
    if (Lizzie.board.getHistory().getMoveNumber() != before + 1) {
      retryTurn(engine, c, "引擎返回了非法落子: " + mv);
      return;
    }
    BoardHistoryNode current = Lizzie.board.getHistory().getCurrentHistoryNode();
    recordMove(current);
    if (active) beginTurn(current);
    check();
    updateUi();
  }

  private static void finishResign(Seat seat) {
    boolean black = seat != null && blackSeats.contains(seat);
    Lizzie.board.getHistory().getGameInfo().setResult(black ? "W+R" : "B+R");
    status = (black ? "黑方" : "白方") + "认输";
    String message = status;
    stop();
    status = message;
    updateUi();
    Utils.showMsgNoModal("联棋：" + message);
  }

  public static void resign() {
    if (!active) return;
    finishResign(seatForTurn());
  }

  public static void togglePause() {
    if (!active) return;
    if (!paused) {
      paused = true;
      pauseStarted = System.nanoTime();
    } else {
      pausedNanos += System.nanoTime() - pauseStarted;
      paused = false;
      pauseStarted = 0;
      lastTick = System.nanoTime();
      if (movingEngine != null) {
        Channel c = channels.get(movingEngine);
        if (c != null && c.result != null) {
          String value = c.result;
          c.result = null;
          generated(movingEngine, c, value);
        }
      }
      check();
    }
    LizzieFrame.menu.setPairGameMode(true);
    updateUi();
  }

  private static void fail(String message) {
    status = message;
    if (active && !paused) {
      paused = true;
      pauseStarted = System.nanoTime();
    }
    updateUi();
    Utils.showMsgNoModal("联棋：" + message);
  }

  /**
   * 落子出错（引擎报错、返回非法点、思考超时）时不要直接暂停判死：
   * 把这台引擎整盘重同步后重试，最多 3 次，仍失败才停。
   */
  private static void retryTurn(Leelaz engine, Channel c, String reason) {
    if (!active) return;
    if (turnRetries >= 3) {
      fail(reason + "（已自动重试 3 次仍失败）");
      return;
    }
    turnRetries++;
    status = reason + "，正在重新同步引擎后重试（" + turnRetries + "/3）";
    movingEngine = null;
    if (c != null) {
      c.generated = false;
      c.inFlight = false;
      c.preparing = false;
      c.barrier = false;
      c.barrierNext = null;
      c.ready = false; // 让 tick 重新 prepare 这台引擎
      c.paramCache.clear();
      while (!c.queue.isEmpty()) {
        Req r = c.queue.pollFirst();
        try {
          r.reply.done(false, "retry");
        } catch (Exception e) {
          // ignore
        }
      }
    }
    if (engine != null && (!engine.isLoaded() || engine.isDownWithError)) {
      try {
        engine.startEngine(Lizzie.engineManager.engineList.indexOf(engine));
        status = "引擎已断开，正在重启后重试（" + turnRetries + "/3）";
      } catch (Exception e) {
        status = "引擎已断开，重启失败: " + e.getMessage();
      }
    }
    updateUi();
  }

  /**
   * 无人值守自测（仅 -Dpairgo.autotest=1 时启用）：自动开一局 1v1 AI 对 AI，
   * 30 秒后把局面进度写到 -Dpairgo.autotest.out 指定的文件并退出。
   * 用来在没有点击的条件下验证落子轮转、重试恢复和纯净模式。
   */
  private static boolean autotestStarted;

  public static void maybeRunAutotest() {
    if (!"1".equals(System.getProperty("pairgo.autotest"))) return;
    synchronized (PairGo.class) {
      if (autotestStarted) return;
      autotestStarted = true;
    }
    final String out = System.getProperty("pairgo.autotest.out", "pairgo-autotest.txt");
    final String seats = System.getProperty("pairgo.autotest.seats", "ai:0;ai:1");
    final int stopAt = Integer.getInteger("pairgo.autotest.stop", 0);
    final int runSeconds = Integer.getInteger("pairgo.autotest.seconds", 30);
    javax.swing.Timer boot =
        new javax.swing.Timer(
            5000,
            ev -> {
              try {
                String[] sides = seats.split(";", -1);
                List<Seat> black = autotestSeats(sides.length > 0 ? sides[0] : "ai:0");
                List<Seat> white = autotestSeats(sides.length > 1 ? sides[1] : "ai:1");
                pureMode = Boolean.getBoolean("pairgo.autotest.pure");
                final String testRules = System.getProperty("pairgo.autotest.rules", "");
                if (!testRules.isEmpty()) setRules(testRules);
                int testMode =
                    "prob".equalsIgnoreCase(System.getProperty("pairgo.autotest.mode", ""))
                        ? MODE_PROBABILITY
                        : MODE_SEQUENCE;
                int[] pct = {50, 50};
                String pv = System.getProperty("pairgo.autotest.prob", "");
                if (!pv.isEmpty()) {
                  String[] pp = pv.split(",");
                  if (pp.length > 0) pct[0] = clampPercent(parseSafeInt(pp[0], 50));
                  if (pp.length > 1) pct[1] = clampPercent(parseSafeInt(pp[1], 50));
                }
                long testSeed = Long.getLong("pairgo.autotest.seed", 0L);
                start(
                    black,
                    white,
                    Integer.getInteger("pairgo.autotest.handicap", 0),
                    false,
                    testMode,
                    pct[0],
                    pct[1],
                    testSeed);
                javax.swing.Timer human =
                    new javax.swing.Timer(
                        Integer.getInteger("pairgo.autotest.humanDelay", 600),
                        e -> autotestHumanMove());
                human.setRepeats(true);
                human.start();
                final int shotAt = Integer.getInteger("pairgo.autotest.shotAt", 0);
                final String shot = System.getProperty("pairgo.autotest.shot", "");
                if (shotAt > 0 && !shot.isEmpty()) {
                  javax.swing.Timer shooter =
                      new javax.swing.Timer(
                          shotAt * 1000,
                          e0 -> {
                            ((javax.swing.Timer) e0.getSource()).stop();
                            captureFrame(shot);
                            try {
                              java.io.PrintWriter tw =
                                  new java.io.PrintWriter(
                                      new java.io.FileWriter(shot + ".title.txt", false), true);
                              tw.println("title=" + Lizzie.frame.getTitle());
                              tw.println("seatCountText=" + seatMoveCountText());
                              tw.close();
                            } catch (Exception ex) {
                              // 自测附加信息写不出来不影响截图
                            }
                          });
                  shooter.setRepeats(false);
                  shooter.start();
                }
                final String second = System.getProperty("pairgo.autotest.second", "");
                final int komiAt = Integer.getInteger("pairgo.autotest.komiAt", 0);
                if (komiAt > 0) {
                  // 模拟用户在顶部改贴目：不结束对局，只让引擎按新贴目重同步。
                  javax.swing.Timer komiTimer =
                      new javax.swing.Timer(
                          komiAt * 1000,
                          evKomi -> {
                            ((javax.swing.Timer) evKomi.getSource()).stop();
                            if (!active) return;
                            double value =
                                Double.parseDouble(
                                    System.getProperty("pairgo.autotest.komiValue", "6.5"));
                            try {
                              Lizzie.leelaz.komiNoMenu(value);
                              Lizzie.board.getHistory().getGameInfo().changeKomi();
                              Lizzie.frame.refresh();
                            } catch (Exception ex) {
                              status = "改贴目失败: " + ex;
                            }
                          });
                  komiTimer.setRepeats(false);
                  komiTimer.start();
                }
                final int pauseAt = Integer.getInteger("pairgo.autotest.pauseAt", 0);
                final int rulesAt = Integer.getInteger("pairgo.autotest.rulesAt", 0);
                final String rulesValue = System.getProperty("pairgo.autotest.rulesValue", "");
                if (rulesAt > 0) {
                  // 默认用日本规则做自测（没有空格，方便命令行传参）。
                  final String value =
                      rulesValue.isEmpty()
                          ? "{\"scoring\":\"TERRITORY\",\"ko\":\"SIMPLE\",\"whiteHandicapBonus\":\"N\",\"suicide\":false,\"tax\":\"NONE\",\"hasButton\":false}"
                          : rulesValue;
                  javax.swing.Timer rulesTimer =
                      new javax.swing.Timer(
                          rulesAt * 1000,
                          evRules -> {
                            ((javax.swing.Timer) evRules.getSource()).stop();
                            if (active) setRules(value);
                          });
                  rulesTimer.setRepeats(false);
                  rulesTimer.start();
                }
                if (pauseAt > 0) {
                  // 验证“暂停 → 继续”不会把对局结束掉。
                  javax.swing.Timer pauser =
                      new javax.swing.Timer(
                          pauseAt * 1000,
                          evPause -> {
                            ((javax.swing.Timer) evPause.getSource()).stop();
                            togglePause();
                            LizzieFrame.menu.toggleDoubleMenuGameStatus();
                            javax.swing.Timer resumer =
                                new javax.swing.Timer(
                                    2500,
                                    evResume -> {
                                      ((javax.swing.Timer) evResume.getSource()).stop();
                                      togglePause();
                                      LizzieFrame.menu.toggleDoubleMenuGameStatus();
                                    });
                            resumer.setRepeats(false);
                            resumer.start();
                          });
                  pauser.setRepeats(false);
                  pauser.start();
                }
                if (stopAt > 0) {
                  javax.swing.Timer stopper =
                      new javax.swing.Timer(
                          stopAt * 1000,
                          e -> {
                            stop();
                            final int switchAt =
                                Integer.getInteger("pairgo.autotest.switchAt", -1);
                            final int switchIndex =
                                Integer.getInteger("pairgo.autotest.switchIndex", 2);
                            if (switchAt >= 0) {
                              dbg("AUTOTEST schedule switch index=" + switchIndex + " in " + switchAt);
                              switchTimer =
                                  new javax.swing.Timer(
                                      switchAt,
                                      evSw -> {
                                        ((javax.swing.Timer) evSw.getSource()).stop();
                                        try {
                                          dbg(
                                              "AUTOTEST switchEngine index="
                                                  + switchIndex
                                                  + " list="
                                                  + Lizzie.engineManager.engineList.size()
                                                  + " currentNo="
                                                  + EngineManager.currentEngineNo
                                                  + " main="
                                                  + engName(Lizzie.leelaz));
                                          Lizzie.engineManager.switchEngine(switchIndex, true);
                                          dbg("AUTOTEST switched main=" + engName(Lizzie.leelaz));
                                        } catch (Exception ex) {
                                          dbg("AUTOTEST switch failed " + ex);
                                        }
                                      });
                              switchTimer.setRepeats(false);
                              switchTimer.start();
                            }
                            final String shotAfter =
                                System.getProperty("pairgo.autotest.shotAfter", "");
                            if (!shotAfter.isEmpty()) {
                              javax.swing.Timer shutter =
                                  new javax.swing.Timer(
                                      Integer.getInteger("pairgo.autotest.shotAfterDelay", 1500),
                                      e3 -> {
                                        ((javax.swing.Timer) e3.getSource()).stop();
                                        captureFrame(shotAfter);
                                      });
                              shutter.setRepeats(false);
                              shutter.start();
                            }
                            if (second.isEmpty()) {
                              javax.swing.Timer report =
                                  new javax.swing.Timer(
                                      Integer.getInteger("pairgo.autotest.afterStop", 4000),
                                      e2 -> {
                                        writeAutotest(out, "stoppedAt=" + stopAt);
                                        System.exit(0);
                                      });
                              report.setRepeats(false);
                              report.start();
                              return;
                            }
                            javax.swing.Timer restart =
                                new javax.swing.Timer(
                                    Integer.getInteger("pairgo.autotest.secondDelay", 3000),
                                    e2 -> {
                                      String[] s2 = second.split(";", -1);
                                      start(
                                          autotestSeats(s2.length > 0 ? s2[0] : "ai:0"),
                                          autotestSeats(s2.length > 1 ? s2[1] : "ai:1"),
                                          0,
                                          false);
                                      javax.swing.Timer report =
                                          new javax.swing.Timer(
                                              Integer.getInteger(
                                                      "pairgo.autotest.secondSeconds", 15)
                                                  * 1000,
                                              e3 -> {
                                                writeAutotest(out, "secondGame=" + second);
                                                System.exit(0);
                                              });
                                      report.setRepeats(false);
                                      report.start();
                                    });
                            restart.setRepeats(false);
                            restart.start();
                          });
                  stopper.setRepeats(false);
                  stopper.start();
                } else {
                  javax.swing.Timer finish =
                      new javax.swing.Timer(
                          runSeconds * 1000,
                          e2 -> {
                            writeAutotest(out, "ranSeconds=" + runSeconds);
                            System.exit(0);
                          });
                  finish.setRepeats(false);
                  finish.start();
                }
              } catch (Throwable e) {
                e.printStackTrace();
                System.exit(2);
              }
            });
    boot.setRepeats(false);
    boot.start();
  }

  private static int parseSafeInt(String value, int def) {
    try {
      return Integer.parseInt(value.trim());
    } catch (Exception e) {
      return def;
    }
  }

  /** 自测座位描述：human 或 ai:引擎序号，多座位用逗号分隔，黑白用分号分隔。 */
  private static List<Seat> autotestSeats(String spec) {
    List<Seat> seats = new ArrayList<Seat>();
    if (spec == null || spec.trim().isEmpty()) return seats;
    for (String part : spec.split(",")) {
      String s = part.trim();
      if (s.isEmpty()) continue;
      Seat seat = new Seat();
      if (s.startsWith("ai")) {
        String[] bits = s.split(":");
        int index = 0;
        try {
          index = bits.length > 1 ? Integer.parseInt(bits[1].trim()) : 0;
        } catch (Exception e) {
          index = 0;
        }
        seat.isAi = true;
        seat.engineIndex = index;
        seat.name = "E" + index;
        seat.aiTimeSec = Integer.getInteger("pairgo.autotest.aitime", 2);
        int av = Integer.getInteger("pairgo.autotest.aiVisits", 0);
        if (av > 0) {
          seat.aiUseVisits = true;
          seat.aiVisits = av;
        }
        seat.resignMinMove =
            Integer.getInteger(
                "pairgo.autotest.resignMin" + index,
                Integer.getInteger("pairgo.autotest.resignMin", 150));
        seat.resignConsec =
            Integer.getInteger(
                "pairgo.autotest.resignConsec" + index,
                Integer.getInteger("pairgo.autotest.resignConsec", 3));
        try {
          seat.resignWinrate =
              Double.parseDouble(
                  System.getProperty(
                      "pairgo.autotest.resignRate" + index,
                      System.getProperty("pairgo.autotest.resignRate", "5")));
        } catch (Exception e) {
          seat.resignWinrate = 5;
        }
      } else {
        seat.isAi = false;
        seat.name = "人类";
        seat.humanTimeSec = Integer.getInteger("pairgo.autotest.humanTime", 30);
      }
      seats.add(seat);
    }
    return seats;
  }

  /** 自测用“人类”：轮到人类时随便找个空点落子，模拟真人点击。 */
  private static void autotestHumanMove() {
    if (!active || paused || !isHumanTurn()) return;
    if (Lizzie.board.getHistory().getCurrentHistoryNode() != turnNode) return;
    Stone color = Lizzie.board.getHistory().isBlacksTurn() ? Stone.BLACK : Stone.WHITE;
    for (int i = 0; i < 800; i++) {
      int x = (int) (Math.random() * Board.boardWidth);
      int y = (int) (Math.random() * Board.boardHeight);
      if (Lizzie.board.getData().stones[Board.getIndex(x, y)] == Stone.EMPTY) {
        Lizzie.board.place(x, y, color);
        return;
      }
    }
  }

  /** 自测截图：把当前主窗口截到指定文件。 */
  private static void captureFrame(final String path) {
    try {
      Lizzie.frame.toFront();
      Lizzie.frame.repaint();
    } catch (Exception e) {
      // ignore
    }
    javax.swing.Timer cap =
        new javax.swing.Timer(
            900,
            e1 -> {
              ((javax.swing.Timer) e1.getSource()).stop();
              try {
                // 直接渲染窗口内容，不依赖窗口是否被其它窗口遮挡。
                java.awt.image.BufferedImage img =
                    new java.awt.image.BufferedImage(
                        Math.max(1, Lizzie.frame.getWidth()),
                        Math.max(1, Lizzie.frame.getHeight()),
                        java.awt.image.BufferedImage.TYPE_INT_ARGB);
                java.awt.Graphics2D gg = img.createGraphics();
                Lizzie.frame.paintAll(gg);
                gg.dispose();
                javax.imageio.ImageIO.write(img, "png", new java.io.File(path));
              } catch (Exception ex) {
                // ignore
              }
            });
    cap.setRepeats(false);
    cap.start();
  }

  private static void writeAutotest(String out, String meta) {
    try {
      java.io.PrintWriter pw = new java.io.PrintWriter(new java.io.FileWriter(out, false), true);
      pw.println(meta);
      pw.println("pureMode=" + pureMode);
      pw.println("active=" + active);
      pw.println("mode=" + (mode == MODE_PROBABILITY ? "prob" : "seq"));
      pw.println("prob=" + probPercent[0] + "," + probPercent[1]);
      List<Seat> allSeatList = allSeats();
      int[] sc = seatMoveCounts();
      StringBuilder scb = new StringBuilder();
      for (int i = 0; i < allSeatList.size() && i < sc.length; i++) {
        if (i > 0) scb.append(',');
        scb.append(seatLabelFor(allSeatList.get(i))).append(':').append(sc[i]);
      }
      pw.println("seatCounts=" + scb);
      pw.println("seatCountText=" + seatMoveCountText());
      pw.println("paused=" + paused);
      pw.println(
          "moves=" + (Lizzie.board == null ? -1 : Lizzie.board.getHistory().getMoveNumber()));
      pw.println(
          "komi="
              + (Lizzie.board == null
                  ? "?"
                  : Lizzie.board.getHistory().getGameInfo().getKomi()));
      pw.println("status=" + status);
      pw.println("samples=" + history.size());
      pw.println("blackSeats=" + blackSeats.size());
      pw.println("whiteSeats=" + whiteSeats.size());
      pw.println("hasGameHistory=" + hasGameHistory());
      pw.println("pureDisplay=" + isPureDisplay());
      pw.println("pondering=" + (Lizzie.leelaz != null && Lizzie.leelaz.isPondering()));
      pw.println(
          "engineBest="
              + (Lizzie.leelaz == null || Lizzie.leelaz.getBestMoves() == null
                  ? -1
                  : Lizzie.leelaz.getBestMoves().size()));
      int best =
          Lizzie.board == null || Lizzie.board.getData() == null
              ? -1
              : (Lizzie.board.getData().bestMoves == null
                  ? -1
                  : Lizzie.board.getData().bestMoves.size());
      pw.println("bestMoves=" + best);
      TurnInfo ti = turnInfo();
      pw.println(
          "turn="
              + (ti == null
                  ? "null"
                  : ti.label
                      + "|ai="
                      + ti.ai
                      + "|data="
                      + ti.hasData
                      + "|wr="
                      + ti.winrate
                      + "|visits="
                      + ti.visits
                      + "|stdev="
                      + ti.scoreStdev));
      pw.println("saveName=" + Lizzie.board.getHistory().getGameInfo().getSaveFileName());
      try {
        featurecat.lizzie.rules.SGFParser.save(Lizzie.board, "pairgo-save-test.sgf");
        pw.println("sgf=ok");
      } catch (Throwable t) {
        pw.println("sgfErr=" + t);
      }
      pw.close();
    } catch (Exception e) {
      // 自测结果写不出来不影响进程退出
    }
  }

  /** 非本轮座位点击棋盘：完全静默，不提示、不改变任何状态。 */
  public static void hintHuman() {}

  public static void stop() {
    if (!SwingUtilities.isEventDispatchThread()) {
      SwingUtilities.invokeLater(() -> stop());
      return;
    }
    if (!active) return;
    lastMoveMillis = currentMoveMillis();
    try {
      frozenTurn = buildTurnInfo();
    } catch (Exception e) {
      frozenTurn = null;
    }
    // 结束瞬间先把“最后一手之后的真实判断”写到当前节点，左上角原生胜率条
    // 不会因为还没有新分析而退回到上一手/空盘面的旧值（用户看到的 ~99%）。
    try {
      if (frozenTurn != null && frozenTurn.hasData && Lizzie.board != null) {
        BoardData d = Lizzie.board.getHistory().getCurrentHistoryNode().getData();
        d.winrate = frozenTurn.winrate;
        d.scoreMean = frozenTurn.scoreMean;
        d.scoreStdev = frozenTurn.scoreStdev;
        d.setPlayouts(Math.max(1, frozenTurn.visits));
        d.isChanged = true;
      }
    } catch (Exception e) {
      // 写入失败不影响结束对局
    }
    active = false;
    paused = false;
    starting = false;
    status = "";
    pendingEngineStarts.clear();
    startingCloud.clear();
    cloudTries.clear();
    cloudSince.clear();
    startingEngine = null;
    currentKomi = Double.NaN;
    if (timer != null) {
      timer.stop();
      timer = null;
    }
    for (Map.Entry<Leelaz, Channel> entry : channels.entrySet()) {
      Channel c = entry.getValue();
      if (c.generation != generation) continue;
      c.closing = true;
      c.info = null;
      if (c.inFlight) {
        command(
            entry.getKey(),
            entry.getKey().isKatago ? "stop" : "name",
            (ok, value) -> {
              if (!c.inFlight) finishClosing(entry.getKey(), c);
            });
      } else {
        finishClosing(entry.getKey(), c);
      }
    }
    movingEngine = null;
    liveSample = null;
    if (namesOverridden) {
      Lizzie.config.showNameInBoard = savedNames;
      namesOverridden = false;
    }
    LizzieFrame.boardRenderer.changedName = true;
    LizzieFrame.menu.setPairGameMode(false);
    dbg("STOP original=" + engName(originalEngine) + " leelaz=" + engName(Lizzie.leelaz));
    // 不要盲目换回对局前的引擎：那台引擎可能根本没参与联棋、棋盘是空的，
    // 换回去之后原生分析对着空棋盘算，胜率面板会一直是空的。
    // 联棋用过的这台引擎棋谱是完整同步的，保留它才能立刻分析刚下完的局面。
    Leelaz lastPair = Lizzie.leelaz;
    boolean keepPairEngine =
        lastPair != null && lastPair.isLoaded() && lastPair != originalEngine;
    if (!keepPairEngine && originalEngine != null) {
      setMainEngine(originalEngine);
    } else {
      // 保留对局引擎时也要同步原生索引，否则用户马上换引擎复盘会停错对象。
      setMainEngine(lastPair);
    }
    try {
      Lizzie.frame.updateTitle();
      Lizzie.frame.reSetLoc();
    } catch (Exception e) {
      // 刷新失败不影响退出
    }
    // 结束即恢复：左侧统计/候选点按原生显示；但样本保留，胜率图继续画这盘联棋的曲线。
    moveLog.clear();
    liveSample = null;
    updateUi();
    scheduleNativeResume();
    // 结束对局后主动刷新两次（用户反馈要手动刷新胜率才恢复）：
    // 第一次切回正常布局，第二次等原生分析/重绘稳定后再刷一次。
    for (final int delay : new int[] {300, 1200}) {
      Timer refresh =
          new Timer(
              delay,
              e -> {
                ((Timer) e.getSource()).stop();
                try {
                  Lizzie.frame.reSetLoc();
                  Lizzie.frame.refresh();
                } catch (Exception ex) {
                  // 刷新失败不影响结束对局
                }
              });
      refresh.setRepeats(false);
      refresh.start();
    }
    // 兜底：引擎迟迟不结束时不把通道永久占住。
    if (!channels.isEmpty()) {
      if (closeTimer != null) closeTimer.stop();
      final long token = generation;
      closeTimer =
          new Timer(
              4000,
              e -> {
                ((Timer) e.getSource()).stop();
                if (active || token != generation) return; // 新一局已经开始，不能误关它的通道
                for (Map.Entry<Leelaz, Channel> entry :
                    new ArrayList<Map.Entry<Leelaz, Channel>>(channels.entrySet())) {
                  entry.getValue().closing = true;
                  entry.getValue().abandoned = true;
                  entry.getValue().inFlight = false;
                  restore(entry.getKey(), entry.getValue(), savedCommands(entry.getValue()), 0);
                }
              });
      closeTimer.setRepeats(false);
      closeTimer.start();
    }
  }

  private static List<String> savedCommands(Channel c) {
    List<String> restore = new ArrayList<String>();
    for (Map.Entry<String, String> p : c.saved.entrySet())
      restore.add("kata-set-param " + p.getKey() + " " + p.getValue());
    c.saved.clear();
    return restore;
  }

  private static void finishClosing(Leelaz engine, Channel c) {
    if (!c.closing || c.inFlight || c.restoring) return;
    while (!c.queue.isEmpty()) {
      Req r = c.queue.pollFirst();
      try {
        r.reply.done(false, "closed");
      } catch (Exception e) {
        // ignore
      }
    }
    if (c.abandoned) {
      // 旧一局遗留的通道：不要再回写参数，避免覆盖新一局的设置。
      channels.remove(engine, c);
      return;
    }
    c.restoring = true;
    restore(engine, c, savedCommands(c), 0);
  }

  private static void restore(Leelaz engine, Channel c, List<String> commands, int i) {
    if (c.generation != generation) {
      // 上一局的收尾命令还在慢慢回，通道已经被新一局替代，不能再往新通道里塞命令。
      channels.remove(engine, c);
      return;
    }
    if (i >= commands.size()) {
      channels.remove(engine, c);
      // 参数已还原，接着恢复原生分析，避免结束后胜率面板一直空白。
      if (!active && engine == Lizzie.leelaz) resumeNativeAnalysis();
      return;
    }
    command(engine, commands.get(i), (ok, value) -> restore(engine, c, commands, i + 1));
  }

  /**
   * 联棋结束后的收尾：把联棋清成空的 bestMoves 丢掉，让原生引擎重新分析当前局面。
   * 这样左侧胜率、目差、胜率图和候选表立刻回到普通对局的样子。
   */
  private static void scheduleNativeResume() {
    if (nativeResumeTimer != null) {
      nativeResumeTimer.stop();
      nativeResumeTimer = null;
    }
    nativeResumeCancelled = false;
    nativeResumeTimer =
        new Timer(
            1200,
            e -> {
              ((Timer) e.getSource()).stop();
              nativeResumeTimer = null;
              resumeNativeAnalysis();
            });
    nativeResumeTimer.setRepeats(false);
    nativeResumeTimer.start();
  }

  private static void resumeNativeAnalysis() {
    if (nativeResumeCancelled) return;
    if (active || Lizzie.frame == null || Lizzie.board == null) return;
    Leelaz engine = Lizzie.leelaz != null ? Lizzie.leelaz : originalEngine;
    if (engine == null || !engine.isLoaded()) return;
    if (Lizzie.frame.isPlayingAgainstLeelaz || Lizzie.frame.isAnaPlayingAgainstLeelaz) return;
    try {
      dbg(
          "RESUME engine="
              + engName(engine)
              + " pondering="
              + engine.isPondering()
              + " upToDate="
              + engine.isResponseUpToDate()
              + " best="
              + (engine.getBestMoves() == null ? -1 : engine.getBestMoves().size()));
      // 联棋期间原生命令的应答可能被拦截/消费，计数会落后；先对齐再重新分析。
      engine.setResponseUpToDate();
      engine.clearBestMoves();
      // 保留当前节点的联棋最后判断，等原生分析回来再覆盖；
      // 这里如果直接把 playouts 清 0，左上角胜率条会回退到上一手，出现 ~99% 的跳变。
      engine.ponder();
      dbg(
          "RESUME2 pondering="
              + engine.isPondering()
              + " upToDate="
              + engine.isResponseUpToDate()
              + " best="
              + (engine.getBestMoves() == null ? -1 : engine.getBestMoves().size())
              + " playing="
              + Lizzie.frame.isPlayingAgainstLeelaz
              + " playponder="
              + Lizzie.config.playponder);
      final Leelaz probeEngine = engine;
      Timer probe =
          new Timer(
              2500,
              ev -> {
                ((Timer) ev.getSource()).stop();
                dbg(
                    "RESUME4 best="
                        + (probeEngine.getBestMoves() == null
                            ? -1
                            : probeEngine.getBestMoves().size())
                        + " pondering="
                        + probeEngine.isPondering()
                        + " upToDate="
                        + probeEngine.isResponseUpToDate());
              });
      probe.setRepeats(false);
      probe.start();
      Lizzie.board.setForceRefresh(true);
      Lizzie.frame.refresh();
    } catch (Exception e) {
      // 恢复失败不影响其他界面
    }
  }

  /** 诊断：联棋结束后仍有非当前引擎在输出分析（会造成画面来回闪）。 */
  private static volatile long foreignSince;
  private static volatile int foreignCount;

  public static void noteForeignAnalysis(Leelaz engine) {
    foreignCount++;
    long now = System.nanoTime();
    if (foreignSince == 0) foreignSince = now;
    if (now - foreignSince > 1000000000L) {
      dbg(
          "FOREIGNINFO engine="
              + engName(engine)
              + " count="
              + foreignCount
              + " main="
              + engName(Lizzie.leelaz)
              + " pondering="
              + engine.isPondering());
      foreignCount = 0;
      foreignSince = now;
    }
  }

  private static void updateUi() {
    if (Lizzie.frame != null) Lizzie.frame.updatePairGoDisplay();
  }
}
