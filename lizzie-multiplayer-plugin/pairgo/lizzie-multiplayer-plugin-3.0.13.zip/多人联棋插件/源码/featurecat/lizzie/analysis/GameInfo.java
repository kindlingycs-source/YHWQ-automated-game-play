package featurecat.lizzie.analysis;

import featurecat.lizzie.Lizzie;
import featurecat.lizzie.gui.LizzieFrame;
import java.util.Date;

public class GameInfo {
  public static final String DEFAULT_NAME_CPU_PLAYER = "Computer";
  public static double DEFAULT_KOMI = 7.5;
  public boolean changedKomi = false;

  private String playerBlack = "";
  private String playerWhite = "";
  private Date date = new Date();
  private double komi = DEFAULT_KOMI;
  private int handicap = 0;
  private String result = "";

  public String getResult() {
    return result;
  }

  public void setResult(String result) {
    this.result = result;
    Lizzie.frame.setResult(result);
  }

  public String getPlayerBlack() {
    return playerBlack;
  }

  public Date getDate() {
    return date;
  }

  public void setDate(Date date) {
    this.date = date;
  }

  public void setPlayerBlack(String playerBlack) {
    this.playerBlack = playerBlack;
  }

  public String getPlayerWhite() {
    return playerWhite;
  }

  public String getSaveFileName() {
    if (playerBlack.equals("") && playerWhite.equals(""))
      return Lizzie.resourceBundle.getString("GameInfo.untitled");
    // 联棋的队名里带 " / " 之类字符，直接当文件名在 Windows 上是非法路径，
    // 会导致“保存失败”。这里统一把非法字符换成下划线。
    return sanitizeFileName(playerBlack + "_Vs_" + playerWhite);
  }

  private static String sanitizeFileName(String name) {
    if (name == null) return "";
    String cleaned = name.replaceAll("[\\\\/:*?\"<>|\\r\\n\\t]", "_");
    cleaned = cleaned.replace(" / ", "_").trim();
    return cleaned.isEmpty() ? Lizzie.resourceBundle.getString("GameInfo.untitled") : cleaned;
  }

  public void setPlayerWhite(String playerWhite) {
    this.playerWhite = playerWhite;
  }

  public double getKomi() {
    return komi;
  }

  public void setKomi(double komi) {
    this.komi = komi;
    LizzieFrame.menu.txtKomi.setText(String.valueOf(komi));
    if (Lizzie.frame.isInScoreMode) Lizzie.board.showGroupResult();
  }

  public void setKomiNoMenu(double komi) {
    this.komi = komi;
  }

  public void changeKomi() {
    changedKomi = true;
  }

  public int getHandicap() {
    return handicap;
  }

  public void setHandicap(int handicap) {
    this.handicap = handicap;
  }

  public void resetAllNoKomi() {
    this.handicap = 0;
    this.playerBlack = "";
    this.playerWhite = "";
    this.date = new Date();
    this.result = "";
    Lizzie.frame.setResult("");
  }
}
