package featurecat.lizzie.multi;

import org.json.JSONObject;

/** 一手棋（含停一手）。 */
public final class RoomMove {
  public int n = 0;
  public String seat = "";
  public boolean black = true;
  public int x = -1;
  public int y = -1;
  public boolean pass = false;
  public long ms = 0;

  public RoomMove() {}

  public RoomMove(int n, String seat, boolean black, int x, int y, boolean pass, long ms) {
    this.n = n;
    this.seat = seat;
    this.black = black;
    this.x = x;
    this.y = y;
    this.pass = pass;
    this.ms = ms;
  }

  public JSONObject toJson() {
    JSONObject o = new JSONObject();
    o.put("n", n);
    o.put("seat", seat);
    o.put("black", black);
    o.put("x", x);
    o.put("y", y);
    o.put("pass", pass);
    o.put("ms", ms);
    return o;
  }

  public static RoomMove fromJson(JSONObject o) {
    RoomMove m = new RoomMove();
    if (o == null) return m;
    m.n = o.optInt("n", 0);
    m.seat = o.optString("seat", "");
    m.black = o.optBoolean("black", true);
    m.x = o.optInt("x", -1);
    m.y = o.optInt("y", -1);
    m.pass = o.optBoolean("pass", false);
    m.ms = o.optLong("ms", 0);
    return m;
  }

  public String coordinate() {
    return pass ? "pass" : featurecat.lizzie.rules.Board.convertCoordinatesToName(x, y);
  }
}
