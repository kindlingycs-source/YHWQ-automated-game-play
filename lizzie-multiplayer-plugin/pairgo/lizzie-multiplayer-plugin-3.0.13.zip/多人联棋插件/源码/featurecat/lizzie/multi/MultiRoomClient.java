package featurecat.lizzie.multi;

import java.net.URI;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import javax.swing.SwingUtilities;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONObject;

/** 多人约战客户端。连接房主内嵌的房间服务，自动重连。 */
public final class MultiRoomClient extends WebSocketClient {
  public interface Listener {
    void onWelcome(int you, RoomState room);

    void onRoom(RoomState room);

    void onApplied(RoomMove move, RoomState room);

    void onEnd(String result, String reason, RoomState room);

    void onClosed(String reason);

    void onKicked();

    void onErrorMsg(String code, String msg);

    /** 连接掉了，正在重连（attempt 从 1 开始）。 */
    void onDisconnected(int attempt);
  }

  private final String clientId;
  private final String roomCode;
  private final String hostToken;
  private final Listener listener;
  private final Timer retryTimer = new Timer("multi-client-retry", true);
  private volatile boolean closedByUser;
  private volatile boolean fatal;
  private volatile boolean ended;
  private volatile boolean retryScheduled;
  private int attempts;
  private int playerId = -1;
  private RoomState room;
  private int lastN;

  public MultiRoomClient(
      URI uri, String clientId, String roomCode, String hostToken, Listener listener) {
    super(uri);
    this.clientId = clientId == null || clientId.isEmpty() ? UUID.randomUUID().toString() : clientId;
    this.roomCode = roomCode == null ? "" : roomCode;
    this.hostToken = hostToken == null ? "" : hostToken;
    this.listener = listener;
    setConnectionLostTimeout(10);
  }

  public static String newClientId() {
    return UUID.randomUUID().toString();
  }

  public int playerId() {
    return playerId;
  }

  public RoomState room() {
    return room;
  }

  public String clientId() {
    return clientId;
  }

  public void connectRoom() {
    try {
      connect();
    } catch (Exception e) {
      // onError / onClose 会走重试
    }
  }

  @Override
  public void onOpen(ServerHandshake handshake) {
    attempts = 0;
    retryScheduled = false;
    JSONObject o = new JSONObject();
    o.put("t", "hello");
    o.put("clientId", clientId);
    o.put("roomCode", roomCode);
    o.put("hostToken", hostToken);
    send(o.toString());
  }

  @Override
  public void onMessage(String message) {
    final JSONObject m;
    try {
      m = new JSONObject(message);
    } catch (Exception e) {
      return;
    }
    final String t = m.optString("t", "");
    SwingUtilities.invokeLater(
        new Runnable() {
          @Override
          public void run() {
            try {
              dispatch(t, m);
            } catch (Exception e) {
              // 忽略一条坏消息
            }
          }
        });
  }

  private void dispatch(String t, JSONObject m) {
    if ("welcome".equals(t)) {
      playerId = m.optInt("you", playerId);
      RoomState st = RoomState.fromJson(m.optJSONObject("room"));
      room = st;
      lastN = st.moves.size();
      if (listener != null) listener.onWelcome(playerId, st);
    } else if ("room".equals(t)) {
      RoomState st = RoomState.fromJson(m.optJSONObject("room"));
      if (st.phase.equals(RoomState.CLOSED)) {
        ended = true;
      }
      // room 广播不带 moves：保留本地棋谱
      if (room != null) st.moves.addAll(room.moves);
      room = st;
      if (listener != null) listener.onRoom(st);
    } else if ("applied".equals(t)) {
      RoomMove mv = RoomMove.fromJson(m.optJSONObject("move"));
      RoomState st = m.optJSONObject("room") == null ? null : RoomState.fromJson(m.optJSONObject("room"));
      if (st != null && room != null) st.moves.addAll(room.moves);
      if (st == null) st = room;
      if (st != null && mv.n > 0) {
        if (mv.n == st.moves.size() + 1) st.moves.add(mv);
        else if (mv.n <= st.moves.size()) st.moves.set(mv.n - 1, mv);
      }
      room = st;
      if (listener != null) listener.onApplied(mv, room);
    } else if ("end".equals(t)) {
      ended = true;
      RoomState st = m.optJSONObject("room") == null ? null : RoomState.fromJson(m.optJSONObject("room"));
      if (st != null && (st.moves.isEmpty()) && room != null) st.moves.addAll(room.moves);
      room = st == null ? room : st;
      if (listener != null) listener.onEnd(m.optString("result", ""), m.optString("reason", ""), room);
    } else if ("closed".equals(t)) {
      ended = true;
      if (listener != null) listener.onClosed(m.optString("reason", ""));
      close();
    } else if ("kicked".equals(t)) {
      fatal = true;
      if (listener != null) listener.onKicked();
      close();
    } else if ("error".equals(t)) {
      String code = m.optString("code", "");
      String msg = m.optString("msg", "");
      if ("started".equals(code) || "no-room".equals(code) || "full".equals(code)) fatal = true;
      if (listener != null) listener.onErrorMsg(code, msg);
    }
  }

  @Override
  public void onClose(int code, String reason, boolean remote) {
    if (closedByUser || fatal || ended) return;
    if (room != null && RoomState.CLOSED.equals(room.phase)) return;
    scheduleRetry();
  }

  @Override
  public void onError(Exception ex) {
    // onClose 里统一重试
  }

  private void scheduleRetry() {
    if (retryScheduled) return;
    if (attempts >= 10) {
      if (listener != null) listener.onDisconnected(attempts);
      return;
    }
    attempts++;
    retryScheduled = true;
    if (listener != null) listener.onDisconnected(attempts);
    retryTimer.schedule(
        new TimerTask() {
          @Override
          public void run() {
            retryScheduled = false;
            if (closedByUser || fatal || ended) return;
            try {
              reconnect();
            } catch (Exception e) {
              scheduleRetry();
            }
          }
        },
        2000L);
  }

  @Override
  public void close() {
    closedByUser = true;
    retryTimer.cancel();
    try {
      super.close();
    } catch (Exception e) {
      // ignore
    }
  }

  // ------------------------------------------------------------------ 发送

  private void sendMsg(JSONObject o) {
    try {
      if (isOpen()) send(o.toString());
    } catch (Exception e) {
      // ignore
    }
  }

  public void sendSit(String seat) {
    JSONObject o = new JSONObject();
    o.put("t", "sit");
    o.put("seat", seat);
    sendMsg(o);
  }

  public void sendReady(boolean ready) {
    JSONObject o = new JSONObject();
    o.put("t", "ready");
    o.put("ready", ready);
    sendMsg(o);
  }

  public void sendAddAi(String seat, int engineId, String engineName) {
    JSONObject o = new JSONObject();
    o.put("t", "addAi");
    o.put("seat", seat);
    o.put("engineId", engineId);
    o.put("engineName", engineName);
    sendMsg(o);
  }

  public void sendRemoveAi(String seat) {
    JSONObject o = new JSONObject();
    o.put("t", "removeAi");
    o.put("seat", seat);
    sendMsg(o);
  }

  public void sendMoveAi(String from, String to) {
    JSONObject o = new JSONObject();
    o.put("t", "moveAi");
    o.put("from", from);
    o.put("to", to);
    sendMsg(o);
  }

  public void sendEngineReady(String seat, boolean ok, String engineName, long ms) {
    JSONObject o = new JSONObject();
    o.put("t", "engineReady");
    o.put("seat", seat);
    o.put("ok", ok);
    o.put("engineName", engineName);
    o.put("ms", ms);
    sendMsg(o);
  }

  public void sendEngineDown(String seat) {
    JSONObject o = new JSONObject();
    o.put("t", "engineDown");
    o.put("seat", seat);
    sendMsg(o);
  }

  public void sendRules(RoomRules rules) {
    JSONObject o = new JSONObject();
    o.put("t", "setRules");
    o.put("rules", rules.toJson());
    sendMsg(o);
  }

  public void sendStart() {
    JSONObject o = new JSONObject();
    o.put("t", "start");
    sendMsg(o);
  }

  public void sendMove(String seat, int n, int x, int y, boolean pass, long ms) {
    JSONObject o = new JSONObject();
    o.put("t", "move");
    o.put("seat", seat);
    o.put("n", n);
    o.put("x", x);
    o.put("y", y);
    o.put("pass", pass);
    o.put("ms", ms);
    sendMsg(o);
  }

  public void sendResign(String seat) {
    JSONObject o = new JSONObject();
    o.put("t", "resign");
    o.put("seat", seat);
    sendMsg(o);
  }

  public void sendSkip(String seat) {
    JSONObject o = new JSONObject();
    o.put("t", "skip");
    o.put("seat", seat);
    sendMsg(o);
  }

  public void sendWait(String seat) {
    JSONObject o = new JSONObject();
    o.put("t", "wait");
    o.put("seat", seat);
    sendMsg(o);
  }

  public void sendEndGame() {
    JSONObject o = new JSONObject();
    o.put("t", "endGame");
    sendMsg(o);
  }

  public void sendKick(int playerId) {
    JSONObject o = new JSONObject();
    o.put("t", "kick");
    o.put("playerId", playerId);
    sendMsg(o);
  }

  public void sendTransferHost(int playerId) {
    JSONObject o = new JSONObject();
    o.put("t", "transferHost");
    o.put("playerId", playerId);
    sendMsg(o);
  }

  /** 退出房间（不是解散）：服务端会随机转让房主，只有全空才关闭。 */
  public void sendLeaveRoom() {
    JSONObject o = new JSONObject();
    o.put("t", "leave");
    sendMsg(o);
  }

  public void sendCloseRoom() {
    JSONObject o = new JSONObject();
    o.put("t", "leave");
    sendMsg(o);
  }

  public boolean isEnded() {
    return ended;
  }

  public boolean isFatal() {
    return fatal;
  }

  public String roomCode() {
    return roomCode;
  }

  public String hostToken() {
    return hostToken;
  }

  public int lastN() {
    return lastN;
  }
}
