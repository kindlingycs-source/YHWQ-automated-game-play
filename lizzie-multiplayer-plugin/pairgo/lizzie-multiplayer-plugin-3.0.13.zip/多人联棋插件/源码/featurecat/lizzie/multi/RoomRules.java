package featurecat.lizzie.multi;

import org.json.JSONObject;

/** 多人约战房间规则。所有非法输入在 sanitize() 里静默回落到默认值。 */
public final class RoomRules {
  public double komi = 7.5;
  public int handicap = 0;
  public int humanSec = 30;
  public boolean aiUseVisits = false;
  public int aiSec = 3;
  public int aiVisits = 10000;
  public boolean aiResign = true;
  public double aiResignWinrate = 3.0;
  public int aiResignConsec = 3;
  public int aiResignMinMove = 100;
  public String ruleSet = "chinese";

  public RoomRules copy() {
    RoomRules r = new RoomRules();
    r.komi = komi;
    r.handicap = handicap;
    r.humanSec = humanSec;
    r.aiUseVisits = aiUseVisits;
    r.aiSec = aiSec;
    r.aiVisits = aiVisits;
    r.aiResign = aiResign;
    r.aiResignWinrate = aiResignWinrate;
    r.aiResignConsec = aiResignConsec;
    r.aiResignMinMove = aiResignMinMove;
    r.ruleSet = ruleSet;
    return r;
  }

  public void sanitize() {
    if (Double.isNaN(komi) || Double.isInfinite(komi) || komi < -150 || komi > 150) komi = 7.5;
    if (handicap != 0 && (handicap < 2 || handicap > 9)) handicap = 0;
    if (humanSec < 1 || humanSec > 3600) humanSec = 30;
    if (aiSec < 1 || aiSec > 600) aiSec = 3;
    if (aiVisits < 1 || aiVisits > 10000000) aiVisits = 10000;
    if (aiResignWinrate < 0 || aiResignWinrate > 100) aiResignWinrate = 3.0;
    if (aiResignConsec < 1 || aiResignConsec > 20) aiResignConsec = 3;
    if (aiResignMinMove < 0 || aiResignMinMove > 1000) aiResignMinMove = 100;
    if (!"japanese".equals(ruleSet)) ruleSet = "chinese";
  }

  public JSONObject toJson() {
    JSONObject o = new JSONObject();
    o.put("komi", komi);
    o.put("handicap", handicap);
    o.put("humanSec", humanSec);
    o.put("aiUseVisits", aiUseVisits);
    o.put("aiSec", aiSec);
    o.put("aiVisits", aiVisits);
    o.put("aiResign", aiResign);
    o.put("aiResignWinrate", aiResignWinrate);
    o.put("aiResignConsec", aiResignConsec);
    o.put("aiResignMinMove", aiResignMinMove);
    o.put("ruleSet", ruleSet);
    return o;
  }

  public static RoomRules fromJson(JSONObject o) {
    RoomRules r = new RoomRules();
    if (o == null) return r;
    r.komi = o.optDouble("komi", 7.5);
    r.handicap = o.optInt("handicap", 0);
    r.humanSec = o.optInt("humanSec", 30);
    r.aiUseVisits = o.optBoolean("aiUseVisits", false);
    r.aiSec = o.optInt("aiSec", 3);
    r.aiVisits = o.optInt("aiVisits", 10000);
    r.aiResign = o.optBoolean("aiResign", true);
    r.aiResignWinrate = o.optDouble("aiResignWinrate", 3.0);
    r.aiResignConsec = o.optInt("aiResignConsec", 3);
    r.aiResignMinMove = o.optInt("aiResignMinMove", 100);
    r.ruleSet = o.optString("ruleSet", "chinese");
    r.sanitize();
    return r;
  }
}
