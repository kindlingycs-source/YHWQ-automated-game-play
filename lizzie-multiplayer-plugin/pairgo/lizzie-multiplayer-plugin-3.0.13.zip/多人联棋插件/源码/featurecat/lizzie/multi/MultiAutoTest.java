package featurecat.lizzie.multi;

import featurecat.lizzie.Lizzie;
import featurecat.lizzie.analysis.EngineManager;
import java.io.File;
import java.io.PrintWriter;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import javax.swing.SwingUtilities;

/**
 * 多人约战 GUI 自测：真 Lizzie + 真引擎（testenv fake GTP）。
 * -Dmulti.autotest=1 启动，约 8 秒后自动开房、进一个测试客户端、挂一个 AI 座位、下几手、存谱，写结果并退出。
 */
public final class MultiAutoTest {
  private static final Object LOCK = new Object();
  private static String out = "multi-autotest.out";
  private static volatile StringBuilder details = new StringBuilder();
  private static long startedAt;

  private MultiAutoTest() {}

  public static void maybeRun() {
    final String uiTest = System.getProperty("multi.uitest", "");
    if (!uiTest.isEmpty()) {
      Thread t =
          new Thread(
              new Runnable() {
                public void run() {
                  runUiTest(uiTest);
                }
              },
              "multi-ui-test");
      t.setDaemon(true);
      t.start();
      return;
    }
    if (!"1".equals(System.getProperty("multi.autotest", ""))) return;
    out = System.getProperty("multi.autotest.out", "multi-autotest.out");
    Thread t =
        new Thread(
            new Runnable() {
              public void run() {
                try {
                  Thread.sleep(8000);
                } catch (InterruptedException e) {
                  return;
                }
                runTest();
              }
            },
            "multi-autotest");
    t.setDaemon(true);
    t.start();
  }

  /** 只截准备窗口的 UI 自测：-Dmulti.uitest=join|host -Dmulti.uitest.shot=<png>。 */
  private static void runUiTest(final String mode) {
    try {
      Thread.sleep(6000);
      final MultiRoomDialog[] holder = new MultiRoomDialog[1];
      SwingUtilities.invokeAndWait(
          new Runnable() {
            public void run() {
              holder[0] =
                  new MultiRoomDialog(
                      Lizzie.frame,
                      "host".equals(mode)
                          || "popup".equals(mode)
                          || "engine".equals(mode)
                          || "uncheck".equals(mode)
                          || "guest".equals(mode)
                          || "start".equals(mode));
              holder[0].setVisible(true);
            }
          });
      Thread.sleep(1200);
      final MultiRoomDialog d = holder[0];
      if ("join".equals(mode) || "code".equals(mode)) {
        SwingUtilities.invokeAndWait(
            new Runnable() {
              public void run() {
                try {
                  java.lang.reflect.Field f =
                      MultiRoomDialog.class.getDeclaredField("joinCode");
                  f.setAccessible(true);
                  javax.swing.JTextField[] code = (javax.swing.JTextField[]) f.get(d);
                  for (int i = 0; i < code.length; i++) {
                    log(
                        "code box "
                            + i
                            + " size="
                            + code[i].getSize()
                            + " pref="
                            + code[i].getPreferredSize());
                  }
                } catch (Exception e) {
                  e.printStackTrace();
                }
              }
            });
      }
      if ("code".equals(mode)) {
        SwingUtilities.invokeAndWait(
            new Runnable() {
              public void run() {
                try {
                  java.lang.reflect.Field f =
                      MultiRoomDialog.class.getDeclaredField("joinCode");
                  f.setAccessible(true);
                  final javax.swing.JTextField[] code =
                      (javax.swing.JTextField[]) f.get(d);
                  code[0].setText("a");
                  log("code after a='" + code[0].getText() + "'");
                  code[0].setText("1");
                  log("code after 1='" + code[0].getText() + "'");
                  code[1].setText("x");
                  log("code after x='" + code[1].getText() + "'");
                  code[1].setText("2");
                  log("code after 2='" + code[1].getText() + "'");
                  log(
                      "code text="
                          + code[0].getText()
                          + code[1].getText()
                          + code[2].getText()
                          + code[3].getText());
                } catch (Exception e) {
                  e.printStackTrace();
                }
              }
            });
        Thread.sleep(400);
        SwingUtilities.invokeAndWait(
            new Runnable() {
              public void run() {
                try {
                  java.awt.image.BufferedImage img =
                      new java.awt.image.BufferedImage(
                          d.getWidth(),
                          d.getHeight(),
                          java.awt.image.BufferedImage.TYPE_INT_ARGB);
                  java.awt.Graphics2D g = img.createGraphics();
                  d.paintAll(g);
                  g.dispose();
                  String shot =
                      System.getProperty("multi.uitest.shot", "multi-ui-code.png");
                  javax.imageio.ImageIO.write(img, "png", new File(shot));
                  log("ui test code shot=" + shot);
                } catch (Exception e) {
                  e.printStackTrace();
                }
              }
            });
        System.exit(0);
      }
      if ("start".equals(mode)) {
        SwingUtilities.invokeLater(
            new Runnable() {
              public void run() {
                try {
                  java.lang.reflect.Method m =
                      MultiRoomDialog.class.getDeclaredMethod("startGame");
                  m.setAccessible(true);
                  m.invoke(d);
                } catch (Exception e) {
                  e.printStackTrace();
                }
              }
            });
        Thread.sleep(700);
        SwingUtilities.invokeAndWait(
            new Runnable() {
              public void run() {
                try {
                  for (java.awt.Window w : java.awt.Window.getWindows()) {
                    javax.swing.JOptionPane pane = findOptionPane(w);
                    if (pane != null) {
                      log("start message=" + pane.getMessage());
                      break;
                    }
                  }
                } catch (Exception e) {
                  e.printStackTrace();
                }
              }
            });
        System.exit(0);
      }
      if ("guest".equals(mode)) {
        SwingUtilities.invokeAndWait(
            new Runnable() {
              public void run() {
                try {
                  java.lang.reflect.Field hostField =
                      MultiGame.class.getDeclaredField("host");
                  hostField.setAccessible(true);
                  hostField.set(MultiGame.INSTANCE, false);
                  d.refresh(MultiGame.INSTANCE.room());
                  java.lang.reflect.Field komiField =
                      MultiRoomDialog.class.getDeclaredField("komi");
                  java.lang.reflect.Field blockerField =
                      MultiRoomDialog.class.getDeclaredField("rulesBlocker");
                  komiField.setAccessible(true);
                  blockerField.setAccessible(true);
                  javax.swing.JTextField komi = (javax.swing.JTextField) komiField.get(d);
                  javax.swing.JPanel blocker = (javax.swing.JPanel) blockerField.get(d);
                  java.awt.Point p =
                      SwingUtilities.convertPoint(
                          komi,
                          komi.getWidth() / 2,
                          komi.getHeight() / 2,
                          d.getContentPane());
                  java.awt.Component deep =
                      SwingUtilities.getDeepestComponentAt(d.getContentPane(), p.x, p.y);
                  log(
                      "guest blockerVisible="
                          + blocker.isVisible()
                          + " deepest="
                          + (deep == null ? "null" : deep.getClass().getName())
                          + " isBlocker="
                          + (deep == blocker));
                } catch (Exception e) {
                  e.printStackTrace();
                }
              }
            });
        Thread.sleep(300);
      }
      if ("uncheck".equals(mode)) {
        SwingUtilities.invokeAndWait(
            new Runnable() {
              public void run() {
                try {
                  java.lang.reflect.Field f1 =
                      MultiRoomDialog.class.getDeclaredField("aiUseVisits");
                  java.lang.reflect.Field f2 =
                      MultiRoomDialog.class.getDeclaredField("aiResign");
                  f1.setAccessible(true);
                  f2.setAccessible(true);
                  javax.swing.JCheckBox visits = (javax.swing.JCheckBox) f1.get(d);
                  javax.swing.JCheckBox resign = (javax.swing.JCheckBox) f2.get(d);
                  if (visits.isSelected()) visits.doClick();
                  if (resign.isSelected()) resign.doClick();
                } catch (Exception e) {
                  e.printStackTrace();
                }
              }
            });
        Thread.sleep(300);
      }
      if ("engine".equals(mode)) {
        SwingUtilities.invokeLater(
            new Runnable() {
              public void run() {
                try {
                  java.lang.reflect.Method m =
                      MultiRoomDialog.class.getDeclaredMethod("addAi", String.class);
                  m.setAccessible(true);
                  m.invoke(d, "B2");
                } catch (Exception e) {
                  e.printStackTrace();
                }
              }
            });
        Thread.sleep(1800);
        SwingUtilities.invokeAndWait(
            new Runnable() {
              public void run() {
                try {
                  java.awt.Window target = null;
                  for (java.awt.Window w : java.awt.Window.getWindows()) {
                    if (w.isShowing()
                        && w instanceof javax.swing.JDialog
                        && "选择 AI 引擎".equals(((javax.swing.JDialog) w).getTitle())) {
                      target = w;
                      break;
                    }
                  }
                  java.awt.Robot robot = new java.awt.Robot();
                  java.awt.Rectangle r =
                      target == null
                          ? new java.awt.Rectangle(0, 0, 900, 600)
                          : target.getBounds();
                  java.awt.image.BufferedImage img = robot.createScreenCapture(r);
                  String shot = System.getProperty("multi.uitest.shot", "multi-ui-engine.png");
                  javax.imageio.ImageIO.write(img, "png", new File(shot));
                  log(
                      "ui test engine shot="
                          + shot
                          + " dialog="
                          + r
                          + " found="
                          + (target != null));
                } catch (Exception e) {
                  e.printStackTrace();
                }
              }
            });
        System.exit(0);
      }
      if ("popup".equals(mode)) {
        final javax.swing.JButton[] btn = new javax.swing.JButton[1];
        SwingUtilities.invokeAndWait(
            new Runnable() {
              public void run() {
                btn[0] = findButton(d, "黑②");
                d.toFront();
                if (btn[0] != null) {
                  java.awt.Point p = new java.awt.Point(40, 30);
                  btn[0].dispatchEvent(
                      new java.awt.event.MouseEvent(
                          btn[0],
                          java.awt.event.MouseEvent.MOUSE_PRESSED,
                          System.currentTimeMillis(),
                          0,
                          p.x,
                          p.y,
                          1,
                          false,
                          java.awt.event.MouseEvent.BUTTON1));
                  btn[0].doClick();
                }
              }
            });
        Thread.sleep(900);
        SwingUtilities.invokeAndWait(
            new Runnable() {
              public void run() {
                try {
                  java.awt.Robot robot = new java.awt.Robot();
                  java.awt.Rectangle r = d.getBounds();
                  java.awt.image.BufferedImage img =
                      robot.createScreenCapture(
                          new java.awt.Rectangle(r.x - 30, r.y - 30, r.width + 60, r.height + 60));
                  String shot = System.getProperty("multi.uitest.shot", "multi-ui-popup.png");
                  javax.imageio.ImageIO.write(img, "png", new File(shot));
                  log("ui test popup shot=" + shot + " dialog=" + d.getBounds());
                } catch (Exception e) {
                  e.printStackTrace();
                }
              }
            });
        System.exit(0);
      }
      SwingUtilities.invokeAndWait(
          new Runnable() {
            public void run() {
              try {
                java.awt.image.BufferedImage img =
                    new java.awt.image.BufferedImage(
                        d.getWidth(), d.getHeight(), java.awt.image.BufferedImage.TYPE_INT_ARGB);
                java.awt.Graphics2D g = img.createGraphics();
                d.paintAll(g);
                g.dispose();
                String shot =
                    System.getProperty("multi.uitest.shot", "multi-ui-" + mode + ".png");
                javax.imageio.ImageIO.write(img, "png", new File(shot));
                log("ui test shot=" + shot + " size=" + d.getWidth() + "x" + d.getHeight());
              } catch (Exception e) {
                e.printStackTrace();
              }
            }
          });
      System.exit(0);
    } catch (Throwable t) {
      t.printStackTrace();
      System.exit(1);
    }
  }

  private static void log(String s) {
    details.append(s).append('\n');
    System.out.println("[multi-autotest] " + s);
  }

  private static void fail(String s) {
    log("FAIL: " + s);
    try {
      RoomState r = MultiGame.INSTANCE.room();
      if (r != null) log("room=" + r.toJson(true).toString());
    } catch (Exception e) {
      // ignore
    }
    write("FAIL\n" + details);
    System.exit(1);
  }

  private static void write(String s) {
    try {
      PrintWriter w =
          new PrintWriter(
              new java.io.OutputStreamWriter(
                  new java.io.FileOutputStream(out), StandardCharsets.UTF_8));
      w.print(s);
      w.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private static void waitUntil(BooleanSupplier cond, long timeoutMs, String what) {
    long end = System.currentTimeMillis() + timeoutMs;
    while (System.currentTimeMillis() < end) {
      if (cond.getAsBoolean()) return;
      try {
        Thread.sleep(100);
      } catch (InterruptedException e) {
        return;
      }
    }
    fail("timeout: " + what);
  }

  private static void runTest() {
    try {
      startedAt = System.currentTimeMillis();
      File saveDir = new File("save").getAbsoluteFile();
      saveDir.mkdirs();
      try {
        Lizzie.config.persisted
            .getJSONObject("filesystem")
            .put("last-folder", saveDir.getAbsolutePath());
      } catch (Exception e) {
        log("set last-folder failed: " + e.getMessage());
      }
      log("start host");
      MultiGame game = MultiGame.INSTANCE;
      game.setUi(null);
      if (!game.startHost()) fail("startHost failed");
      waitUntil(
          new BooleanSupplier() {
            public boolean getAsBoolean() {
              return game.myPlayerId() > 0 && game.room() != null;
            }
          },
          10000,
          "host welcome");
      final MultiRoomServer server = game.server();
      final MultiRoomClient host = game.client();
      if (server == null || host == null) fail("no server/client");
      log("room=" + server.code() + " port=" + server.port());
      final String rule = System.getProperty("multi.autotest.rule", "");
      if (!rule.isEmpty()) {
        featurecat.lizzie.multi.RoomRules rr = game.room().rules.copy();
        rr.ruleSet = rule;
        host.sendRules(rr);
        waitUntil(
            new BooleanSupplier() {
              public boolean getAsBoolean() {
                return game.room() != null && rule.equals(game.room().rules.ruleSet);
              }
            },
            5000,
            "rules " + rule);
        log("rule=" + rule);
      }

      // 选一台不是当前主引擎的引擎做 AI
      int main = EngineManager.currentEngineNo;
      if (main < 0 && Lizzie.leelaz != null && Lizzie.engineManager.engineList != null) {
        main = Lizzie.engineManager.engineList.indexOf(Lizzie.leelaz);
      }
      log("mainEngine=" + main + " engines=" + Lizzie.engineManager.engineList.size());
      int engineIndex = -1;
      String engineName = "AI";
      for (int i = Lizzie.engineManager.engineList.size() - 1; i >= 0; i--) {
        if (i == main) continue;
        if (Lizzie.engineManager.engineList.get(i) == Lizzie.leelaz) continue;
        engineIndex = i;
        engineName = Lizzie.engineManager.getEngineName(i);
        break;
      }
      if (engineIndex < 0) fail("no free engine for AI seat");
      log("add AI B2 engineIndex=" + engineIndex + " name=" + engineName);
      host.sendAddAi("B2", engineIndex, engineName);
      waitUntil(
          new BooleanSupplier() {
            public boolean getAsBoolean() {
              RoomSeat s = game.room() == null ? null : game.room().seat("B2");
              return s != null && s.isAi() && s.ready && s.online;
            }
          },
          45000,
          "AI engine self-check");
      log("AI ready");

      final AutoJoiner aj = new AutoJoiner();
      MultiRoomClient joiner =
          new MultiRoomClient(
              URI.create("ws://127.0.0.1:" + server.port()),
              MultiRoomClient.newClientId(),
              server.code(),
              "",
              aj);
      joiner.connectRoom();
      waitUntil(
          new BooleanSupplier() {
            public boolean getAsBoolean() {
              return aj.you > 0 && aj.room != null;
            }
          },
          10000,
          "joiner welcome");
      log("joiner=" + aj.you);

      host.sendReady(true);
      joiner.sendReady(true);
      waitUntil(
          new BooleanSupplier() {
            public boolean getAsBoolean() {
              RoomState r = game.room();
              return r != null && r.startReady();
            }
          },
          10000,
          "startReady");
      host.sendStart();
      waitUntil(
          new BooleanSupplier() {
            public boolean getAsBoolean() {
              RoomState r = game.room();
              return r != null && RoomState.PLAYING.equals(r.phase);
            }
          },
          10000,
          "phase PLAYING");
      waitUntil(
          new BooleanSupplier() {
            public boolean getAsBoolean() {
              return game.isActive();
            }
          },
          5000,
          "game active");
      log("game started");
      if (Lizzie.config.showCaptured
          || Lizzie.config.showWinrateGraph
          || Lizzie.config.showSubBoard
          || Lizzie.config.showVariationGraph
          || Lizzie.config.showListPane) {
        fail("analysis panels not hidden");
      }
      if (!Lizzie.config.showCoordinates) fail("coordinates not on");
      if (featurecat.lizzie.gui.LizzieFrame.toolbar != null
          && featurecat.lizzie.gui.LizzieFrame.toolbar.isVisible()) {
        fail("toolbar still visible");
      }
      log("layout hidden: captured/winrate/subboard/variation/listpane=false, coordinates=true");

      host.sendMove("B1", 1, 3, 3, false, 0);
      waitUntil(
          new BooleanSupplier() {
            public boolean getAsBoolean() {
              return game.room() != null && game.room().moves.size() >= 1;
            }
          },
          5000,
          "move 1");
      joiner.sendMove("W1", 2, 15, 15, false, 0);
      waitUntil(
          new BooleanSupplier() {
            public boolean getAsBoolean() {
              return game.room() != null && game.room().moves.size() >= 2;
            }
          },
          5000,
          "move 2");
      waitUntil(
          new BooleanSupplier() {
            public boolean getAsBoolean() {
              RoomState r = game.room();
              return r != null
                  && r.moves.size() >= 3
                  && "B2".equals(r.moves.get(r.moves.size() - 1).seat);
            }
          },
          30000,
          "AI B2 move");
      RoomState st = game.room();
      log("AI move n=" + st.moves.get(st.moves.size() - 1).n + " " + st.moves.get(st.moves.size() - 1).coordinate());

      // 当前轮到 W1：双方连续停一手结束
      joiner.sendMove("W1", 4, -1, -1, true, 0);
      waitUntil(
          new BooleanSupplier() {
            public boolean getAsBoolean() {
              return game.room() != null && game.room().moves.size() >= 4;
            }
          },
          5000,
          "pass 4");
      host.sendMove("B1", 5, -1, -1, true, 0);
      waitUntil(
          new BooleanSupplier() {
            public boolean getAsBoolean() {
              RoomState r = game.room();
              return r != null && RoomState.ENDED.equals(r.phase);
            }
          },
          10000,
          "ENDED");
      log("ended result=" + game.room().result + " reason=" + game.room().endReason);

      // 等自动存谱
      final File finalSave = saveDir;
      File[] sgf = null;
      long end = System.currentTimeMillis() + 6000;
      while (System.currentTimeMillis() < end) {
        sgf =
            finalSave.listFiles(
                new java.io.FileFilter() {
                  public boolean accept(File f) {
                    return f.isFile()
                        && f.getName().toLowerCase(Locale.ROOT).endsWith(".sgf")
                        && f.lastModified() > startedAt - 5000;
                  }
                });
        if (sgf != null && sgf.length > 0) break;
        Thread.sleep(200);
      }
      if (sgf == null || sgf.length == 0) fail("no SGF auto-saved");
      File newest = sgf[0];
      for (File f : sgf) if (f.lastModified() > newest.lastModified()) newest = f;
      log("sgf=" + newest.getAbsolutePath() + " size=" + newest.length());
      if (newest.length() <= 0) fail("SGF empty");
      waitUntil(
          new BooleanSupplier() {
            public boolean getAsBoolean() {
              return !game.isActive();
            }
          },
          5000,
          "restore after end");
      log("restored: active=false");
      write("PASS\n" + details);
      log("PASS");
      System.exit(0);
    } catch (Throwable t) {
      t.printStackTrace();
      fail("exception: " + t);
    }
  }

  private static javax.swing.JOptionPane findOptionPane(java.awt.Component c) {
    if (c instanceof javax.swing.JOptionPane) return (javax.swing.JOptionPane) c;
    if (c instanceof java.awt.Container) {
      for (java.awt.Component k : ((java.awt.Container) c).getComponents()) {
        javax.swing.JOptionPane p = findOptionPane(k);
        if (p != null) return p;
      }
    }
    return null;
  }

  private static javax.swing.JButton findButton(java.awt.Component c, String text) {
    if (c instanceof javax.swing.JButton) {
      String s = ((javax.swing.JButton) c).getText();
      if (s != null && s.contains(text)) return (javax.swing.JButton) c;
    }
    if (c instanceof java.awt.Container) {
      for (java.awt.Component k : ((java.awt.Container) c).getComponents()) {
        javax.swing.JButton b = findButton(k, text);
        if (b != null) return b;
      }
    }
    return null;
  }

  private static final class AutoJoiner implements MultiRoomClient.Listener {
    volatile int you;
    volatile RoomState room;

    public void onWelcome(int id, RoomState s) {
      you = id;
      room = s;
    }

    public void onRoom(RoomState s) {
      room = s;
    }

    public void onApplied(RoomMove m, RoomState s) {
      room = s;
    }

    public void onEnd(String result, String reason, RoomState s) {
      room = s;
    }

    public void onClosed(String reason) {}

    public void onKicked() {}

    public void onErrorMsg(String code, String msg) {
      System.out.println("[multi-autotest] joiner error " + code + " " + msg);
    }

    public void onDisconnected(int attempt) {}
  }
}
