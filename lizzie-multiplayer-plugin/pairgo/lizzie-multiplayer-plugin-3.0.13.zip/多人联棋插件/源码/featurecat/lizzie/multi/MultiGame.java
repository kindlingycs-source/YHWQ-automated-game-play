package featurecat.lizzie.multi;

import featurecat.lizzie.Lizzie;
import featurecat.lizzie.analysis.GameInfo;
import featurecat.lizzie.analysis.PairGo;
import featurecat.lizzie.gui.LizzieFrame;
import featurecat.lizzie.rules.Board;
import featurecat.lizzie.rules.SGFParser;
import featurecat.lizzie.rules.Stone;
import featurecat.lizzie.util.Utils;
import java.io.File;
import java.net.ServerSocket;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Optional;
import javax.swing.SwingUtilities;
import org.json.JSONObject;

/**
 * 多人约战本地控制器：连接/房间/棋盘/输入/保存。
 *
 * <p>和本地联棋（PairGo）完全独立；这里只调用棋盘和保存的公共能力，不改本地联棋逻辑。
 */
public final class MultiGame implements MultiRoomClient.Listener, MultiRoomServer.Listener {
  public static final MultiGame INSTANCE = new MultiGame();

  public interface Ui {
    void refresh(RoomState room);

    void status(String text);

    void error(String text);

    void closed(String reason);
  }

  private Ui ui;
  private MultiRoomServer server;
  private MultiRoomClient client;
  private volatile RoomState room;
  private int myPlayerId = -1;
  private String myHumanSeat = "";
  private volatile boolean active;
  private boolean host;
  private boolean ended;
  private boolean restored;

  // 进入对局前的本机设置，结束后恢复
  private boolean origNoCapture;
  private boolean origShowName;
  private boolean origShowCoordinates;
  private boolean origShowMoveNumber;
  private int origOnlyLastMoveNumber;
  private int origAllowMoveNumber;
  private boolean origCanSuicidal;
  private boolean origPlaying;
  private boolean origAnaPlaying;

  private MultiSeatBar seatBar;

  private MultiGame() {}

  public void setUi(Ui ui) {
    this.ui = ui;
  }

  public RoomState room() {
    return room;
  }

  public int myPlayerId() {
    return myPlayerId;
  }

  public String myHumanSeat() {
    return myHumanSeat;
  }

  public boolean isActive() {
    return active;
  }

  public boolean isHost() {
    return host;
  }

  public MultiRoomClient client() {
    return client;
  }

  public MultiRoomServer server() {
    return server;
  }

  public boolean isMyTurn() {
    return active
        && !ended
        && room != null
        && RoomState.PLAYING.equals(room.phase)
        && !myHumanSeat.isEmpty()
        && myHumanSeat.equals(room.turnSeat);
  }

  // ------------------------------------------------------------------ 开房 / 进房

  public boolean startHost() {
    resetForNewRoom();
    try {
      String clientId = MultiRoomClient.newClientId();
      String hostToken = MultiRoomClient.newClientId();
      int port = freePort();
      server = new MultiRoomServer(port, clientId, hostToken);
      server.setListener(this);
      if (!server.startServer()) {
        error("房间服务启动失败");
        return false;
      }
      client =
          new MultiRoomClient(
              URI.create("ws://127.0.0.1:" + port),
              clientId,
              server.code(),
              hostToken,
              this);
      client.connectRoom();
      return true;
    } catch (Exception e) {
      error("开房失败：" + e.getMessage());
      return false;
    }
  }

  public void join(String host, int port, String code) {
    resetForNewRoom();
    try {
      client =
          new MultiRoomClient(
              URI.create("ws://" + host + ":" + port),
              MultiRoomClient.newClientId(),
              code,
              "",
              this);
      client.connectRoom();
    } catch (Exception e) {
      error("进房失败：" + e.getMessage());
    }
  }

  private static int freePort() throws Exception {
    ServerSocket s = new ServerSocket(0);
    int p = s.getLocalPort();
    s.close();
    return p;
  }

  private void resetForNewRoom() {
    active = false;
    ended = false;
    restored = false;
    host = false;
    myPlayerId = -1;
    myHumanSeat = "";
    room = null;
  }

  public void closeAll() {
    try {
      if (client != null) client.close();
    } catch (Exception e) {
      // ignore
    }
    try {
      if (server != null) server.stop();
    } catch (Exception e) {
      // ignore
    }
    client = null;
    server = null;
  }

  /**
   * 只退出当前客户端，不主动停掉自己机器上的房间服务。
   * 房主退出后，服务端会把房主随机转让给还在线的玩家；
   * 只有所有人都离开/掉线时，服务端才自己关闭。
   */
  public void leaveRoom() {
    MultiRoomClient c = client;
    client = null;
    if (c != null) {
      try {
        c.close();
      } catch (Exception e) {
        // ignore
      }
    }
    host = false;
    myPlayerId = -1;
    myHumanSeat = "";
    if (server == null) {
      room = null;
      ended = false;
      restored = false;
    }
  }

  // ------------------------------------------------------------------ 客户端回调

  @Override
  public void onWelcome(int you, RoomState st) {
    myPlayerId = you;
    publish(st);
  }

  @Override
  public void onRoom(RoomState st) {
    publish(st);
  }

  @Override
  public void onApplied(RoomMove mv, RoomState st) {
    RoomState copy = st;
    if (copy == null) return;
    if (active) {
      applyMove(mv);
      publish(copy);
    } else {
      publish(copy);
    }
  }

  @Override
  public void onEnd(String result, String reason, RoomState st) {
    if (!SwingUtilities.isEventDispatchThread()) {
      SwingUtilities.invokeLater(
          new Runnable() {
            public void run() {
              onEnd(result, reason, st);
            }
          });
      return;
    }
    if (st != null) room = st;
    ended = true;
    if (active) {
      endAndSave(result, reason);
    }
    if (ui != null) ui.refresh(room);
  }

  @Override
  public void onClosed(String reason) {
    if (!SwingUtilities.isEventDispatchThread()) {
      SwingUtilities.invokeLater(
          new Runnable() {
            public void run() {
              onClosed(reason);
            }
          });
      return;
    }
    if (active) {
      endAndSave("", "房间关闭：" + reason);
    }
    if (ui != null) ui.closed(reason);
  }

  @Override
  public void onKicked() {
    if (!SwingUtilities.isEventDispatchThread()) {
      SwingUtilities.invokeLater(
          new Runnable() {
            public void run() {
              onKicked();
            }
          });
      return;
    }
    if (active) restore();
    if (ui != null) ui.closed("你被房主移出了房间");
    client = null;
  }

  @Override
  public void onErrorMsg(String code, String msg) {
    if (ui != null) ui.error(msg);
  }

  @Override
  public void onDisconnected(int attempt) {
    if (ui != null) ui.status("连接断开，正在重连 " + attempt + "/10…");
  }

  // ------------------------------------------------------------------ 服务端回调（只用于房主本地）

  // 注：MultiRoomServer.Listener 与 MultiRoomClient.Listener 的 onRoom/onClosed
  // 签名相同，上面已经实现；这里不再重复定义。

  // ------------------------------------------------------------------ 状态刷新 / 开局

  private void publish(final RoomState st) {
    if (st == null) return;
    Runnable r =
        new Runnable() {
          @Override
          public void run() {
            room = st;
            host = room.hostId == myPlayerId;
            RoomSeat hs = room.humanSeatOf(myPlayerId);
            myHumanSeat = hs == null ? "" : hs.id;
            if (RoomState.PLAYING.equals(room.phase) && !active && !ended) beginGame();
            if (seatBar != null) seatBar.refresh(room);
            if (ui != null) ui.refresh(room);
            featurecat.lizzie.analysis.MultiEngine.sync(room, myPlayerId, client);
          }
        };
    if (SwingUtilities.isEventDispatchThread()) r.run();
    else SwingUtilities.invokeLater(r);
  }

  private void beginGame() {
    if (active) return;
    active = true;
    savedSettings();
    try {
      Lizzie.frame.isPlayingAgainstLeelaz = false;
      Lizzie.frame.isAnaPlayingAgainstLeelaz = false;
      Lizzie.config.noCapture = false;
      if (Lizzie.leelaz != null) Lizzie.leelaz.canSuicidal = false;
      setupBoard();
      enterGameLayout();
      seatBar = new MultiSeatBar(this);
      seatBar.showBar();
      // 重连进来时把已有棋谱补上
      for (RoomMove m : room.moves) applyMove(m);
      startMyAiSeats();
      applyTitle();
      Lizzie.frame.refresh();
    } catch (Exception e) {
      error("进入对局失败：" + e.getMessage());
    }
  }

  private void savedSettings() {
    origNoCapture = Lizzie.config.noCapture;
    origShowName = Lizzie.config.showNameInBoard;
    origShowCoordinates = Lizzie.config.showCoordinates;
    origShowMoveNumber = Lizzie.config.showMoveNumber;
    origOnlyLastMoveNumber = Lizzie.config.onlyLastMoveNumber;
    origAllowMoveNumber = Lizzie.config.allowMoveNumber;
    origCanSuicidal = Lizzie.leelaz == null ? false : Lizzie.leelaz.canSuicidal;
    origPlaying = Lizzie.frame.isPlayingAgainstLeelaz;
    origAnaPlaying = Lizzie.frame.isAnaPlayingAgainstLeelaz;
  }

  private void setupBoard() {
    int handicap = room.rules.handicap;
    double komi = room.rules.komi;
    Lizzie.board.clear(false);
    GameInfo gi = Lizzie.board.getHistory().getGameInfo();
    gi.setKomi(komi);
    gi.setHandicap(handicap >= 2 ? handicap : 0);
    if (Lizzie.leelaz != null) {
      // 只影响界面上的规则显示；AI 引擎由 MultiEngine 单独发 kata-set-rules。
      Lizzie.leelaz.usingSpecificRules = "japanese".equals(room.rules.ruleSet) ? 3 : 1;
    }
    if (handicap >= 2) {
      int[][] points = PairGo.handicapPoints(handicap);
      for (int[] pt : points) Lizzie.board.place(pt[0], pt[1], Stone.BLACK);
      Lizzie.board.flatten();
      if (Lizzie.board.startStonelist == null) {
        Lizzie.board.startStonelist = new java.util.ArrayList<featurecat.lizzie.rules.Movelist>();
      } else {
        Lizzie.board.startStonelist.clear();
      }
      Lizzie.board.hasStartStone = true;
      for (int[] pt : points) Lizzie.board.setStartListStone(pt, true);
      if (Lizzie.board.getData() != null) Lizzie.board.getData().blackToPlay = false;
    }
    Lizzie.config.showNameInBoard = true;
    Lizzie.config.showCoordinates = true;
    gi.setPlayerBlack(room.sideLine(true));
    gi.setPlayerWhite(room.sideLine(false));
    try {
      Lizzie.frame.setPlayers(room.sideLine(false), room.sideLine(true));
    } catch (Exception e) {
      // 标题失败不影响对局
    }
    LizzieFrame.boardRenderer.changedName = true;
  }

  private void applyMove(RoomMove m) {
    if (m == null) return;
    Stone color = m.black ? Stone.BLACK : Stone.WHITE;
    if (m.pass) {
      Lizzie.board.pass(color);
    } else {
      Lizzie.board.place(m.x, m.y, color, false, true, false);
    }
    if (Lizzie.leelaz != null) {
      Lizzie.leelaz.clearBestMoves();
      Lizzie.leelaz.notPondering();
    }
    applyTitle();
  }

  public void onBoardClicked(int screenX, int screenY) {
    if (!isMyTurn()) return;
    Optional<int[]> coords = LizzieFrame.boardRenderer.convertScreenToCoordinates(screenX, screenY);
    if (!coords.isPresent()) return;
    int[] c = coords.get();
    if (!Board.isValid(c) || Lizzie.board.hasStoneAt(c)) return;
    int n = room.moves.size() + 1;
    client.sendMove(myHumanSeat, n, c[0], c[1], false, 0);
  }

  public void sendPass() {
    if (!isMyTurn()) return;
    int n = room.moves.size() + 1;
    client.sendMove(myHumanSeat, n, -1, -1, true, 0);
  }

  public void sendResign() {
    if (myHumanSeat.isEmpty()) return;
    client.sendResign(myHumanSeat);
  }

  public void hostSkip(String seat) {
    if (client != null) client.sendSkip(seat);
  }

  public void hostWait(String seat) {
    if (client != null) client.sendWait(seat);
  }

  public void hostEnd() {
    if (client != null) client.sendEndGame();
  }

  public void cycleMoveNumbers() {
    if (Lizzie.config.allowMoveNumber == 0) Lizzie.config.allowMoveNumber = 1;
    else if (Lizzie.config.allowMoveNumber == 1) Lizzie.config.allowMoveNumber = -1;
    else Lizzie.config.allowMoveNumber = 0;
    Lizzie.frame.refresh();
  }

  public void applyTitle() {
    if (room == null) return;
    String turn = room.turnSeat.isEmpty() ? "" : room.seat(room.turnSeat) == null ? "" : room.seat(room.turnSeat).display();
    String s =
        "多人约战 房间"
            + room.code
            + " · 第"
            + (room.moves.size() + 1)
            + "手"
            + (turn.isEmpty() ? "" : " · 轮到 " + turn);
    try {
      Lizzie.frame.setTitle(s);
    } catch (Exception e) {
      // ignore
    }
  }

  // ------------------------------------------------------------------ 结束 / 恢复 / 保存

  private void endAndSave(String result, String reason) {
    if (restored) return;
    if (room != null) {
      room.result = result == null ? "" : result;
      room.endReason = reason == null ? "" : reason;
    }
    String res = result == null || result.isEmpty() ? "终局" : result;
    try {
      Lizzie.board.getHistory().getGameInfo().setResult(res);
    } catch (Exception e) {
      // ignore
    }
    saveSgf(res);
    if (seatBar != null) seatBar.refresh(room);
    applyTitle();
    restore();
  }

  private void saveSgf(String result) {
    try {
      if (Lizzie.board.getHistory().getMoveNumber() <= 0) return;
      JSONObject fs = Lizzie.config.persisted.getJSONObject("filesystem");
      String folder = fs.optString("last-folder", "");
      if (folder == null || folder.isEmpty()) folder = System.getProperty("user.home", ".");
      File dir = new File(folder);
      if (!dir.exists()) dir.mkdirs();
      String base = Lizzie.board.getHistory().getGameInfo().getSaveFileName();
      if (base == null || base.isEmpty()) base = "多人约战_" + (room == null ? "" : room.code);
      String ts = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(new Date());
      File file = new File(dir, base + "_" + ts + ".sgf");
      SGFParser.save(Lizzie.board, file.getAbsolutePath());
      fs.put("last-folder", dir.getAbsolutePath());
      if (ui != null) ui.status("已自动保存棋谱：" + file.getAbsolutePath());
      Utils.showMsgNoModal("已自动保存棋谱：" + file.getAbsolutePath());
    } catch (Exception e) {
      if (ui != null) ui.status("自动保存棋谱失败：" + e.getMessage());
    }
  }

  public void restore() {
    if (!SwingUtilities.isEventDispatchThread()) {
      SwingUtilities.invokeLater(
          new Runnable() {
            public void run() {
              restore();
            }
          });
      return;
    }
    if (restored) return;
    restored = true;
    active = false;
    try {
      Lizzie.config.noCapture = origNoCapture;
      Lizzie.config.showNameInBoard = origShowName;
      Lizzie.config.showCoordinates = origShowCoordinates;
      Lizzie.config.showMoveNumber = origShowMoveNumber;
      Lizzie.config.onlyLastMoveNumber = origOnlyLastMoveNumber;
      Lizzie.config.allowMoveNumber = origAllowMoveNumber;
      if (Lizzie.leelaz != null) Lizzie.leelaz.canSuicidal = origCanSuicidal;
      Lizzie.frame.isPlayingAgainstLeelaz = origPlaying;
      Lizzie.frame.isAnaPlayingAgainstLeelaz = origAnaPlaying;
    } catch (Exception e) {
      // ignore
    }
    exitGameLayout();
    if (seatBar != null) {
      seatBar.disposeBar();
      seatBar = null;
    }
    try {
      Lizzie.frame.refresh();
      Lizzie.frame.updateTitle();
    } catch (Exception e) {
      // ignore
    }
    stopMyAiSeats();
  }

  // 多人约战布局：一次性收起左右分析面板，结束恢复（不在每帧改可见性）
  private void enterGameLayout() {
    try {
      Lizzie.frame.enterMultiLayout();
      LizzieFrame.toolbar.updatePairPanel();
    } catch (Exception e) {
      // ignore
    }
  }

  private void exitGameLayout() {
    try {
      LizzieFrame.toolbar.updatePairPanel();
      Lizzie.frame.exitMultiLayout();
    } catch (Exception e) {
      // ignore
    }
  }

  // ------------------------------------------------------------------ AI 座位（下一步接入）

  private void startMyAiSeats() {
    featurecat.lizzie.analysis.MultiEngine.sync(room, myPlayerId, client);
  }

  private void stopMyAiSeats() {
    featurecat.lizzie.analysis.MultiEngine.closeSession();
  }

  private void maybeRunAiTurn() {
    featurecat.lizzie.analysis.MultiEngine.sync(room, myPlayerId, client);
  }

  private void error(String msg) {
    if (ui != null) ui.error(msg);
  }
}
