package featurecat.lizzie.multi;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.json.JSONObject;

/**
 * 房主端的房间服务（局域网 v1 内嵌在房主 Lizzie 里）。
 *
 * <p>服务端只负责房间、座位、手番、序号、计时、结果；不跑 AI、不实现围棋规则。
 * 落子合法性由落子端的 Board 判定，服务端只查手番/序号。
 */
public final class MultiRoomServer extends WebSocketServer {
  public static final int PROTO = 1;

  public interface Listener {
    void onRoom(RoomState room);

    void onClosed(String reason);
  }

  private final Object lock = new Object();
  private final RoomState room = new RoomState();
  private final Map<WebSocket, Integer> connPlayer = new HashMap<WebSocket, Integer>();
  private final Map<Integer, WebSocket> playerConn = new HashMap<Integer, WebSocket>();
  private final String hostClientId;
  private final String hostToken;
  private boolean hostTransferred;
  private final CountDownLatch started = new CountDownLatch(1);
  private final Timer timer = new Timer("multi-room-timer", true);
  private TimerTask timeoutTask;
  private MultiDiscovery.Host discovery;
  private Listener listener;
  private volatile boolean closed;
  private String closeReason = "";

  public MultiRoomServer(int port, String hostClientId, String hostToken) {
    super(new InetSocketAddress(port));
    this.hostClientId = hostClientId == null ? "" : hostClientId;
    this.hostToken = hostToken == null ? "" : hostToken;
    setReuseAddr(true);
    setConnectionLostTimeout(10);
    room.code = randomCode();
    room.phase = RoomState.LOBBY;
    // 房主先存在，保证房主永远是 玩家1。
    RoomPlayer host = new RoomPlayer(1, this.hostClientId);
    host.host = true;
    host.online = false;
    room.players.add(host);
    room.hostId = 1;
    room.nextPlayerId = 2;
  }

  public void setListener(Listener l) {
    listener = l;
  }

  public RoomState room() {
    return room;
  }

  public String code() {
    return room.code;
  }

  public int port() {
    return getPort();
  }

  /** 启动并准备局域网发现；返回 false 表示服务端没起来。 */
  public boolean startServer() {
    try {
      start();
      if (!started.await(3, TimeUnit.SECONDS)) return false;
      discovery = new MultiDiscovery.Host();
      if (discovery.start(room.code, getPort())) {
        // 局域网内同号重取（最多试 5 次）
        for (int i = 0; i < 5; i++) {
          if (!discovery.claimCollision(room.code, 400)) break;
          room.code = randomCode();
          discovery.setCode(room.code);
        }
      } else {
        discovery = null;
      }
      return true;
    } catch (Exception e) {
      closeReason = "服务端启动失败: " + e.getMessage();
      return false;
    }
  }

  public static String randomCode() {
    int n = 1 + new Random().nextInt(9999);
    return String.format(Locale.ROOT, "%04d", n);
  }

  private void setPhase(String phase) {
    room.phase = phase;
    if (discovery != null) discovery.setPhase(phase);
  }

  @Override
  public void onStart() {
    started.countDown();
  }

  @Override
  public void onOpen(WebSocket conn, ClientHandshake handshake) {
    // 等 hello
  }

  @Override
  public void onClose(WebSocket conn, int code, String reason, boolean remote) {
    synchronized (lock) {
      Integer pid = connPlayer.remove(conn);
      if (pid == null) return;
      playerConn.remove(pid);
      playerGone(pid);
    }
  }

  /**
   * 一个玩家掉线/主动退出：
   * - 准备阶段直接移除，房主走了就随机转让；
   * - 对局中保留座位标记离线，暂停由新房主决定跳过/等待；
   * - 只有玩家全空或全离线才关闭房间。
   */
  private void playerGone(int pid) {
    RoomPlayer p = room.player(pid);
    if (p == null) return;
    if (RoomState.LOBBY.equals(room.phase)) {
      removePlayer(pid);
      if (closed) return;
      if (room.players.isEmpty()) {
        closeRoom("房间已空");
        return;
      }
      broadcastRoom();
      return;
    }
    if (RoomState.ENDED.equals(room.phase) || RoomState.CLOSED.equals(room.phase)) return;
    // 对局中：该成员所有座位离线，暂停，房主决定跳过/等待。
    p.online = false;
    for (RoomSeat s : room.seats)
      if (s.playerId == pid && !s.isEmpty()) {
        s.online = false;
        s.ready = false;
      }
    setPhase(RoomState.PAUSED);
    cancelTimeout();
    if (room.hostId == pid) {
      transferHost();
      if (closed) return;
    }
    if (room.hasAllHumansOffline()) {
      closeRoom("全部玩家掉线");
      return;
    }
    broadcastRoom();
  }

  @Override
  public void onMessage(WebSocket conn, String message) {
    JSONObject m;
    try {
      m = new JSONObject(message);
    } catch (Exception e) {
      return;
    }
    String t = m.optString("t", "");
    synchronized (lock) {
      try {
        if ("hello".equals(t)) {
          handleHello(conn, m);
          return;
        }
        Integer pid = connPlayer.get(conn);
        if (pid == null) return;
        if ("sit".equals(t)) handleSit(pid, m);
        else if ("addAi".equals(t)) handleAddAi(pid, m);
        else if ("removeAi".equals(t)) handleRemoveAi(pid, m);
        else if ("moveAi".equals(t)) handleMoveAi(pid, m);
        else if ("engineReady".equals(t)) handleEngineReady(pid, m);
        else if ("ready".equals(t)) handleReady(pid, m);
        else if ("setRules".equals(t)) handleSetRules(pid, m);
        else if ("start".equals(t)) handleStart(pid);
        else if ("move".equals(t)) handleMove(pid, m);
        else if ("resign".equals(t)) handleResign(pid, m);
        else if ("skip".equals(t)) handleSkip(pid, m);
        else if ("wait".equals(t)) handleWait(pid, m);
        else if ("endGame".equals(t)) handleEndGame(pid);
        else if ("kick".equals(t)) handleKick(pid, m);
        else if ("transferHost".equals(t)) handleTransferHost(pid, m);
        else if ("engineDown".equals(t)) handleEngineDown(pid, m);
        else if ("close".equals(t) || "leave".equals(t)) handleClose(pid);
      } catch (Exception e) {
        error(conn, "bad", e.getMessage() == null ? "请求失败" : e.getMessage());
      }
    }
  }

  @Override
  public void onError(WebSocket conn, Exception ex) {
    // 连接级错误由 onClose 收尾；服务端错误保留在 closeReason。
    if (conn == null && ex != null) closeReason = String.valueOf(ex.getMessage());
  }

  // ------------------------------------------------------------------ hello / 座位

  private void handleHello(WebSocket conn, JSONObject m) {
    String clientId = m.optString("clientId", "");
    String roomCode = m.optString("roomCode", "");
    String token = m.optString("hostToken", "");
    if (clientId.isEmpty()) {
      error(conn, "bad", "缺少 clientId");
      return;
    }
    if (!roomCode.isEmpty() && !roomCode.equals(room.code)) {
      error(conn, "no-room", "房间不存在");
      return;
    }
    boolean isHost = !hostTransferred && !hostToken.isEmpty() && hostToken.equals(token);
    RoomPlayer p = room.playerByClientId(clientId);
    if (p == null && isHost) {
      p = room.player(1);
      if (p != null) p.clientId = clientId;
    }
    if (p == null) {
      if (!RoomState.LOBBY.equals(room.phase)) {
        error(conn, "started", "对局已经开始，不能进入房间");
        return;
      }
      if (emptySeat() == null) {
        error(conn, "full", "房间已满");
        return;
      }
      int id = room.nextPlayerId++;
      p = new RoomPlayer(id, clientId);
      room.players.add(p);
    }
    p.online = true;
    if (isHost) {
      p.host = true;
      room.hostId = p.id;
    }
    connPlayer.put(conn, p.id);
    playerConn.put(p.id, conn);
    // 该成员的座位恢复在线
    for (RoomSeat s : room.seats)
      if (s.playerId == p.id && !s.isEmpty()) s.online = true;
    // 准备阶段必须坐一个真人座位
    if (RoomState.LOBBY.equals(room.phase) && room.humanSeatOf(p.id) == null) {
      RoomSeat s = emptySeat();
      if (s == null) {
        error(conn, "full", "没有空座位");
        return;
      }
      s.kind = RoomSeat.HUMAN;
      s.playerId = p.id;
      s.name = p.name;
      s.online = true;
      s.ready = false;
    }
    JSONObject w = new JSONObject();
    w.put("t", "welcome");
    w.put("you", p.id);
    w.put("proto", PROTO);
    w.put("room", room.toJson(true));
    send(conn, w);
    if (RoomState.PAUSED.equals(room.phase) && !room.hasWaitingSeat()) {
      setPhase(RoomState.PLAYING);
      beginTurn(false);
    }
    broadcastRoom();
  }

  private RoomSeat emptySeat() {
    // 黑白交替坐：B1 W1 B2 W2 B3 W3
    String[] order = {"B1", "W1", "B2", "W2", "B3", "W3"};
    for (String id : order) {
      RoomSeat s = room.seat(id);
      if (s != null && s.isEmpty()) return s;
    }
    return null;
  }

  private void handleSit(int pid, JSONObject m) {
    if (!RoomState.LOBBY.equals(room.phase)) {
      error(pid, "phase", "开局后不能换座位");
      return;
    }
    RoomSeat target = room.seat(m.optString("seat", ""));
    if (target == null || !target.isEmpty()) {
      error(pid, "seat", "这个座位不能坐");
      return;
    }
    RoomPlayer p = room.player(pid);
    if (p == null) return;
    RoomSeat old = room.humanSeatOf(pid);
    if (old != null) old.clear();
    target.kind = RoomSeat.HUMAN;
    target.playerId = pid;
    target.name = p.name;
    target.online = p.online;
    target.ready = false;
    p.ready = false;
    broadcastRoom();
  }

  private void handleAddAi(int pid, JSONObject m) {
    if (!RoomState.LOBBY.equals(room.phase)) {
      error(pid, "phase", "开局后不能加 AI");
      return;
    }
    RoomSeat target = room.seat(m.optString("seat", ""));
    if (target == null || !target.isEmpty()) {
      error(pid, "seat", "这个座位不能放 AI");
      return;
    }
    String engineName = m.optString("engineName", "AI");
    int engineId = m.optInt("engineId", -1);
    if (engineId >= 0) {
      for (RoomSeat s : room.seats) {
        if (s.isAi() && s.playerId == pid && s.engineId == engineId) {
          error(pid, "engine", "不能添加相同引擎进行对局");
          return;
        }
      }
    }
    target.kind = RoomSeat.AI;
    target.playerId = pid;
    target.name = "AI";
    target.engineId = engineId;
    target.engineName = engineName;
    target.online = true;
    target.ready = false;
    target.checking = true;
    broadcastRoom();
  }

  private void handleRemoveAi(int pid, JSONObject m) {
    if (!RoomState.LOBBY.equals(room.phase)) return;
    RoomSeat s = room.seat(m.optString("seat", ""));
    if (s == null || !s.isAi() || s.playerId != pid) {
      error(pid, "seat", "只能移除自己的 AI");
      return;
    }
    s.clear();
    broadcastRoom();
  }

  private void handleMoveAi(int pid, JSONObject m) {
    if (!RoomState.LOBBY.equals(room.phase)) return;
    RoomSeat from = room.seat(m.optString("from", ""));
    RoomSeat to = room.seat(m.optString("to", ""));
    if (from == null || to == null || !from.isAi() || from.playerId != pid || !to.isEmpty()) {
      error(pid, "seat", "不能移动这个 AI");
      return;
    }
    to.kind = RoomSeat.AI;
    to.playerId = pid;
    to.name = from.name;
    to.engineId = from.engineId;
    to.engineName = from.engineName;
    to.online = from.online;
    to.ready = from.ready;
    to.checking = from.checking;
    from.clear();
    broadcastRoom();
  }

  private void handleEngineReady(int pid, JSONObject m) {
    RoomSeat s = room.seat(m.optString("seat", ""));
    if (s == null || !s.isAi() || s.playerId != pid) return;
    boolean ok = m.optBoolean("ok", false);
    s.checking = false;
    s.ready = ok;
    s.online = ok;
    if (m.has("engineName")) s.engineName = m.optString("engineName", s.engineName);
    broadcastRoom();
  }

  private void handleEngineDown(int pid, JSONObject m) {
    RoomSeat s = room.seat(m.optString("seat", ""));
    if (s == null || !s.isAi() || s.playerId != pid) return;
    s.online = false;
    s.ready = false;
    if (!RoomState.LOBBY.equals(room.phase)) {
      setPhase(RoomState.PAUSED);
      cancelTimeout();
      broadcastRoom();
    }
  }

  private void handleReady(int pid, JSONObject m) {
    if (!RoomState.LOBBY.equals(room.phase)) return;
    RoomPlayer p = room.player(pid);
    if (p == null) return;
    RoomSeat seat = room.humanSeatOf(pid);
    if (seat == null) {
      error(pid, "seat", "先坐一个座位");
      return;
    }
    boolean ready = m.optBoolean("ready", false);
    p.ready = ready;
    seat.ready = ready;
    broadcastRoom();
  }

  private void handleSetRules(int pid, JSONObject m) {
    if (room.hostId != pid) {
      error(pid, "host", "只有房主能改规则");
      return;
    }
    if (!RoomState.LOBBY.equals(room.phase)) return;
    RoomRules nr = RoomRules.fromJson(m.optJSONObject("rules"));
    room.rules = nr;
    for (RoomPlayer p : room.players) p.ready = false;
    for (RoomSeat s : room.seats) if (s.isHuman()) s.ready = false;
    broadcastRoom();
  }

  // ------------------------------------------------------------------ 开局 / 落子

  private void handleStart(int pid) {
    if (room.hostId != pid) {
      error(pid, "host", "只有房主能开始");
      return;
    }
    if (!RoomState.LOBBY.equals(room.phase)) return;
    if (!room.startReady()) {
      error(pid, "start", startBlockedReason());
      return;
    }
    room.moves.clear();
    room.result = "";
    room.endReason = "";
    room.blackCount = 0;
    room.whiteCount = 0;
    // 让子局：黑方已摆让子，白方先走。
    room.blackToPlay = room.rules.handicap < 2;
    setPhase(RoomState.PLAYING);
    beginTurn(false);
    broadcastRoom();
  }

  private String startBlockedReason() {
    if (room.humanCount() < 2) return "至少需要 2 个真人";
    if (!room.sideHasOnlineSeat(true) || !room.sideHasOnlineSeat(false)) return "每方至少要有 1 个座位";
    if (!room.allPlayersSeated()) return "还有玩家没有坐座位";
    if (!room.allPlayersReady()) return "还有玩家没有准备";
    if (!room.allAiReady()) return "还有 AI 引擎没有自检通过";
    return "还不能开始";
  }

  private void handleMove(int pid, JSONObject m) {
    if (!RoomState.PLAYING.equals(room.phase)) {
      error(pid, "phase", "当前不是对局中");
      return;
    }
    String seatId = m.optString("seat", "");
    RoomSeat s = room.seat(seatId);
    if (s == null || s.isEmpty() || s.playerId != pid) {
      error(pid, "seat", "不是你的座位");
      return;
    }
    if (!seatId.equals(room.turnSeat)) {
      error(pid, "turn", "还没轮到这个座位");
      return;
    }
    int n = m.optInt("n", 0);
    if (n != room.moves.size() + 1) {
      error(pid, "seq", "手数不连续");
      return;
    }
    boolean pass = m.optBoolean("pass", false);
    int x = m.optInt("x", -1);
    int y = m.optInt("y", -1);
    if (!pass
        && (x < 0
            || y < 0
            || x >= featurecat.lizzie.rules.Board.boardWidth
            || y >= featurecat.lizzie.rules.Board.boardHeight)) {
      error(pid, "coord", "坐标越界");
      return;
    }
    RoomMove mv = new RoomMove(n, seatId, s.black, x, y, pass, m.optLong("ms", 0));
    room.moves.add(mv);
    if (s.black) room.blackCount++;
    else room.whiteCount++;
    room.blackToPlay = !s.black;
    boolean doublePass = room.moves.size() >= 2
        && room.moves.get(room.moves.size() - 1).pass
        && room.moves.get(room.moves.size() - 2).pass;
    if (doublePass) {
      JSONObject applied = new JSONObject();
      applied.put("t", "applied");
      applied.put("move", mv.toJson());
      applied.put("room", room.toJson(false));
      broadcast(applied);
      endGame("", "双方连续停一手，终局");
      return;
    }
    beginTurn(false);
    JSONObject applied = new JSONObject();
    applied.put("t", "applied");
    applied.put("move", mv.toJson());
    applied.put("room", room.toJson(false));
    broadcast(applied);
  }

  private void beginTurn(boolean broadcast) {
    cancelTimeout();
    room.turnSeat = room.turnSeatNow();
    room.turnDeadline = 0L;
    if (room.turnSeat.isEmpty()) {
      setPhase(RoomState.PAUSED);
      broadcastRoom();
      return;
    }
    RoomSeat s = room.seat(room.turnSeat);
    if (s == null) return;
    if (s.isHuman() && s.online && room.rules.humanSec > 0) {
      room.turnDeadline = System.currentTimeMillis() + room.rules.humanSec * 1000L;
      final String seat = room.turnSeat;
      final long deadline = room.turnDeadline;
      timeoutTask =
          new TimerTask() {
            @Override
            public void run() {
              synchronized (lock) {
                if (!RoomState.PLAYING.equals(room.phase)) return;
                if (!seat.equals(room.turnSeat)) return;
                if (room.turnDeadline != deadline) return;
                RoomSeat cur = room.seat(seat);
                if (cur == null) return;
                endGame(cur.black ? "W+T" : "B+T", cur.label() + " 超时");
              }
            }
          };
      timer.schedule(timeoutTask, Math.max(100L, deadline - System.currentTimeMillis()));
    }
    if (broadcast) broadcastRoom();
  }

  private void cancelTimeout() {
    if (timeoutTask != null) {
      timeoutTask.cancel();
      timeoutTask = null;
    }
    room.turnDeadline = 0L;
  }

  // ------------------------------------------------------------------ 认输 / 掉线

  private void handleResign(int pid, JSONObject m) {
    if (!RoomState.PLAYING.equals(room.phase) && !RoomState.PAUSED.equals(room.phase)) return;
    RoomSeat s = room.seat(m.optString("seat", ""));
    if (s == null || s.isEmpty() || s.playerId != pid) {
      error(pid, "seat", "只能认输自己的座位");
      return;
    }
    endGame(s.black ? "W+R" : "B+R", s.label() + " 认输");
  }

  private void handleSkip(int pid, JSONObject m) {
    if (room.hostId != pid) {
      error(pid, "host", "只有房主能跳过");
      return;
    }
    if (!RoomState.PAUSED.equals(room.phase)) return;
    RoomSeat s = room.seat(m.optString("seat", ""));
    if (s == null || s.isEmpty() || s.online || s.skipped) return;
    // 该方真人全掉线时，不允许跳过任何座位让 AI 继续。
    if (room.sideHasHuman(s.black) && !room.sideHasOnlineHuman(s.black)) {
      error(pid, "humans-gone", "该方真人已全部掉线，只能结束对局或继续等待");
      return;
    }
    s.skipped = true;
    s.ready = false;
    if (s.id.equals(room.turnSeat)) {
      beginTurn(false);
    }
    if (!room.hasWaitingSeat()) setPhase(RoomState.PLAYING);
    broadcastRoom();
  }

  private void handleWait(int pid, JSONObject m) {
    if (room.hostId != pid) {
      error(pid, "host", "只有房主能决定等待");
      return;
    }
    // 等待本身就是“保持 PAUSED”，不需要改状态；广播一次让各端刷新提示。
    broadcastRoom();
  }

  private void handleEndGame(int pid) {
    if (room.hostId != pid) {
      error(pid, "host", "只有房主能结束");
      return;
    }
    if (!RoomState.PAUSED.equals(room.phase)) return;
    if (!room.sideAllHumansOfflineOnly() && room.sideHasOnlineSeat(true) && room.sideHasOnlineSeat(false)) {
      error(pid, "not-allowed", "只有整方真人掉线时才能结束");
      return;
    }
    endGame("", "整方真人掉线，房主结束");
  }

  private void handleKick(int pid, JSONObject m) {
    if (room.hostId != pid) {
      error(pid, "host", "只有房主能踢人");
      return;
    }
    if (!RoomState.LOBBY.equals(room.phase)) return;
    int target = m.optInt("playerId", -1);
    if (target == pid) return;
    RoomPlayer p = room.player(target);
    if (p == null) return;
    removePlayer(target);
    WebSocket conn = playerConn.remove(target);
    if (conn != null) {
      JSONObject k = new JSONObject();
      k.put("t", "kicked");
      send(conn, k);
      try {
        conn.close();
      } catch (Exception e) {
        // ignore
      }
      connPlayer.remove(conn);
    }
    broadcastRoom();
  }

  private void handleTransferHost(int pid, JSONObject m) {
    if (room.hostId != pid) {
      error(pid, "host", "只有房主能转让房主");
      return;
    }
    if (!RoomState.LOBBY.equals(room.phase)) {
      error(pid, "phase", "开局后不能转让房主");
      return;
    }
    int target = m.optInt("playerId", -1);
    if (target == pid) return;
    RoomPlayer p = room.player(target);
    if (p == null) {
      error(pid, "player", "玩家不存在");
      return;
    }
    room.hostId = target;
    hostTransferred = true;
    for (RoomPlayer player : room.players) player.host = player.id == target;
    broadcastRoom();
  }

  private void handleClose(int pid) {
    // 客户端主动“退出房间”也走掉线逻辑：房主离开不会解散房间。
    WebSocket conn = playerConn.remove(pid);
    if (conn != null) {
      connPlayer.remove(conn);
      try {
        conn.close();
      } catch (Exception e) {
        // ignore
      }
    }
    playerGone(pid);
  }

  private void removePlayer(int pid) {
    RoomPlayer p = room.player(pid);
    if (p == null) return;
    for (RoomSeat s : room.seats)
      if (s.playerId == pid && !s.isEmpty()) s.clear();
    room.players.remove(p);
    if (room.hostId == pid) transferHost();
  }

  private void transferHost() {
    hostTransferred = true;
    List<RoomPlayer> online = new ArrayList<RoomPlayer>();
    for (RoomPlayer p : room.players) if (p.online) online.add(p);
    if (online.isEmpty()) {
      closeRoom("房间内没有在线玩家");
      return;
    }
    Collections.shuffle(online);
    RoomPlayer nh = online.get(0);
    for (RoomPlayer p : room.players) p.host = false;
    nh.host = true;
    room.hostId = nh.id;
  }

  // ------------------------------------------------------------------ 结束 / 关闭

  private void endNeutral(String reason) {
    endGame("", reason);
  }

  private void endGame(String result, String reason) {
    if (RoomState.ENDED.equals(room.phase) || RoomState.CLOSED.equals(room.phase)) return;
    cancelTimeout();
    setPhase(RoomState.ENDED);
    room.result = result == null ? "" : result;
    room.endReason = reason == null ? "" : reason;
    JSONObject o = new JSONObject();
    o.put("t", "end");
    o.put("result", room.result);
    o.put("reason", room.endReason);
    o.put("room", room.toJson(true));
    broadcast(o);
    timer.schedule(
        new TimerTask() {
          @Override
          public void run() {
            closeRoom("对局结束");
          }
        },
        8000L);
  }

  private void closeRoom(String reason) {
    if (closed) return;
    setPhase(RoomState.CLOSED);
    JSONObject o = new JSONObject();
    o.put("t", "closed");
    o.put("reason", reason == null ? "" : reason);
    broadcast(o);
    closed = true;
    closeReason = reason == null ? "" : reason;
    cancelTimeout();
    if (discovery != null) {
      discovery.stop();
      discovery = null;
    }
    timer.cancel();
    for (WebSocket conn : new ArrayList<WebSocket>(connPlayer.keySet())) {
      try {
        conn.close();
      } catch (Exception e) {
        // ignore
      }
    }
    connPlayer.clear();
    playerConn.clear();
    final String r = closeReason;
    // stop() 可能等待工作线程；放到新线程，避免在 WebSocket 回调线程里自锁。
    new Thread(
            new Runnable() {
              @Override
              public void run() {
                try {
                  stop();
                } catch (Exception e) {
                  // ignore
                }
                if (listener != null) listener.onClosed(r);
              }
            },
            "multi-room-close")
        .start();
  }

  // ------------------------------------------------------------------ 广播

  private void broadcastRoom() {
    if (RoomState.CLOSED.equals(room.phase)) return;
    JSONObject o = new JSONObject();
    o.put("t", "room");
    o.put("room", room.toJson(false));
    broadcast(o);
  }

  private void broadcast(JSONObject o) {
    String s = o.toString();
    for (WebSocket conn : new ArrayList<WebSocket>(connPlayer.keySet())) {
      try {
        conn.send(s);
      } catch (Exception e) {
        // ignore
      }
    }
    // 房主本地也刷新（即使房主客户端还没连上）
    if (listener != null) listener.onRoom(room);
  }

  private void send(WebSocket conn, JSONObject o) {
    try {
      conn.send(o.toString());
    } catch (Exception e) {
      // ignore
    }
  }

  private void error(WebSocket conn, String code, String msg) {
    JSONObject o = new JSONObject();
    o.put("t", "error");
    o.put("code", code);
    o.put("msg", msg);
    send(conn, o);
  }

  private void error(int pid, String code, String msg) {
    WebSocket conn = playerConn.get(pid);
    if (conn != null) error(conn, code, msg);
  }
}
