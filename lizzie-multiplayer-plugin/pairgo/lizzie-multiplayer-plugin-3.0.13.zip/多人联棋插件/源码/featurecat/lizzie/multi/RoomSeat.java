package featurecat.lizzie.multi;

import org.json.JSONObject;

/** 一个座位：黑①~③ / 白①~③，空 / 人类 / AI。 */
public final class RoomSeat {
  public static final String EMPTY = "empty";
  public static final String HUMAN = "human";
  public static final String AI = "ai";

  public String id = "";
  public boolean black = true;
  public int index = 0;
  public String kind = EMPTY;
  /** 人类座位：坐的人；AI 座位：提供引擎的人。 */
  public int playerId = -1;
  public String name = "";
  /** AI 座位：provider 本机的引擎索引。 */
  public int engineId = -1;
  public String engineName = "";
  /** 人类：玩家已准备；AI：引擎自检通过。 */
  public boolean ready = false;
  /** 当前是否在线（人类=客户端连接；AI=provider 连接 + 引擎）。 */
  public boolean online = true;
  /** 已被房主跳过，暂时移出轮转。 */
  public boolean skipped = false;
  /** AI 引擎自检中。 */
  public boolean checking = false;

  public RoomSeat() {}

  public RoomSeat(String id, boolean black, int index) {
    this.id = id;
    this.black = black;
    this.index = index;
  }

  public boolean isHuman() {
    return HUMAN.equals(kind);
  }

  public boolean isAi() {
    return AI.equals(kind);
  }

  public boolean isEmpty() {
    return EMPTY.equals(kind);
  }

  public String label() {
    return (black ? "黑" : "白") + "①②③".charAt(Math.max(0, Math.min(2, index)));
  }

  public String display() {
    if (isEmpty()) return "空";
    if (isHuman()) return name.isEmpty() ? "玩家" + playerId : name;
    return engineName.isEmpty() ? (name.isEmpty() ? "AI" : name) : engineName;
  }

  public JSONObject toJson() {
    JSONObject o = new JSONObject();
    o.put("id", id);
    o.put("black", black);
    o.put("index", index);
    o.put("kind", kind);
    o.put("playerId", playerId);
    o.put("name", name);
    o.put("engineId", engineId);
    o.put("engineName", engineName);
    o.put("ready", ready);
    o.put("online", online);
    o.put("skipped", skipped);
    o.put("checking", checking);
    return o;
  }

  public static RoomSeat fromJson(JSONObject o) {
    RoomSeat s = new RoomSeat();
    if (o == null) return s;
    s.id = o.optString("id", "");
    s.black = o.optBoolean("black", true);
    s.index = o.optInt("index", 0);
    s.kind = o.optString("kind", EMPTY);
    s.playerId = o.optInt("playerId", -1);
    s.name = o.optString("name", "");
    s.engineId = o.optInt("engineId", -1);
    s.engineName = o.optString("engineName", "");
    s.ready = o.optBoolean("ready", false);
    s.online = o.optBoolean("online", true);
    s.skipped = o.optBoolean("skipped", false);
    s.checking = o.optBoolean("checking", false);
    return s;
  }

  public void copyFrom(RoomSeat s) {
    kind = s.kind;
    playerId = s.playerId;
    name = s.name;
    engineId = s.engineId;
    engineName = s.engineName;
    ready = s.ready;
    online = s.online;
    skipped = s.skipped;
    checking = s.checking;
  }

  public void clear() {
    kind = EMPTY;
    playerId = -1;
    name = "";
    engineId = -1;
    engineName = "";
    ready = false;
    online = true;
    skipped = false;
    checking = false;
  }
}
