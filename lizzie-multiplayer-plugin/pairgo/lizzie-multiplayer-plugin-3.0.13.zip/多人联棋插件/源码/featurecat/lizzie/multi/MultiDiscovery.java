package featurecat.lizzie.multi;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * 局域网房间发现。
 *
 * <p>协议（UDP 45231，明文）： FIND|code -> ROOM|code|wsPort|phase|ver|uid
 * CLAIM|code|uid -> TAKEN|code|uid（同号时别的房主回）
 *
 * <p>公网版不需要它：改成连公网房间服务，4 位编号由服务端统一分配。
 */
public final class MultiDiscovery {
  public static final int PORT = 45231;
  public static final String TAG = "PAIRGO1";
  public static final int VER = 1;

  private MultiDiscovery() {}

  public static final class Found {
    public String host = "";
    public int port = 0;
    public String phase = "";
    public int ver = 0;
  }

  /** 广播找房；找不到返回 null。 */
  public static Found find(String code, int timeoutMs) {
    DatagramSocket socket = null;
    try {
      socket = new DatagramSocket();
      socket.setBroadcast(true);
      socket.setSoTimeout(Math.max(200, timeoutMs));
      byte[] data = (TAG + "|FIND|" + code).getBytes("UTF-8");
      DatagramPacket out =
          new DatagramPacket(data, data.length, InetAddress.getByName("255.255.255.255"), PORT);
      socket.send(out);
      long end = System.currentTimeMillis() + Math.max(300, timeoutMs);
      byte[] buf = new byte[1024];
      while (System.currentTimeMillis() < end) {
        DatagramPacket in = new DatagramPacket(buf, buf.length);
        try {
          socket.receive(in);
        } catch (java.net.SocketTimeoutException te) {
          break;
        }
        String s = new String(in.getData(), 0, in.getLength(), "UTF-8");
        String[] p = s.split("\\|");
        if (p.length < 6 || !TAG.equals(p[0]) || !"ROOM".equals(p[1])) continue;
        if (!code.equals(p[2])) continue;
        Found f = new Found();
        f.host = in.getAddress().getHostAddress();
        try {
          f.port = Integer.parseInt(p[3]);
        } catch (Exception e) {
          continue;
        }
        f.phase = p[4];
        try {
          f.ver = Integer.parseInt(p[5]);
        } catch (Exception e) {
          f.ver = 0;
        }
        return f;
      }
    } catch (Exception e) {
      return null;
    } finally {
      if (socket != null) socket.close();
    }
    return null;
  }

  /** 房主端：绑定 UDP 45231，回应 FIND，参与同号 CLAIM。 */
  public static final class Host {
    private final String uid = UUID.randomUUID().toString();
    private final LinkedBlockingQueue<String> taken = new LinkedBlockingQueue<String>();
    private DatagramSocket socket;
    private Thread thread;
    private volatile boolean running;
    private volatile String code = "";
    private volatile int wsPort = 0;
    private volatile String phase = RoomState.LOBBY;

    public boolean start(String code, int wsPort) {
      this.code = code;
      this.wsPort = wsPort;
      try {
        socket = new DatagramSocket(null);
        socket.setReuseAddress(true);
        socket.bind(new InetSocketAddress(PORT));
        socket.setBroadcast(true);
        socket.setSoTimeout(500);
        running = true;
        thread = new Thread(this::loop, "multi-discovery");
        thread.setDaemon(true);
        thread.start();
        return true;
      } catch (Exception e) {
        stop();
        return false;
      }
    }

    public void setPhase(String phase) {
      this.phase = phase == null ? RoomState.LOBBY : phase;
    }

    public void setCode(String code) {
      this.code = code == null ? "" : code;
    }

    /** 开房前探测同号；true 表示局域网里已有同号房间。 */
    public boolean claimCollision(String candidate, int timeoutMs) {
      DatagramSocket s = socket;
      if (s == null || !running) return false;
      taken.clear();
      try {
        byte[] data = (TAG + "|CLAIM|" + candidate + "|" + uid).getBytes("UTF-8");
        DatagramPacket out =
            new DatagramPacket(data, data.length, InetAddress.getByName("255.255.255.255"), PORT);
        s.send(out);
        String hit = taken.poll(Math.max(200, timeoutMs), TimeUnit.MILLISECONDS);
        return hit != null;
      } catch (Exception e) {
        return false;
      }
    }

    private void loop() {
      byte[] buf = new byte[1024];
      while (running) {
        try {
          DatagramPacket in = new DatagramPacket(buf, buf.length);
          socket.receive(in);
          String s = new String(in.getData(), 0, in.getLength(), "UTF-8");
          String[] p = s.split("\\|");
          if (p.length < 3 || !TAG.equals(p[0])) continue;
          if ("FIND".equals(p[1]) && code.equals(p[2])) {
            reply(
                in.getSocketAddress(),
                TAG + "|ROOM|" + code + "|" + wsPort + "|" + phase + "|" + VER + "|" + uid);
          } else if ("CLAIM".equals(p[1])) {
            if (p.length >= 4 && code.equals(p[2]) && !uid.equals(p[3])) {
              // 回显发起方的 uid，发起方据此认出“这是我的探测收到的冲突”。
              reply(in.getSocketAddress(), TAG + "|TAKEN|" + code + "|" + p[3]);
            }
          } else if ("TAKEN".equals(p[1])) {
            if (p.length >= 4 && code.equals(p[2]) && uid.equals(p[3])) taken.offer(p[2]);
          }
        } catch (java.net.SocketTimeoutException te) {
          // 正常，继续等
        } catch (Exception e) {
          if (!running) break;
        }
      }
    }

    private void reply(java.net.SocketAddress to, String text) {
      try {
        byte[] b = text.getBytes("UTF-8");
        socket.send(new DatagramPacket(b, b.length, to));
      } catch (Exception e) {
        // 忽略
      }
    }

    public void stop() {
      running = false;
      if (socket != null) {
        socket.close();
        socket = null;
      }
      if (thread != null) {
        thread.interrupt();
        thread = null;
      }
    }

    public String uid() {
      return uid;
    }
  }
}
