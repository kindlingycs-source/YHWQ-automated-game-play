package featurecat.lizzie.multi;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** 多人约战房间的完整状态。服务端与客户端共用同一份模型。 */
public final class RoomState {
  public static final String LOBBY = "LOBBY";
  public static final String PLAYING = "PLAYING";
  public static final String PAUSED = "PAUSED";
  public static final String ENDED = "ENDED";
  public static final String CLOSED = "CLOSED";

  public String code = "";
  public int hostId = 0;
  public String phase = LOBBY;
  public RoomRules rules = new RoomRules();
  public final List<RoomSeat> seats = new ArrayList<RoomSeat>();
  public final List<RoomPlayer> players = new ArrayList<RoomPlayer>();
  public final List<RoomMove> moves = new ArrayList<RoomMove>();
  public String result = "";
  public String endReason = "";
  public int nextPlayerId = 1;
  public String turnSeat = "";
  public long turnDeadline = 0L;
  public boolean blackToPlay = true;
  public int blackCount = 0;
  public int whiteCount = 0;

  public RoomState() {
    for (int i = 0; i < 3; i++) seats.add(new RoomSeat("B" + (i + 1), true, i));
    for (int i = 0; i < 3; i++) seats.add(new RoomSeat("W" + (i + 1), false, i));
  }

  public RoomSeat seat(String id) {
    if (id == null) return null;
    for (RoomSeat s : seats) if (s.id.equals(id)) return s;
    return null;
  }

  public RoomPlayer player(int id) {
    for (RoomPlayer p : players) if (p.id == id) return p;
    return null;
  }

  public RoomPlayer playerByClientId(String clientId) {
    if (clientId == null) return null;
    for (RoomPlayer p : players) if (clientId.equals(p.clientId)) return p;
    return null;
  }

  public RoomPlayer host() {
    return player(hostId);
  }

  public RoomSeat humanSeatOf(int playerId) {
    for (RoomSeat s : seats) if (s.isHuman() && s.playerId == playerId) return s;
    return null;
  }

  public List<RoomSeat> aiSeatsOf(int playerId) {
    List<RoomSeat> out = new ArrayList<RoomSeat>();
    for (RoomSeat s : seats) if (s.isAi() && s.playerId == playerId) out.add(s);
    return out;
  }

  public List<RoomSeat> activeSeats(boolean black) {
    List<RoomSeat> out = new ArrayList<RoomSeat>();
    for (RoomSeat s : seats)
      if (s.black == black && !s.isEmpty() && !s.skipped && s.online) out.add(s);
    return out;
  }

  public List<RoomSeat> humanSeats(boolean black) {
    List<RoomSeat> out = new ArrayList<RoomSeat>();
    for (RoomSeat s : seats) if (s.black == black && s.isHuman()) out.add(s);
    return out;
  }

  public int humanCount() {
    int n = 0;
    for (RoomSeat s : seats) if (s.isHuman()) n++;
    return n;
  }

  public int onlineHumanCount() {
    int n = 0;
    for (RoomSeat s : seats) if (s.isHuman() && s.online) n++;
    return n;
  }

  public boolean sideHasHuman(boolean black) {
    return !humanSeats(black).isEmpty();
  }

  public boolean sideHasOnlineHuman(boolean black) {
    for (RoomSeat s : humanSeats(black)) if (s.online) return true;
    return false;
  }

  public boolean sideHumansAllOffline(boolean black) {
    List<RoomSeat> hs = humanSeats(black);
    if (hs.isEmpty()) return false; // 一方从开局就是全 AI，不算“真人全掉线”
    for (RoomSeat s : hs) if (s.online) return false;
    return true;
  }

  public boolean sideHasOnlineSeat(boolean black) {
    for (RoomSeat s : seats)
      if (s.black == black && !s.isEmpty() && s.online && !s.skipped) return true;
    return false;
  }

  public boolean hasAllHumansOffline() {
    return humanCount() > 0 && onlineHumanCount() == 0;
  }

  public boolean allPlayersReady() {
    for (RoomPlayer p : players) if (!p.online || !p.ready) return false;
    return true;
  }

  public boolean allAiReady() {
    for (RoomSeat s : seats) {
      if (!s.isAi()) continue;
      if (!s.online || s.checking || !s.ready) return false;
    }
    return true;
  }

  public boolean allPlayersSeated() {
    for (RoomPlayer p : players) if (humanSeatOf(p.id) == null) return false;
    return true;
  }

  /** 开局条件：≥2 真人（不要求分属黑白）；每方 ≥1 非空座位；每人已坐；全部在线且准备；AI 全部自检就绪。 */
  public boolean startReady() {
    if (!LOBBY.equals(phase)) return false;
    if (humanCount() < 2) return false;
    if (!sideHasOnlineSeat(true) || !sideHasOnlineSeat(false)) return false;
    if (!allPlayersSeated()) return false;
    if (!allPlayersReady()) return false;
    if (!allAiReady()) return false;
    return true;
  }

  public boolean sideAllHumansOfflineOnly() {
    return sideHumansAllOffline(true) || sideHumansAllOffline(false);
  }

  public String turnSeatNow() {
    List<RoomSeat> list = activeSeats(blackToPlay);
    if (list.isEmpty()) return "";
    int index = (blackToPlay ? blackCount : whiteCount) % list.size();
    return list.get(index).id;
  }

  public List<RoomSeat> waitingSeats() {
    List<RoomSeat> out = new ArrayList<RoomSeat>();
    for (RoomSeat s : seats)
      if (!s.isEmpty() && !s.skipped && !s.online) out.add(s);
    return out;
  }

  public boolean hasWaitingSeat() {
    return !waitingSeats().isEmpty();
  }

  public JSONObject toJson(boolean includeMoves) {
    JSONObject o = new JSONObject();
    o.put("code", code);
    o.put("hostId", hostId);
    o.put("phase", phase);
    o.put("rules", rules.toJson());
    JSONArray sa = new JSONArray();
    for (RoomSeat s : seats) sa.put(s.toJson());
    o.put("seats", sa);
    JSONArray pa = new JSONArray();
    for (RoomPlayer p : players) pa.put(p.toJson());
    o.put("players", pa);
    if (includeMoves) {
      JSONArray ma = new JSONArray();
      for (RoomMove m : moves) ma.put(m.toJson());
      o.put("moves", ma);
    }
    o.put("result", result);
    o.put("endReason", endReason);
    o.put("nextPlayerId", nextPlayerId);
    o.put("turnSeat", turnSeat);
    o.put("turnDeadline", turnDeadline);
    o.put("blackToPlay", blackToPlay);
    o.put("blackCount", blackCount);
    o.put("whiteCount", whiteCount);
    return o;
  }

  public static RoomState fromJson(JSONObject o) {
    RoomState st = new RoomState();
    if (o == null) return st;
    st.code = o.optString("code", "");
    st.hostId = o.optInt("hostId", 0);
    st.phase = o.optString("phase", LOBBY);
    st.rules = RoomRules.fromJson(o.optJSONObject("rules"));
    JSONArray sa = o.optJSONArray("seats");
    if (sa != null) {
      for (int i = 0; i < sa.length() && i < st.seats.size(); i++) {
        RoomSeat s = RoomSeat.fromJson(sa.optJSONObject(i));
        if (s.id == null || s.id.isEmpty()) s.id = st.seats.get(i).id;
        st.seats.get(i).copyFrom(s);
      }
    }
    JSONArray pa = o.optJSONArray("players");
    if (pa != null) {
      st.players.clear();
      for (int i = 0; i < pa.length(); i++) st.players.add(RoomPlayer.fromJson(pa.optJSONObject(i)));
    }
    JSONArray ma = o.optJSONArray("moves");
    if (ma != null) {
      st.moves.clear();
      for (int i = 0; i < ma.length(); i++) st.moves.add(RoomMove.fromJson(ma.optJSONObject(i)));
    }
    st.result = o.optString("result", "");
    st.endReason = o.optString("endReason", "");
    st.nextPlayerId = o.optInt("nextPlayerId", 1);
    st.turnSeat = o.optString("turnSeat", "");
    st.turnDeadline = o.optLong("turnDeadline", 0L);
    st.blackToPlay = o.optBoolean("blackToPlay", true);
    st.blackCount = o.optInt("blackCount", 0);
    st.whiteCount = o.optInt("whiteCount", 0);
    return st;
  }

  /** 给对局者条/标题用：黑方 ①玩家1 ②KataGo ③空。 */
  public String sideLine(boolean black) {
    StringBuilder sb = new StringBuilder();
    for (RoomSeat s : seats) {
      if (s.black != black) continue;
      if (sb.length() > 0) sb.append("  ");
      sb.append(s.label().charAt(1)).append(s.display());
    }
    return sb.toString();
  }
}
