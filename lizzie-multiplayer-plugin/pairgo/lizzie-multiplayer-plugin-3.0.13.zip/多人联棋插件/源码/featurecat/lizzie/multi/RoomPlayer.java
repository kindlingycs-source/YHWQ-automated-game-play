package featurecat.lizzie.multi;

import org.json.JSONObject;

/** 房间成员。每个成员必须坐一个真人座位（准备阶段不允许纯提供者）。 */
public final class RoomPlayer {
  public int id = 0;
  public String clientId = "";
  public String name = "";
  public boolean host = false;
  public boolean online = true;
  public boolean ready = false;

  public RoomPlayer() {}

  public RoomPlayer(int id, String clientId) {
    this.id = id;
    this.clientId = clientId == null ? "" : clientId;
    this.name = "玩家" + id;
  }

  public JSONObject toJson() {
    JSONObject o = new JSONObject();
    o.put("id", id);
    o.put("name", name);
    o.put("host", host);
    o.put("online", online);
    o.put("ready", ready);
    return o;
  }

  public static RoomPlayer fromJson(JSONObject o) {
    RoomPlayer p = new RoomPlayer();
    if (o == null) return p;
    p.id = o.optInt("id", 0);
    p.name = o.optString("name", "玩家" + p.id);
    p.host = o.optBoolean("host", false);
    p.online = o.optBoolean("online", true);
    p.ready = o.optBoolean("ready", false);
    return p;
  }
}
