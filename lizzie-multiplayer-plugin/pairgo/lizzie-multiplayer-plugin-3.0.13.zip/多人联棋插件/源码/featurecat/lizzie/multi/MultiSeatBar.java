package featurecat.lizzie.multi;

import featurecat.lizzie.Lizzie;
import featurecat.lizzie.gui.LizzieFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/** 对局中的对局者条：6 个座位 + 当前轮次高亮 + 房主掉线操作。 */
public final class MultiSeatBar extends JDialog {
  private final MultiGame game;
  private final JLabel[] cells = new JLabel[6];
  private final JLabel status = new JLabel(" ");
  private final JButton pass = new JButton("停一手");
  private final JButton resign = new JButton("认输");
  private final JButton moveNum = new JButton("显示手数");
  private final JComboBox<String> offline = new JComboBox<String>();
  private final JButton skip = new JButton("跳过");
  private final JButton wait = new JButton("等待");
  private final JButton end = new JButton("结束对局");
  private RoomState last;

  public MultiSeatBar(MultiGame game) {
    super(Lizzie.frame, "多人约战 · 对局者", false);
    this.game = game;
    setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    setLayout(new BorderLayout(4, 4));
    JPanel seats = new JPanel(new GridLayout(2, 1, 2, 2));
    for (int side = 0; side < 2; side++) {
      JPanel row = new JPanel(new GridLayout(1, 3, 2, 2));
      for (int i = 0; i < 3; i++) {
        int idx = side * 3 + i;
        cells[idx] = new JLabel(" ", SwingConstants.CENTER);
        cells[idx].setOpaque(true);
        cells[idx].setBorder(BorderFactory.createEmptyBorder(3, 4, 3, 4));
        row.add(cells[idx]);
      }
      seats.add(row);
    }
    add(seats, BorderLayout.NORTH);
    add(status, BorderLayout.CENTER);

    JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
    buttons.add(pass);
    buttons.add(resign);
    buttons.add(moveNum);
    buttons.add(offline);
    buttons.add(skip);
    buttons.add(wait);
    buttons.add(end);
    add(buttons, BorderLayout.SOUTH);

    pass.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            game.sendPass();
          }
        });
    resign.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            int r =
                JOptionPane.showConfirmDialog(
                    MultiSeatBar.this, "认输会判整队负，确定？", "认输", JOptionPane.OK_CANCEL_OPTION);
            if (r == JOptionPane.OK_OPTION) game.sendResign();
          }
        });
    moveNum.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            game.cycleMoveNumbers();
          }
        });
    skip.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            String s = selectedSeat();
            if (s != null) game.hostSkip(s);
          }
        });
    wait.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            String s = selectedSeat();
            if (s != null) game.hostWait(s);
          }
        });
    end.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            int r =
                JOptionPane.showConfirmDialog(
                    MultiSeatBar.this,
                    "某一方真人已全部掉线。结束对局会记“终局”，确定？",
                    "结束对局",
                    JOptionPane.OK_CANCEL_OPTION);
            if (r == JOptionPane.OK_OPTION) game.hostEnd();
          }
        });
  }

  public void showBar() {
    setSize(780, 145);
    try {
      setLocation(Lizzie.frame.getX() + 30, Lizzie.frame.getY() + 70);
    } catch (Exception e) {
      // ignore
    }
    setVisible(true);
  }

  public void disposeBar() {
    setVisible(false);
    dispose();
  }

  private String selectedSeat() {
    String s = (String) offline.getSelectedItem();
    if (s == null) return null;
    int p = s.indexOf(' ');
    return p > 0 ? s.substring(0, p) : s;
  }

  public void refresh(RoomState room) {
    if (room == null) return;
    last = room;
    String[] ids = {"B1", "B2", "B3", "W1", "W2", "W3"};
    for (int i = 0; i < ids.length; i++) {
      RoomSeat s = room.seat(ids[i]);
      String text = cellText(room, s);
      cells[i].setText(text);
      boolean activeSeat = s != null && s.id.equals(room.turnSeat) && !s.isEmpty();
      if (activeSeat) {
        cells[i].setBackground(new Color(255, 224, 110));
        cells[i].setBorder(BorderFactory.createLineBorder(new Color(230, 140, 0), 2));
      } else if (s != null && s.isAi()) {
        cells[i].setBackground(new Color(225, 238, 255));
        cells[i].setBorder(BorderFactory.createEmptyBorder(3, 4, 3, 4));
      } else if (s != null && s.isHuman()) {
        cells[i].setBackground(new Color(240, 248, 240));
        cells[i].setBorder(BorderFactory.createEmptyBorder(3, 4, 3, 4));
      } else {
        cells[i].setBackground(new Color(240, 240, 240));
        cells[i].setBorder(BorderFactory.createEmptyBorder(3, 4, 3, 4));
      }
    }
    String st;
    if (RoomState.ENDED.equals(room.phase) || RoomState.CLOSED.equals(room.phase)) {
      st = "对局结束：" + (room.result.isEmpty() ? "终局" : room.result)
          + (room.endReason.isEmpty() ? "" : " · " + room.endReason);
    } else if (RoomState.PAUSED.equals(room.phase)) {
      List<String> off = new ArrayList<String>();
      for (RoomSeat s : room.seats) if (!s.isEmpty() && !s.online && !s.skipped) off.add(s.label() + s.display());
      st = "已暂停：等待 " + (off.isEmpty() ? "掉线玩家" : String.join("、", off)) + "（房主选跳过或等待）";
    } else {
      RoomSeat turn = room.seat(room.turnSeat);
      st = "第" + (room.moves.size() + 1) + "手 · 轮到 "
          + (turn == null ? "…" : turn.label() + turn.display())
          + "  黑方：" + room.sideLine(true) + "  白方：" + room.sideLine(false);
    }
    status.setText(st);
    pass.setEnabled(game.isMyTurn());
    resign.setEnabled(game.isMyTurn());
    boolean canHost = game.isHost() && RoomState.PAUSED.equals(room.phase);
    skip.setEnabled(canHost);
    wait.setEnabled(canHost);
    end.setEnabled(canHost);
    offline.setEnabled(canHost);
    String sel = selectedSeat();
    offline.removeAllItems();
    for (RoomSeat s : room.seats) {
      if (!s.isEmpty() && !s.online && !s.skipped) offline.addItem(s.id + " " + s.label() + s.display());
    }
    if (sel != null) {
      for (int i = 0; i < offline.getItemCount(); i++)
        if (((String) offline.getItemAt(i)).startsWith(sel + " ")) {
          offline.setSelectedIndex(i);
          break;
        }
    }
    String m =
        Lizzie.config.allowMoveNumber == 0
            ? "手数：不显示"
            : Lizzie.config.allowMoveNumber == 1 ? "手数：最后1手" : "手数：全显示";
    moveNum.setText(m);
  }

  private String cellText(RoomState room, RoomSeat s) {
    if (s == null) return " ";
    StringBuilder sb = new StringBuilder();
    if (s.id.equals(room.turnSeat) && !s.isEmpty() && !RoomState.ENDED.equals(room.phase))
      sb.append("▶ ");
    sb.append(s.label()).append(' ');
    if (s.isEmpty()) {
      sb.append("空");
    } else if (s.isHuman()) {
      sb.append(s.playerId == room.hostId ? "👑 " : "");
      sb.append(s.display());
      sb.append(s.ready ? " ✓" : "");
      if (!s.online) sb.append(s.skipped ? "（已跳过）" : "（掉线）");
    } else {
      sb.append(s.engineName.isEmpty() ? "AI" : s.engineName);
      if (s.checking) sb.append("（自检中）");
      else if (!s.online) sb.append(s.skipped ? "（已跳过）" : "（引擎掉线）");
      else if (s.id.equals(room.turnSeat) && RoomState.PLAYING.equals(room.phase)) sb.append("（思考中）");
    }
    return sb.toString();
  }
}
