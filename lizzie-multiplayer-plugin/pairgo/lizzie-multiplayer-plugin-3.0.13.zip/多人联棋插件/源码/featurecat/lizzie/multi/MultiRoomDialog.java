package featurecat.lizzie.multi;

import featurecat.lizzie.Lizzie;
import featurecat.lizzie.analysis.EngineManager;
import featurecat.lizzie.analysis.Leelaz;
import featurecat.lizzie.gui.EngineData;
import featurecat.lizzie.gui.LizzieFrame;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.OverlayLayout;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

/** 多人约战的准备窗口：开房/进房、6 个座位、规则、准备/开始/踢人。 */
public final class MultiRoomDialog extends JDialog implements MultiGame.Ui {
  private static final int JOIN_WIDTH = 520;
  private static final int JOIN_HEIGHT = 300;
  private static final int ROOM_WIDTH = 940;
  private static final int ROOM_HEIGHT = 400;
  private static final int RULES_WIDTH = 450;

  private final MultiGame game = MultiGame.INSTANCE;
  private final boolean hostMode;
  private final CardLayout cards = new CardLayout();
  private final JPanel root = new JPanel(cards);
  private final JLabel status = new JLabel(" ");
  private final JLabel codeLabel = new JLabel("房间 ----");
  private final JPanel seatPanel = new JPanel(new GridLayout(3, 2, 6, 6));
  private RoomState room;
  private boolean disposed;

  // join panel
  private final JTextField[] joinCode = new JTextField[4];
  private final JTextField joinHost = new JTextField(14);
  private final JTextField joinPort = new JTextField(6);
  private final JButton joinBtn = new JButton("进入房间");

  // room panel
  private final JTextField komi = new JTextField(5);
  private final JTextField handicap = new JTextField(3);
  private final JTextField humanSec = new JTextField(4);
  private final JTextField aiSec = new JTextField(4);
  private final JTextField aiVisits = new JTextField(7);
  private final JCheckBox aiUseVisits = new JCheckBox("按计算量");
  private final JCheckBox aiResign = new JCheckBox("允许 AI 认输");
  private final JTextField resignWinrate = new JTextField(4);
  private final JTextField resignConsec = new JTextField(3);
  private final JTextField resignMin = new JTextField(4);
  private final JComboBox<String> ruleSet = new JComboBox<String>(new String[] {"中国规则", "日本规则"});
  private final JButton applyRules = new JButton("应用规则");
  private JPanel rulesBlocker;
  private final JButton readyBtn = new JButton("准备");
  private final JButton startBtn = new JButton("开始对局");
  private final JButton exitBtn = new JButton("退出房间");

  private boolean editingRules;
  private boolean settingRuleCombo;

  public MultiRoomDialog(LizzieFrame owner, boolean hostMode) {
    super(owner, "多人约战(真人联机)", false);
    this.hostMode = hostMode;
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    setResizable(false);
    root.add(buildJoinPanel(), "join");
    root.add(buildRoomPanel(), "room");
    add(root);
    add(status, BorderLayout.SOUTH);
    if (hostMode) {
      cards.show(root, "room");
      setSize(ROOM_WIDTH, ROOM_HEIGHT);
      game.setUi(this);
      if (!game.startHost()) {
        status.setText("开房失败");
      } else {
        codeLabel.setText("房间 " + game.server().code() + "（本机端口 " + game.server().port() + "）");
      }
    } else {
      cards.show(root, "join");
      setSize(JOIN_WIDTH, JOIN_HEIGHT);
      clearJoinCode();
      SwingUtilities.invokeLater(
          new Runnable() {
            public void run() {
              joinCode[0].requestFocusInWindow();
            }
          });
    }
    setLocationRelativeTo(owner);
    joinBtn.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            doJoin();
          }
        });
    applyRules.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            applyRules();
          }
        });
    readyBtn.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            toggleReady();
          }
        });
    startBtn.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            startGame();
          }
        });
    exitBtn.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            exitRoom();
          }
        });
    addFocusGuard(komi);
    addFocusGuard(handicap);
    addFocusGuard(humanSec);
    addFocusGuard(aiSec);
    addFocusGuard(aiVisits);
    aiUseVisits.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            updateAiRuleEnabled(game.isHost());
          }
        });
    aiResign.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            updateAiRuleEnabled(game.isHost());
          }
        });
    ruleSet.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (!settingRuleCombo && game.isHost() && room != null) applyRules();
          }
        });
    updateRuleControls(hostMode);
  }

  private void addFocusGuard(final JTextField f) {
    f.addFocusListener(
        new FocusAdapter() {
          @Override
          public void focusGained(FocusEvent e) {
            editingRules = true;
          }

          @Override
          public void focusLost(FocusEvent e) {
            editingRules = false;
          }
        });
  }

  private JPanel buildJoinPanel() {
    JPanel p = new JPanel(new BorderLayout(8, 8));
    p.setBorder(BorderFactory.createEmptyBorder(14, 18, 10, 18));
    JPanel top = new JPanel(new BorderLayout(0, 4));
    JLabel title = new JLabel("进入多人约战房间");
    title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
    top.add(title, BorderLayout.NORTH);
    JLabel hint =
        new JLabel(
            "<html>先只填 4 位房间号，局域网会自动找房；<br>"
                + "找不到时，再填下面的主机地址和端口。</html>");
    hint.setFont(hint.getFont().deriveFont(12f));
    hint.setForeground(new Color(100, 100, 100));
    top.add(hint, BorderLayout.CENTER);
    p.add(top, BorderLayout.NORTH);
    JPanel form = new JPanel(new BorderLayout(0, 12));
    JPanel codeLine = new JPanel(new GridLayout(1, 2, 10, 0));
    codeLine.add(new JLabel("4 位房间号："));
    JPanel codeRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
    for (int i = 0; i < joinCode.length; i++) {
      joinCode[i] = createCodeField(i);
      codeRow.add(joinCode[i]);
    }
    codeLine.add(codeRow);
    form.add(codeLine, BorderLayout.NORTH);

    // 主机地址 / 端口是备用通道：字号和输入框都做小，平时不抢眼。
    JPanel advanced = new JPanel(new GridLayout(2, 2, 10, 6));
    JLabel hostLabel = new JLabel("主机地址：");
    hostLabel.setFont(hostLabel.getFont().deriveFont(11f));
    hostLabel.setForeground(new Color(110, 110, 110));
    joinHost.setColumns(12);
    joinHost.setFont(joinHost.getFont().deriveFont(11f));
    joinHost.setToolTipText("局域网内一般不用填；自动找不到房间时填房主 IP 或主机名");
    JPanel hostWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
    hostWrap.add(joinHost);
    advanced.add(hostLabel);
    advanced.add(hostWrap);

    JLabel portLabel = new JLabel("端口：");
    portLabel.setFont(portLabel.getFont().deriveFont(11f));
    portLabel.setForeground(new Color(110, 110, 110));
    joinPort.setColumns(5);
    joinPort.setFont(joinPort.getFont().deriveFont(11f));
    joinPort.setToolTipText("配合主机地址使用；留空则自动发现");
    JPanel portWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
    portWrap.add(joinPort);
    advanced.add(portLabel);
    advanced.add(portWrap);
    form.add(advanced, BorderLayout.CENTER);
    p.add(form, BorderLayout.CENTER);
    JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
    bottom.add(joinBtn);
    p.add(bottom, BorderLayout.SOUTH);
    return p;
  }

  /** 验证码式 4 格房间号：一格一个数字，非数字没有反应，输入后自动跳下一格。 */
  private JTextField createCodeField(final int index) {
    final Dimension square = new Dimension(44, 44);
    final JTextField f =
        new JTextField() {
          @Override
          public Dimension getPreferredSize() {
            return square;
          }

          @Override
          public Dimension getMinimumSize() {
            return square;
          }

          @Override
          public Dimension getMaximumSize() {
            return square;
          }
        };
    f.setHorizontalAlignment(SwingConstants.CENTER);
    f.setFont(f.getFont().deriveFont(Font.BOLD, 20f));
    f.setPreferredSize(square);
    f.setMinimumSize(square);
    f.setMaximumSize(square);
    ((AbstractDocument) f.getDocument())
        .setDocumentFilter(
            new DocumentFilter() {
              private void setDigits(FilterBypass fb, String text, AttributeSet attr)
                  throws BadLocationException {
                if (text == null) return;
                if (text.isEmpty()) {
                  fb.replace(0, fb.getDocument().getLength(), "", attr);
                  return;
                }
                String digits = text.replaceAll("\\D", "");
                if (digits.isEmpty()) return; // 非数字：直接忽略
                String keep = digits.substring(0, 1);
                fb.replace(0, fb.getDocument().getLength(), keep, attr);
                SwingUtilities.invokeLater(
                    new Runnable() {
                      public void run() {
                        focusAfterCodeInput(index);
                      }
                    });
              }

              @Override
              public void insertString(
                  FilterBypass fb, int offset, String text, AttributeSet attr)
                  throws BadLocationException {
                setDigits(fb, text, attr);
              }

              @Override
              public void replace(
                  FilterBypass fb, int offset, int length, String text, AttributeSet attr)
                  throws BadLocationException {
                setDigits(fb, text, attr);
              }
            });
    f.addKeyListener(
        new KeyAdapter() {
          @Override
          public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE
                && f.getText().isEmpty()
                && index > 0) {
              joinCode[index - 1].setText("");
              joinCode[index - 1].requestFocusInWindow();
              e.consume();
            } else if (e.getKeyCode() == KeyEvent.VK_LEFT && index > 0) {
              joinCode[index - 1].requestFocusInWindow();
              e.consume();
            } else if (e.getKeyCode() == KeyEvent.VK_RIGHT && index < joinCode.length - 1) {
              joinCode[index + 1].requestFocusInWindow();
              e.consume();
            } else if (e.getKeyCode() == KeyEvent.VK_ENTER) {
              doJoin();
            }
          }
        });
    f.addFocusListener(
        new FocusAdapter() {
          @Override
          public void focusGained(FocusEvent e) {
            SwingUtilities.invokeLater(
                new Runnable() {
                  public void run() {
                    f.selectAll();
                  }
                });
          }
        });
    return f;
  }

  private void focusAfterCodeInput(int index) {
    if (index < joinCode.length - 1) {
      joinCode[index + 1].requestFocusInWindow();
      joinCode[index + 1].selectAll();
    }
  }

  private String joinCodeText() {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < joinCode.length; i++) {
      sb.append(joinCode[i] == null ? "" : joinCode[i].getText().trim());
    }
    return sb.toString();
  }

  private void clearJoinCode() {
    for (int i = 0; i < joinCode.length; i++) if (joinCode[i] != null) joinCode[i].setText("");
  }

  private void focusFirstEmptyCode() {
    for (int i = 0; i < joinCode.length; i++) {
      if (joinCode[i].getText().trim().isEmpty()) {
        joinCode[i].requestFocusInWindow();
        return;
      }
    }
    joinCode[joinCode.length - 1].requestFocusInWindow();
  }

  private JPanel buildRoomPanel() {
    JPanel p = new JPanel(new BorderLayout(6, 4));
    p.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
    JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
    codeLabel.setFont(codeLabel.getFont().deriveFont(Font.BOLD, 18f));
    top.add(codeLabel);
    JButton copy = new JButton("复制房间号");
    copy.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            if (room != null) {
              java.awt.Toolkit.getDefaultToolkit()
                  .getSystemClipboard()
                  .setContents(new java.awt.datatransfer.StringSelection(room.code), null);
              status.setText("房间号已复制");
            }
          }
        });
    top.add(copy);
    p.add(top, BorderLayout.NORTH);

    seatPanel.setBorder(BorderFactory.createTitledBorder("座位（黑方在左 / 白方在右，点击座位操作）"));
    JPanel center = new JPanel(new BorderLayout(8, 4));
    // 座位和规则都按自身高度靠上摆，不随窗口纵向拉伸，避免每个框又高又空。
    JPanel seatHolder = new JPanel(new BorderLayout());
    seatHolder.add(seatPanel, BorderLayout.NORTH);
    center.add(seatHolder, BorderLayout.CENTER);
    JPanel rulesHolder = new JPanel(new BorderLayout());
    rulesHolder.add(buildRulesPanel(), BorderLayout.NORTH);
    center.add(rulesHolder, BorderLayout.EAST);
    p.add(center, BorderLayout.CENTER);

    JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 2));
    exitBtn.setToolTipText("退出后房主会自动转让；房间里没有人时才关闭房间");
    bottom.add(readyBtn);
    bottom.add(startBtn);
    bottom.add(exitBtn);
    p.add(bottom, BorderLayout.SOUTH);
    return p;
  }

  private JPanel buildRulesPanel() {
    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
    p.setBorder(
        BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("房间规则（房主设置）"),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)));
    addRuleRow(p, new JLabel("贴目"), komi, new JLabel("让子(0/2-9)"), handicap);
    addRuleRow(p, new JLabel("每手秒"), humanSec, new JLabel("AI 秒/手"), aiSec);
    addRuleRow(p, new JLabel("AI 计算量"), aiVisits, aiUseVisits, new JLabel(""));
    addRuleRow(p, new JLabel("AI 认输"), aiResign, new JLabel("胜率<%"), resignWinrate);
    addRuleRow(p, new JLabel("连续手"), resignConsec, new JLabel("手数≥"), resignMin);
    addRuleRow(p, new JLabel("规则"), ruleSet, new JLabel(""), applyRules);
    p.add(Box.createVerticalGlue());
    JScrollPane sp = new JScrollPane(p);
    sp.setBorder(BorderFactory.createEmptyBorder());
    sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
    sp.getVerticalScrollBar().setUnitIncrement(16);
    sp.setPreferredSize(new Dimension(RULES_WIDTH, 236));
    JPanel view = new JPanel(new BorderLayout());
    view.add(sp, BorderLayout.CENTER);
    view.setPreferredSize(new Dimension(RULES_WIDTH, 236));
    rulesBlocker = new JPanel();
    rulesBlocker.setOpaque(false);
    rulesBlocker.setVisible(false);
    rulesBlocker.addMouseListener(
        new MouseAdapter() {
          @Override
          public void mousePressed(MouseEvent e) {
            e.consume();
          }

          @Override
          public void mouseReleased(MouseEvent e) {
            e.consume();
          }
        });
    JPanel wrap = new JPanel();
    wrap.setLayout(new OverlayLayout(wrap));
    wrap.add(view);
    wrap.add(rulesBlocker);
    wrap.setComponentZOrder(rulesBlocker, 0);
    wrap.setPreferredSize(new Dimension(RULES_WIDTH, 236));
    return wrap;
  }

  /** 一行 4 列；行高压到 27 像素，输入框随之变细长，不再被 GridLayout 拉高。 */
  private void addRuleRow(JPanel parent, Component... items) {
    JPanel row = new JPanel(new GridLayout(1, 4, 6, 0));
    for (int i = 0; i < items.length; i++) row.add(items[i]);
    row.setAlignmentX(Component.LEFT_ALIGNMENT);
    row.setPreferredSize(new Dimension(RULES_WIDTH - 30, 27));
    row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 27));
    parent.add(row);
    parent.add(Box.createRigidArea(new Dimension(0, 5)));
  }

  private void doJoin() {
    String code = joinCodeText();
    if (!code.matches("\\d{4}")) {
      status.setText("请填满 4 位房间号");
      focusFirstEmptyCode();
      return;
    }
    String host = joinHost.getText().trim();
    String portText = joinPort.getText().trim();
    game.setUi(this);
    if (!host.isEmpty() && !portText.isEmpty()) {
      try {
        game.join(host, Integer.parseInt(portText), code);
        showRoomCard();
      } catch (Exception e) {
        status.setText("端口不合法");
      }
      return;
    }
    status.setText("正在局域网内找房间…");
    final String fcode = code;
    new Thread(
            new Runnable() {
              public void run() {
                final MultiDiscovery.Found f = MultiDiscovery.find(fcode, 1600);
                SwingUtilities.invokeLater(
                    new Runnable() {
                      public void run() {
                        if (f == null) {
                          status.setText("没找到房间：检查是否同一局域网，或填主机地址+端口");
                          return;
                        }
                        game.join(f.host, f.port, fcode);
                        showRoomCard();
                      }
                    });
              }
            },
            "multi-discovery-join")
        .start();
  }

  /** 进房成功后，窗口从“进房小框”切到“房间准备大框”。 */
  private void showRoomCard() {
    cards.show(root, "room");
    setSize(ROOM_WIDTH, ROOM_HEIGHT);
    setLocationRelativeTo(getOwner());
    validate();
    repaint();
  }

  private void startGame() {
    if (room == null || game.client() == null || !game.isHost()) return;
    int humans = room.humanCount();
    if (humans < 2 || humans > 6) {
      JOptionPane.showMessageDialog(
          this,
          "人数不合法，必须2到6人才能开局。",
          "多人约战(真人联机)",
          JOptionPane.WARNING_MESSAGE);
      return;
    }
    if (!room.startReady()) {
      status.setText("还不能开始：请确认每人已坐好、准备，且 AI 已通过自检");
      return;
    }
    game.client().sendStart();
  }

  private void applyRules() {
    if (room == null || game.client() == null || !game.isHost()) return;
    RoomRules r = readRules();
    game.client().sendRules(r);
    status.setText("规则已下发");
  }

  private RoomRules readRules() {
    RoomRules r = new RoomRules();
    r.komi = parseDouble(komi.getText(), 7.5);
    r.handicap = parseInt(handicap.getText(), 0);
    r.humanSec = parseInt(humanSec.getText(), 30);
    r.aiSec = parseInt(aiSec.getText(), 3);
    r.aiVisits = parseInt(aiVisits.getText(), 10000);
    r.aiUseVisits = aiUseVisits.isSelected();
    r.aiResign = aiResign.isSelected();
    r.aiResignWinrate = parseDouble(resignWinrate.getText(), 3.0);
    r.aiResignConsec = parseInt(resignConsec.getText(), 3);
    r.aiResignMinMove = parseInt(resignMin.getText(), 100);
    r.ruleSet = ruleSet.getSelectedIndex() == 1 ? "japanese" : "chinese";
    r.sanitize();
    return r;
  }

  private static int parseInt(String s, int def) {
    try {
      int v = Integer.parseInt(s.trim());
      return v;
    } catch (Exception e) {
      return def;
    }
  }

  private static double parseDouble(String s, double def) {
    try {
      return Double.parseDouble(s.trim());
    } catch (Exception e) {
      return def;
    }
  }

  private void toggleReady() {
    if (room == null || game.client() == null) return;
    RoomPlayer me = room.player(game.myPlayerId());
    boolean ready = me == null || !me.ready;
    game.client().sendReady(ready);
  }

  private void exitRoom() {
    // 退出不是解散：房主离开后由服务端随机转让；只有全员离开/掉线才关房。
    if (game.client() != null) game.client().sendLeaveRoom();
    game.leaveRoom();
    dispose();
  }

  // ------------------------------------------------------------------ Ui

  @Override
  public void refresh(RoomState st) {
    if (disposed) return;
    room = st;
    if (RoomState.LOBBY.equals(st.phase)) {
      cards.show(root, "room");
    } else {
      // 开局后由对局者条接管；准备窗口自动收起
      dispose();
      return;
    }
    RoomPlayer host = st.host();
    codeLabel.setText(
        "房间 " + st.code + (host == null ? "" : "（房主 " + host.name + "）"));
    if (!editingRules) {
      komi.setText(String.valueOf(st.rules.komi));
      handicap.setText(String.valueOf(st.rules.handicap));
      humanSec.setText(String.valueOf(st.rules.humanSec));
      aiSec.setText(String.valueOf(st.rules.aiSec));
      aiVisits.setText(String.valueOf(st.rules.aiVisits));
      aiUseVisits.setSelected(st.rules.aiUseVisits);
      aiResign.setSelected(st.rules.aiResign);
      resignWinrate.setText(String.valueOf(st.rules.aiResignWinrate));
      resignConsec.setText(String.valueOf(st.rules.aiResignConsec));
      resignMin.setText(String.valueOf(st.rules.aiResignMinMove));
      settingRuleCombo = true;
      ruleSet.setSelectedIndex("japanese".equals(st.rules.ruleSet) ? 1 : 0);
      settingRuleCombo = false;
    }
    boolean editable = game.isHost();
    updateRuleControls(editable);

    rebuildSeats(st);
    RoomPlayer me = st.player(game.myPlayerId());
    readyBtn.setEnabled(me != null && st.humanSeatOf(game.myPlayerId()) != null);
    readyBtn.setText(me != null && me.ready ? "取消准备" : "准备");
    startBtn.setEnabled(game.isHost());
    startBtn.setVisible(game.isHost());
    String s =
        "玩家："
            + st.players.size()
            + " · 真人："
            + st.humanCount()
            + " · 状态："
            + (st.startReady() ? "可以开始" : "等待准备/自检");
    status.setText(s);
  }

  /**
   * 非房主：控件保持正常颜色，用透明遮罩挡住鼠标；输入框额外设为不可编辑，避免键盘输入。
   * 房主：去掉遮罩，全部可编辑。
   */
  private void updateRuleControls(boolean editable) {
    if (rulesBlocker != null) rulesBlocker.setVisible(!editable);
    setRuleField(komi, editable);
    setRuleField(handicap, editable);
    setRuleField(humanSec, editable);
    setRuleField(aiSec, editable);
    aiUseVisits.setEnabled(true);
    aiUseVisits.setFocusable(editable);
    aiResign.setEnabled(true);
    aiResign.setFocusable(editable);
    ruleSet.setEnabled(true);
    ruleSet.setFocusable(editable);
    applyRules.setEnabled(true);
    applyRules.setFocusable(editable);
    updateAiRuleEnabled(editable);
  }

  private void setRuleField(JTextField f, boolean editable) {
    f.setEditable(editable);
    f.setEnabled(true);
    f.setFocusable(editable);
    f.setBackground(java.awt.Color.WHITE);
  }

  /** 两个 AI 勾选项关掉时，对应的计算量 / 认输阈值输入框一起置灰。 */
  private void updateAiRuleEnabled(boolean hostEditable) {
    boolean visitsOn = aiUseVisits.isSelected();
    boolean resignOn = aiResign.isSelected();
    setAiField(aiVisits, visitsOn, hostEditable);
    setAiField(resignWinrate, resignOn, hostEditable);
    setAiField(resignConsec, resignOn, hostEditable);
    setAiField(resignMin, resignOn, hostEditable);
  }

  private void setAiField(JTextField f, boolean optionOn, boolean hostEditable) {
    f.setEnabled(optionOn);
    f.setEditable(hostEditable && optionOn);
    f.setFocusable(hostEditable && optionOn);
  }

  private void rebuildSeats(RoomState st) {
    seatPanel.removeAll();
    // 3 行 × 2 列：黑① 白① / 黑② 白② / 黑③ 白③
    for (int i = 0; i < 3; i++) {
      for (int side = 0; side < 2; side++) {
        String id = (side == 0 ? "B" : "W") + (i + 1);
        RoomSeat s = st.seat(id);
        JButton b = new JButton(cellHtml(st, s));
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setVerticalAlignment(SwingConstants.TOP);
        b.setBackground(
            s != null && s.id.equals(st.turnSeat)
                ? new Color(255, 235, 150)
                : new Color(245, 245, 245));
        b.setOpaque(true);
        b.setPreferredSize(new Dimension(190, 72));
        SeatAction action = new SeatAction(st, s, b);
        b.addActionListener(action);
        b.addMouseListener(action);
        seatPanel.add(b);
      }
    }
    seatPanel.revalidate();
    seatPanel.repaint();
  }

  private String cellHtml(RoomState st, RoomSeat s) {
    if (s == null) return " ";
    String head = "<html><b>" + s.label() + "</b>";
    if (s.isEmpty()) return head + "<br>空</html>";
    if (s.isHuman()) {
      String host = s.playerId == st.hostId ? " ★房主" : "";
      String ready = s.ready ? " ✓已准备" : "";
      String off = !s.online ? "（掉线）" : "";
      return head + "<br>" + s.display() + host + ready + off + "</html>";
    }
    String status = s.checking ? "（自检中）" : !s.online ? "（引擎掉线）" : s.ready ? " ✓就绪" : "";
    return head + "<br>" + (s.engineName.isEmpty() ? "AI" : s.engineName) + status + "</html>";
  }

  private final class SeatAction extends MouseAdapter implements ActionListener {
    private final RoomState st;
    private final RoomSeat seat;
    private final JButton button;
    private Point clickPoint;

    SeatAction(RoomState st, RoomSeat seat, JButton button) {
      this.st = st;
      this.seat = seat;
      this.button = button;
    }

    @Override
    public void mousePressed(MouseEvent e) {
      clickPoint = e.getPoint();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
      if (seat == null) return;
      // 自己已坐的座位不弹任何说明；换座直接点空位。
      if (seat.isHuman() && seat.playerId == game.myPlayerId()) return;
      javax.swing.JPopupMenu m = new javax.swing.JPopupMenu();
      final String id = seat.id;
      if (seat.isEmpty()) {
        javax.swing.JMenuItem sit = new javax.swing.JMenuItem("坐到这里");
        sit.addActionListener(
            new ActionListener() {
              public void actionPerformed(ActionEvent ae) {
                if (game.client() != null) game.client().sendSit(id);
              }
            });
        m.add(sit);
        javax.swing.JMenuItem add = new javax.swing.JMenuItem("加 AI 引擎…");
        add.addActionListener(
            new ActionListener() {
              public void actionPerformed(ActionEvent ae) {
                addAi(id);
              }
            });
        m.add(add);
      } else if (seat.isHuman() && game.isHost()) {
        javax.swing.JMenuItem transfer = new javax.swing.JMenuItem("转让房主给 " + seat.display());
        transfer.addActionListener(
            new ActionListener() {
              public void actionPerformed(ActionEvent ae) {
                if (game.client() != null) game.client().sendTransferHost(seat.playerId);
              }
            });
        m.add(transfer);
        javax.swing.JMenuItem kick = new javax.swing.JMenuItem("踢出 " + seat.display());
        kick.addActionListener(
            new ActionListener() {
              public void actionPerformed(ActionEvent ae) {
                if (game.client() != null) game.client().sendKick(seat.playerId);
              }
            });
        m.add(kick);
      } else if (seat.isAi() && seat.playerId == game.myPlayerId()) {
        javax.swing.JMenuItem rm = new javax.swing.JMenuItem("移除这个 AI");
        rm.addActionListener(
            new ActionListener() {
              public void actionPerformed(ActionEvent ae) {
                if (game.client() != null) game.client().sendRemoveAi(id);
              }
            });
        m.add(rm);
        javax.swing.JMenuItem mv = new javax.swing.JMenuItem("移动到空位…");
        mv.addActionListener(
            new ActionListener() {
              public void actionPerformed(ActionEvent ae) {
                moveAi(id);
              }
            });
        m.add(mv);
      }
      if (m.getComponentCount() == 0) {
        javax.swing.JMenuItem none = new javax.swing.JMenuItem("这个座位由其他玩家管理");
        none.setEnabled(false);
        m.add(none);
      }
      Dimension pref = m.getPreferredSize();
      Point at = clickPoint;
      if (at == null) at = new Point(button.getWidth() / 2, button.getHeight());
      // 选项框底线正中间对准鼠标。
      m.show(button, at.x - Math.max(1, pref.width) / 2, at.y - Math.max(1, pref.height));
      if (System.getProperty("multi.debug") != null) {
        System.out.println(
            "[multi-ui] popup at="
                + at
                + " pref="
                + pref
                + " size="
                + m.getSize()
                + " loc="
                + m.getLocationOnScreen());
      }
    }
  }

  private void addAi(String seatId) {
    List<Leelaz> engines = Lizzie.engineManager == null ? null : Lizzie.engineManager.engineList;
    if (engines == null || engines.isEmpty()) {
      status.setText("没有配置引擎：先在 Lizzie 里配置一个引擎");
      return;
    }
    ArrayList<EngineData> engineData = featurecat.lizzie.util.Utils.getEngineData();
    String[] names = new String[engines.size()];
    int maxTextWidth = 220;
    FontMetrics fm = getFontMetrics(getFont());
    for (int i = 0; i < engines.size(); i++) {
      Leelaz e = engines.get(i);
      String n = null;
      if (engineData != null && i < engineData.size()) n = engineData.get(i).name;
      if (n == null || n.trim().isEmpty()) n = e.oriEnginename;
      if (n == null || n.trim().isEmpty()) n = "未命名引擎";
      names[i] = n;
      maxTextWidth = Math.max(maxTextWidth, fm.stringWidth(n) + 40);
    }
    final JList<String> list = new JList<String>(names);
    list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    list.setSelectedIndex(0);
    list.setFixedCellWidth(maxTextWidth);
    list.setFixedCellHeight(24);
    list.setVisibleRowCount(Math.min(names.length, 12));
    JScrollPane listScroll = new JScrollPane(list);
    listScroll.setBorder(BorderFactory.createEmptyBorder());
    listScroll.setPreferredSize(
        new Dimension(maxTextWidth + 24, Math.min(names.length, 12) * 24 + 4));
    int pick =
        JOptionPane.showConfirmDialog(
            this,
            listScroll,
            "选择 AI 引擎",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE);
    if (pick != JOptionPane.OK_OPTION) return;
    int idx = list.getSelectedIndex();
    if (idx < 0) return;
    int main = EngineManager.currentEngineNo;
    if (main < 0 && Lizzie.leelaz != null && Lizzie.engineManager.engineList != null) {
      main = Lizzie.engineManager.engineList.indexOf(Lizzie.leelaz);
    }
    if (idx == main || engines.get(idx) == Lizzie.leelaz) {
      status.setText("当前分析引擎不能当 AI 座位；请先在 Lizzie 里配置第二台引擎");
      return;
    }
    if (room != null && idx >= 0) {
      for (RoomSeat s : room.seats) {
        if (s.isAi() && s.playerId == game.myPlayerId() && s.engineId == idx) {
          JOptionPane.showMessageDialog(
              this,
              "不能添加相同引擎进行对局",
              "多人约战(真人联机)",
              JOptionPane.WARNING_MESSAGE);
          return;
        }
      }
    }
    game.client().sendAddAi(seatId, idx, Lizzie.engineManager.getEngineName(idx));
  }

  private void moveAi(String from) {
    if (room == null) return;
    List<String> empty = new ArrayList<String>();
    for (RoomSeat s : room.seats) if (s.isEmpty()) empty.add(s.id);
    if (empty.isEmpty()) {
      status.setText("没有空位");
      return;
    }
    Object sel = JOptionPane.showInputDialog(this, "移动到", "移动 AI", JOptionPane.QUESTION_MESSAGE, null, empty.toArray(), empty.get(0));
    if (sel == null) return;
    game.client().sendMoveAi(from, String.valueOf(sel));
  }

  @Override
  public void status(String text) {
    status.setText(text);
  }

  @Override
  public void error(String text) {
    status.setText(text);
  }

  @Override
  public void closed(String reason) {
    if (disposed) return;
    status.setText("房间已关闭：" + reason);
    readyBtn.setEnabled(false);
    startBtn.setEnabled(false);
    // 让用户看到原因，再关窗
    javax.swing.Timer t =
        new javax.swing.Timer(
            2500,
            new ActionListener() {
              public void actionPerformed(ActionEvent e) {
                dispose();
              }
            });
    t.setRepeats(false);
    t.start();
  }

  @Override
  public void dispose() {
    disposed = true;
    game.setUi(null);
    super.dispose();
  }
}
