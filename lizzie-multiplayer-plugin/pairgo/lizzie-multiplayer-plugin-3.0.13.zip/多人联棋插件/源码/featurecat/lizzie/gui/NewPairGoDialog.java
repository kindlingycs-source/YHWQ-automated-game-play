package featurecat.lizzie.gui;

import featurecat.lizzie.Lizzie;
import featurecat.lizzie.analysis.PairGo;
import featurecat.lizzie.util.Utils;
import org.json.JSONArray;
import org.json.JSONObject;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/** 联棋自定义房间: 黑白各 1~2 个座位，每位可选空/人类(限时)/AI(引擎+时间+认输) */
public class NewPairGoDialog extends JDialog {
  // 记住上一局的设置，下次打开联棋房间时沿用。
  private static final int[][] lastType = new int[2][2];
  private static final int[][] lastEngine = new int[2][2];
  private static final String[][] lastMain = new String[2][2];
  private static final String[][] lastByo = new String[2][2];
  private static final String[][] lastByoCount = new String[2][2];
  private static final String[][] lastHumanTime = new String[2][2];
  private static final String[][] lastAiTime = new String[2][2];
  private static final String[][] lastAiMode = new String[2][2];
  private static final String[][] lastAiVisits = new String[2][2];
  private static final String[][] lastResignMove = new String[2][2];
  private static final String[][] lastResignConsec = new String[2][2];
  private static final String[][] lastResignRate = new String[2][2];
  private static final boolean[][] lastLimit = new boolean[2][2];
  private static final String[][] lastEngineName = new String[2][2];
  private static String lastKomi = "7.5";
  private static String lastHandicap = "0";
  private static boolean lastPure = false;
  private static boolean lastContinue = false;
  private static int lastMode = 0;
  private static String lastProbBlack = "50";
  private static String lastProbWhite = "50";
  private static boolean hasLast = false;

  private final String[] sideNames = {"黑方", "白方"};
  private final String[] slotNames = {"①", "②"};

  private final JFontComboBox[][] cboType = new JFontComboBox[2][2];
  private final JFontComboBox[][] cboEngine = new JFontComboBox[2][2];
  private final JFontCheckBox[][] chkLimit = new JFontCheckBox[2][2];
  private final JFontTextField[][] txtHumanTime = new JFontTextField[2][2];
  private final JFontTextField[][] txtMain = new JFontTextField[2][2];
  private final JFontTextField[][] txtByo = new JFontTextField[2][2];
  private final JFontTextField[][] txtByoCount = new JFontTextField[2][2];
  private final JFontRadioButton[][] rdoAiTime = new JFontRadioButton[2][2];
  private final JFontRadioButton[][] rdoAiVisits = new JFontRadioButton[2][2];
  private final ButtonGroup[][] aiModeGroup = new ButtonGroup[2][2];
  private final JFontTextField[][] txtAiTime = new JFontTextField[2][2];
  private final JFontTextField[][] txtAiVisits = new JFontTextField[2][2];
  private final JFontTextField[][] txtResignMove = new JFontTextField[2][2];
  private final JFontTextField[][] txtResignConsec = new JFontTextField[2][2];
  private final JFontTextField[][] txtResignRate = new JFontTextField[2][2];
  private final JPanel[][] humanRow = new JPanel[2][2];
  private final JPanel[][] aiRow1 = new JPanel[2][2];
  private final JPanel[][] aiRow2 = new JPanel[2][2];
  private final JPanel[][] engineRow = new JPanel[2][2];

  private final ArrayList<ArrayList<Integer>> itemEngine = new ArrayList<ArrayList<Integer>>();
  private final ArrayList<ArrayList<String>> itemName = new ArrayList<ArrayList<String>>();

  private JFontTextField txtKomi;
  private JFontTextField txtHandicap;
  private JFontCheckBox chkContinue;
  private JFontCheckBox chkPure;
  private JFontRadioButton rdoSeq;
  private JFontRadioButton rdoProb;
  private JFontTextField txtProbBlack;
  private JFontTextField txtProbWhite;
  private JFontLabel lblProbBlack;
  private JFontLabel lblProbWhite;
  private boolean cancelled = true;

  public NewPairGoDialog(Window owner) {
    super(owner);
    if (!hasLast) loadPersisted();
    setModal(true);
    setTitle("联棋房间（黑白各 1~2 位）");
    setAlwaysOnTop(Lizzie.frame != null && Lizzie.frame.isAlwaysOnTop());
    setResizable(false);

    JPanel content = new JPanel(new BorderLayout(0, 6));


    ArrayList<EngineData> data = Utils.getEngineData();
    JPanel grid = new JPanel(new GridLayout(1, 2, 10, 0));
    for (int side = 0; side < 2; side++) {
      JPanel col = new JPanel(new BorderLayout(0, 4));
      JFontLabel head = new JFontLabel(sideNames[side]);
      head.setHorizontalAlignment(JFontLabel.CENTER);
      col.add(head, BorderLayout.NORTH);
      JPanel slots = new JPanel(new GridLayout(2, 1, 0, 6));
      for (int slot = 0; slot < 2; slot++) {
        slots.add(buildSlot(side, slot, data));
      }
      col.add(slots, BorderLayout.CENTER);
      grid.add(col);
    }
    content.add(grid, BorderLayout.CENTER);

    JPanel global = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
    global.add(new JFontLabel("贴目"));
    txtKomi = new JFontTextField(hasLast ? lastKomi : "7.5");
    txtKomi.setColumns(4);
    global.add(txtKomi);
    global.add(new JFontLabel("让子(仅19路)"));
    txtHandicap = new JFontTextField(hasLast ? lastHandicap : "0");
    txtHandicap.setColumns(3);
    global.add(txtHandicap);
    chkContinue = new JFontCheckBox("当前局面续弈");
    global.add(chkContinue);
    chkPure = new JFontCheckBox("纯净对弈(只显示时间)");
    if (hasLast) {
      chkPure.setSelected(lastPure);
      chkContinue.setSelected(lastContinue);
    }
    global.add(chkPure);

    JPanel modeRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
    modeRow.add(new JFontLabel("联棋模式"));
    rdoSeq = new JFontRadioButton("顺序联棋");
    rdoProb = new JFontRadioButton("概率联棋");
    ButtonGroup modeGroup = new ButtonGroup();
    modeGroup.add(rdoSeq);
    modeGroup.add(rdoProb);
    if (lastMode == PairGo.MODE_PROBABILITY) rdoProb.setSelected(true);
    else rdoSeq.setSelected(true);
    rdoSeq.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            refreshProb();
          }
        });
    rdoProb.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            refreshProb();
          }
        });
    modeRow.add(rdoSeq);
    modeRow.add(rdoProb);
    modeRow.add(new JFontLabel("黑①概率"));
    txtProbBlack = new JFontTextField(lastProbBlack);
    txtProbBlack.setColumns(3);
    modeRow.add(txtProbBlack);
    modeRow.add(new JFontLabel("%"));
    lblProbBlack = new JFontLabel("");
    modeRow.add(lblProbBlack);
    modeRow.add(new JFontLabel("白①概率"));
    txtProbWhite = new JFontTextField(lastProbWhite);
    txtProbWhite.setColumns(3);
    modeRow.add(txtProbWhite);
    modeRow.add(new JFontLabel("%"));
    lblProbWhite = new JFontLabel("");
    modeRow.add(lblProbWhite);
    DocumentListener probListener =
        new DocumentListener() {
          public void insertUpdate(DocumentEvent e) {
            refreshProb();
          }

          public void removeUpdate(DocumentEvent e) {
            refreshProb();
          }

          public void changedUpdate(DocumentEvent e) {
            refreshProb();
          }
        };
    txtProbBlack.getDocument().addDocumentListener(probListener);
    txtProbWhite.getDocument().addDocumentListener(probListener);
    for (int s = 0; s < 2; s++)
      for (int k = 0; k < 2; k++) cboType[s][k].addActionListener(e -> refreshProb());
    refreshProb();

    JPanel buttons = new JPanel();
    JFontButton ok = new JFontButton("开始对局");
    JFontButton cancel = new JFontButton("取消");
    ok.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            confirmStart();
          }
        });
    cancel.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            cancelled = true;
            setVisible(false);
          }
        });
    buttons.add(ok);
    buttons.add(cancel);

    JPanel topRows = new JPanel(new GridLayout(2, 1, 0, 2));
    topRows.add(modeRow);
    topRows.add(global);
    JPanel south = new JPanel(new BorderLayout());
    south.add(topRows, BorderLayout.NORTH);
    south.add(buttons, BorderLayout.SOUTH);
    content.add(south, BorderLayout.SOUTH);

    setContentPane(content);
    pack();
    setLocationRelativeTo(owner);
    getRootPane().setDefaultButton(ok);
  }

  private JPanel buildSlot(final int side, final int slot, ArrayList<EngineData> data) {
    JPanel box = new JPanel();
    box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
    box.setBorder(
        BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(140, 140, 140)),
            sideNames[side] + slotNames[slot]));

    // 类型
    JPanel typeRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 1));
    JFontComboBox type = new JFontComboBox();
    type.addItem("空");
    type.addItem("人类");
    type.addItem("AI");
    type.setSelectedIndex(
        hasLast
            ? Math.max(0, Math.min(2, lastType[side][slot]))
            : (side == 0 && slot == 0 ? 1 : (side == 1 && slot == 0 ? 1 : 0)));
    cboType[side][slot] = type;
    typeRow.add(type);
    box.add(typeRow);

    // 引擎(仅AI)
    JPanel engRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 1));
    engRow.add(new JFontLabel("引擎"));
    JFontComboBox eng = new JFontComboBox();
    ArrayList<Integer> map = new ArrayList<Integer>();
    ArrayList<String> names = new ArrayList<String>();
    map.add(-1);
    names.add("");
    eng.addItem("");
    for (int k = 0; k < data.size(); k++) {
      EngineData d = data.get(k);
      String cmd = d.commands == null ? "" : d.commands;
      String nm = d.name == null ? "" : d.name;
      if (cmd.contains("分割线") || nm.contains("分割线") || nm.trim().isEmpty()) continue;
      eng.addItem("[" + (k + 1) + "] " + nm);
      map.add(k);
      names.add(nm);
    }
    cboEngine[side][slot] = eng;
    itemEngine.add(map);
    itemName.add(names);
    int wantEngine = hasLast ? lastEngine[side][slot] : 1;
    if (hasLast
        && lastEngineName[side][slot] != null
        && !lastEngineName[side][slot].isEmpty()) {
      int found = names.indexOf(lastEngineName[side][slot]);
      if (found > 0) wantEngine = found;
    }
    if (eng.getItemCount() > 1)
      eng.setSelectedIndex(Math.max(1, Math.min(eng.getItemCount() - 1, wantEngine)));
    eng.setPreferredSize(new Dimension(250, 22));
    engRow.add(eng);
    engineRow[side][slot] = engRow;
    box.add(engRow);

    // 人类: 每手限时（与 AI 的每手时间同一格式）
    JPanel hr = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 1));
    hr.add(new JFontLabel("每手"));
    txtHumanTime[side][slot] =
        new JFontTextField(hasLast ? nz(lastHumanTime[side][slot], "30") : "30");
    txtHumanTime[side][slot].setColumns(4);
    hr.add(txtHumanTime[side][slot]);
    hr.add(new JFontLabel("秒  超时判负"));
    humanRow[side][slot] = hr;
    box.add(hr);

    // AI: 每手时间 / 计算量（二选一）
    JPanel ar1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 1));
    rdoAiTime[side][slot] = new JFontRadioButton("按时间");
    rdoAiVisits[side][slot] = new JFontRadioButton("按计算量");
    aiModeGroup[side][slot] = new ButtonGroup();
    aiModeGroup[side][slot].add(rdoAiTime[side][slot]);
    aiModeGroup[side][slot].add(rdoAiVisits[side][slot]);
    ar1.add(rdoAiTime[side][slot]);
    txtAiTime[side][slot] = new JFontTextField(hasLast ? nz(lastAiTime[side][slot], "3") : "3");
    txtAiTime[side][slot].setColumns(3);
    ar1.add(txtAiTime[side][slot]);
    ar1.add(new JFontLabel("秒/手"));
    ar1.add(rdoAiVisits[side][slot]);
    String visitsText = hasLast ? nz(lastAiVisits[side][slot], "10000") : "10000";
    try {
      if (Integer.parseInt(visitsText.trim()) <= 0) visitsText = "10000";
    } catch (Exception ex) {
      visitsText = "10000";
    }
    txtAiVisits[side][slot] = new JFontTextField(visitsText);
    txtAiVisits[side][slot].setColumns(6);
    ar1.add(txtAiVisits[side][slot]);
    aiRow1[side][slot] = ar1;
    box.add(ar1);
    String mode = hasLast ? lastAiMode[side][slot] : "time";
    if ("visits".equals(mode)) rdoAiVisits[side][slot].setSelected(true);
    else rdoAiTime[side][slot].setSelected(true);
    ActionListener modeListener = e -> refreshAiMode(side, slot);
    rdoAiTime[side][slot].addActionListener(modeListener);
    rdoAiVisits[side][slot].addActionListener(modeListener);
    refreshAiMode(side, slot);

    // AI: 认输条件
    JPanel ar2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 1));
    ar2.add(new JFontLabel("认输: 手数≥"));
    txtResignMove[side][slot] = new JFontTextField(hasLast ? nz(lastResignMove[side][slot], "0") : "0");
    txtResignMove[side][slot].setColumns(4);
    ar2.add(txtResignMove[side][slot]);
    ar2.add(new JFontLabel("连续"));
    txtResignConsec[side][slot] = new JFontTextField(hasLast ? nz(lastResignConsec[side][slot], "3") : "3");
    txtResignConsec[side][slot].setColumns(2);
    ar2.add(txtResignConsec[side][slot]);
    ar2.add(new JFontLabel("手 胜率<"));
    txtResignRate[side][slot] = new JFontTextField(hasLast ? nz(lastResignRate[side][slot], "5") : "5");
    txtResignRate[side][slot].setColumns(4);
    ar2.add(txtResignRate[side][slot]);
    ar2.add(new JFontLabel("%"));
    aiRow2[side][slot] = ar2;
    box.add(ar2);

    type.addActionListener(
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            refreshSlot(side, slot);
            pack();
          }
        });
    refreshSlot(side, slot);
    return box;
  }

  /** 概率输入：只接受 1~99；其它一律 50（不弹错，静默回落）。 */
  private static int clampProb(int value) {
    return value < 1 || value > 99 ? 50 : value;
  }

  /** 该方实际有几个座位（0=空位不算）。 */
  private int sideSeatCount(int side) {
    int count = 0;
    for (int slot = 0; slot < 2; slot++) {
      if (cboType[side][slot] != null && cboType[side][slot].getSelectedIndex() != 0) count++;
    }
    return count;
  }

  /**
   * 概率只对“同一方有两个座位”才有意义。
   * 一方只有 1 个座位时，那一位固定 100%，输入框置灰、提示写清楚。
   */
  private static String probHint(int seatCount, int value) {
    if (seatCount <= 0) return "（无座位）";
    if (seatCount == 1) return "（仅 1 座，固定 100%）";
    int v = clampProb(value);
    return "（② " + (100 - v) + "%）";
  }

  private boolean settingProb;

  private void refreshProb() {
    if (settingProb) return;
    boolean prob = rdoProb != null && rdoProb.isSelected();
    int blackCount = sideSeatCount(0);
    int whiteCount = sideSeatCount(1);
    settingProb = true;
    try {
      applyProbField(txtProbBlack, blackCount, prob);
      applyProbField(txtProbWhite, whiteCount, prob);
    } finally {
      settingProb = false;
    }
    if (lblProbBlack != null) {
      lblProbBlack.setText(prob ? probHint(blackCount, parseInt(txtProbBlack, 50)) : "");
    }
    if (lblProbWhite != null) {
      lblProbWhite.setText(prob ? probHint(whiteCount, parseInt(txtProbWhite, 50)) : "");
    }
  }

  /** 单座一方固定 100%；从单座恢复到双座时把自动填的 100 还原成默认 50。 */
  private void applyProbField(final JFontTextField field, int seatCount, boolean probMode) {
    if (field == null) return;
    if (seatCount >= 2) {
      field.setEnabled(probMode);
      if ("100".equals(field.getText().trim())) setProbText(field, "50");
    } else {
      field.setEnabled(false);
      if (!"100".equals(field.getText().trim())) setProbText(field, "100");
    }
  }

  /**
   * 改文本框必须推迟到当前输入事件之后：如果 refreshProb 是在 DocumentListener 回调里触发的，
   * 直接 setText 会抛 “Attempt to mutate in notification”。
   */
  private void setProbText(final JFontTextField field, final String value) {
    SwingUtilities.invokeLater(
        () -> {
          if (settingProb) return;
          settingProb = true;
          try {
            field.setText(value);
          } finally {
            settingProb = false;
          }
          refreshProb();
        });
  }

  private void refreshAiMode(int side, int slot) {
    boolean useTime = rdoAiTime[side][slot] == null || rdoAiTime[side][slot].isSelected();
    if (txtAiTime[side][slot] != null) txtAiTime[side][slot].setEnabled(useTime);
    if (txtAiVisits[side][slot] != null) txtAiVisits[side][slot].setEnabled(!useTime);
  }

  private void refreshSlot(int side, int slot) {
    int t = cboType[side][slot].getSelectedIndex(); // 0空 1人类 2AI
    boolean human = t == 1;
    boolean ai = t == 2;
    engineRow[side][slot].setVisible(ai);
    humanRow[side][slot].setVisible(human);
    aiRow1[side][slot].setVisible(ai);
    aiRow2[side][slot].setVisible(ai);
  }

  public boolean isCancelled() {
    return cancelled;
  }

  private static String nz(String value, String def) {
    return value == null || value.trim().isEmpty() ? def : value;
  }

  private void remember() {
    for (int side = 0; side < 2; side++)
      for (int slot = 0; slot < 2; slot++) {
        lastType[side][slot] = cboType[side][slot].getSelectedIndex();
        int item = cboEngine[side][slot].getSelectedIndex();
        lastEngine[side][slot] = item;
        ArrayList<String> names = itemName.get(side * 2 + slot);
        lastEngineName[side][slot] =
            item >= 0 && item < names.size() ? names.get(item) : "";
        lastHumanTime[side][slot] = txtHumanTime[side][slot].getText();
        lastAiTime[side][slot] = txtAiTime[side][slot].getText();
        lastAiVisits[side][slot] = txtAiVisits[side][slot].getText();
        lastAiMode[side][slot] = rdoAiVisits[side][slot].isSelected() ? "visits" : "time";
        lastResignMove[side][slot] = txtResignMove[side][slot].getText();
        lastResignConsec[side][slot] = txtResignConsec[side][slot].getText();
        lastResignRate[side][slot] = txtResignRate[side][slot].getText();
      }
    lastKomi = txtKomi.getText();
    lastHandicap = txtHandicap.getText();
    lastPure = chkPure.isSelected();
    lastContinue = chkContinue.isSelected();
    lastMode = rdoProb.isSelected() ? PairGo.MODE_PROBABILITY : PairGo.MODE_SEQUENCE;
    lastProbBlack = txtProbBlack.getText();
    lastProbWhite = txtProbWhite.getText();
    hasLast = true;
    savePersisted();
  }

  /** 关闭程序后仍沿用上一局的联棋房间配置（写入 persist 配置文件）。 */
  private void savePersisted() {
    try {
      if (Lizzie.config == null || Lizzie.config.persisted == null) return;
      JSONObject room = new JSONObject();
      room.put("komi", lastKomi);
      room.put("handicap", lastHandicap);
      room.put("pure", lastPure);
      room.put("continue", lastContinue);
      room.put("mode", lastMode);
      room.put("probBlack", lastProbBlack);
      room.put("probWhite", lastProbWhite);
      room.put("black", sideJson(0));
      room.put("white", sideJson(1));
      Lizzie.config.persisted.put("pairgo-room", room);
      Lizzie.config.persist();
    } catch (Exception e) {
      // 配置写不进去不影响开局
    }
  }

  private JSONArray sideJson(int side) {
    JSONArray arr = new JSONArray();
    for (int slot = 0; slot < 2; slot++) {
      JSONObject o = new JSONObject();
      o.put("type", lastType[side][slot]);
      o.put("engineItem", lastEngine[side][slot]);
      o.put(
          "engine",
          lastEngineName[side][slot] == null ? "" : lastEngineName[side][slot]);
      o.put(
          "humanTime",
          lastHumanTime[side][slot] == null ? "30" : lastHumanTime[side][slot]);
      o.put("aiTime", lastAiTime[side][slot] == null ? "3" : lastAiTime[side][slot]);
      o.put("aiVisits", lastAiVisits[side][slot] == null ? "10000" : lastAiVisits[side][slot]);
      o.put(
          "aiMode",
          lastAiMode[side][slot] == null ? "time" : lastAiMode[side][slot]);
      o.put(
          "resignMove",
          lastResignMove[side][slot] == null ? "0" : lastResignMove[side][slot]);
      o.put(
          "resignConsec",
          lastResignConsec[side][slot] == null ? "3" : lastResignConsec[side][slot]);
      o.put(
          "resignRate",
          lastResignRate[side][slot] == null ? "5" : lastResignRate[side][slot]);
      o.put("limit", lastLimit[side][slot]);
      arr.put(o);
    }
    return arr;
  }

  /** 启动时恢复上一局的房间配置；没有记录就保持默认值。 */
  private void loadPersisted() {    try {
      if (Lizzie.config == null || Lizzie.config.persisted == null) return;
      JSONObject room = Lizzie.config.persisted.optJSONObject("pairgo-room");
      if (room == null) return;
      lastKomi = room.optString("komi", "7.5");
      lastHandicap = room.optString("handicap", "0");
      lastPure = room.optBoolean("pure", false);
      lastContinue = room.optBoolean("continue", false);
      lastMode = room.optInt("mode", 0);
      lastProbBlack = room.optString("probBlack", "50");
      lastProbWhite = room.optString("probWhite", "50");
      readSide(room.optJSONArray("black"), 0);
      readSide(room.optJSONArray("white"), 1);
      hasLast = true;
    } catch (Exception e) {
      // 配置损坏时退回默认值
    }
  }

  private void readSide(JSONArray arr, int side) {
    if (arr == null) return;
    for (int slot = 0; slot < 2 && slot < arr.length(); slot++) {
      JSONObject o = arr.optJSONObject(slot);
      if (o == null) continue;
      lastType[side][slot] = o.optInt("type", side == 0 && slot == 0 ? 1 : 0);
      lastEngine[side][slot] = o.optInt("engineItem", 1);
      lastEngineName[side][slot] = o.optString("engine", "");
      lastHumanTime[side][slot] = o.optString("humanTime", "30");
      lastAiTime[side][slot] = o.optString("aiTime", "3");
      lastAiVisits[side][slot] = o.optString("aiVisits", "10000");
      try {
        if (Integer.parseInt(lastAiVisits[side][slot].trim()) <= 0) {
          lastAiVisits[side][slot] = "10000";
        }
      } catch (Exception ex) {
        lastAiVisits[side][slot] = "10000";
      }
      lastAiMode[side][slot] = o.optString("aiMode", "");
      lastResignMove[side][slot] = o.optString("resignMove", "0");
      lastResignConsec[side][slot] = o.optString("resignConsec", "3");
      lastResignRate[side][slot] = o.optString("resignRate", "5");
      lastLimit[side][slot] = o.optBoolean("limit", false);
    }
  }

  private int parseInt(JFontTextField f, int def) {
    try {
      return Integer.parseInt(f.getText().trim());
    } catch (Exception e) {
      return def;
    }
  }

  private double parseDouble(JFontTextField f, double def) {
    try {
      return Double.parseDouble(f.getText().trim());
    } catch (Exception e) {
      return def;
    }
  }

  private void confirmStart() {
    List<PairGo.Seat> black = new ArrayList<PairGo.Seat>();
    List<PairGo.Seat> white = new ArrayList<PairGo.Seat>();
    List<Integer> used = new ArrayList<Integer>();
    for (int side = 0; side < 2; side++) {
      for (int slot = 0; slot < 2; slot++) {
        int t = cboType[side][slot].getSelectedIndex();
        if (t == 0) continue;
        PairGo.Seat s = new PairGo.Seat();
        if (t == 2) {
          int item = cboEngine[side][slot].getSelectedIndex();
          int idx = item >= 0 ? itemEngine.get(side * 2 + slot).get(item) : -1;
          if (idx < 0) {
            JOptionPane.showMessageDialog(
                this, sideNames[side] + slotNames[slot] + " 选了 AI，但没有选引擎。");
            return;
          }
          if (used.contains(idx)) {
            JOptionPane.showMessageDialog(this, "同一个引擎不能同时占两个座位。");
            return;
          }
          used.add(idx);
          s.isAi = true;
          s.engineIndex = idx;
          s.name = itemName.get(side * 2 + slot).get(item);
          s.aiUseVisits = rdoAiVisits[side][slot].isSelected();
          if (s.aiUseVisits) {
            s.aiVisits = parseInt(txtAiVisits[side][slot], 10000);
            if (s.aiVisits <= 0) s.aiVisits = 10000;
            s.aiTimeSec = 3;
          } else {
            s.aiTimeSec = parseInt(txtAiTime[side][slot], 3);
            if (s.aiTimeSec <= 0) s.aiTimeSec = 3;
            s.aiVisits = 0;
          }
          s.resignMinMove = parseInt(txtResignMove[side][slot], 0);
          if (s.resignMinMove < 0) s.resignMinMove = 0;
          s.resignConsec = parseInt(txtResignConsec[side][slot], 3);
          if (s.resignConsec <= 0) s.resignConsec = 3;
          s.resignWinrate = parseDouble(txtResignRate[side][slot], 5);
          if (!Double.isFinite(s.resignWinrate)) s.resignWinrate = 5;
          if (s.resignWinrate < 0) s.resignWinrate = 0;
          if (s.resignWinrate > 100) s.resignWinrate = 100;
        } else {
          s.isAi = false;
          s.name = "人类";
          s.timeLimit = true;
          s.humanTimeSec = parseInt(txtHumanTime[side][slot], 30);
          if (s.humanTimeSec <= 0) s.humanTimeSec = 30;
        }
        if (side == 0) black.add(s);
        else white.add(s);
      }
    }
    if (black.isEmpty() || white.isEmpty()) {
      JOptionPane.showMessageDialog(this, "黑白双方各至少要有 1 位。");
      return;
    }
    if (Lizzie.board.getHistory().getMoveNumber() > 0 && !chkContinue.isSelected()) {
      int r =
          JOptionPane.showConfirmDialog(
              this, "开始联棋将清空当前棋盘，是否继续？", "联棋对弈", JOptionPane.OK_CANCEL_OPTION);
      if (r != JOptionPane.OK_OPTION) return;
    }
    try {
      double komi = Double.parseDouble(txtKomi.getText().trim());
      if (!Double.isFinite(komi)) throw new IllegalArgumentException();
      Lizzie.board.getHistory().getGameInfo().setKomi(komi);
    } catch (Exception e) {
      JOptionPane.showMessageDialog(this, "贴目必须是有效数字。");
      return;
    }
    remember();
    cancelled = false;
    setVisible(false);
    featurecat.lizzie.analysis.PairGo.pureMode = chkPure.isSelected();
    int handicap = parseInt(txtHandicap, 0);
    if (handicap > 9) handicap = 9;
    int gameMode = rdoProb.isSelected() ? PairGo.MODE_PROBABILITY : PairGo.MODE_SEQUENCE;
    int probBlack = clampProb(parseInt(txtProbBlack, 50));
    int probWhite = clampProb(parseInt(txtProbWhite, 50));
    // 一方只有 1 个座位时概率没有意义，统一按默认值传（运行时该座位固定 100%）。
    if (black.size() < 2) probBlack = 50;
    if (white.size() < 2) probWhite = 50;
    PairGo.start(
        black, white, handicap, chkContinue.isSelected(), gameMode, probBlack, probWhite, 0L);
  }

  /** 自测钩子：-Dpairgo.dialogtest=write 写入配置，read 在下一个进程里读回并核对。 */
  private static boolean dialogTestStarted;

  public static void maybeRunDialogTest() {
    final String mode = System.getProperty("pairgo.dialogtest", "");
    if (mode.isEmpty()) return;
    synchronized (NewPairGoDialog.class) {
      if (dialogTestStarted) return;
      dialogTestStarted = true;
    }
    final String out = System.getProperty("pairgo.dialogtest.out", "pairgo-dialogtest.txt");
    final String shot = System.getProperty("pairgo.dialogtest.shot", "");
    // 等主窗口建好再测：对话框要拿它当 owner，persist() 也要读界面状态。
    javax.swing.Timer boot =
        new javax.swing.Timer(7000, e -> {
          ((javax.swing.Timer) e.getSource()).stop();
          SwingUtilities.invokeLater(
              () -> {
          try {
            final NewPairGoDialog d = new NewPairGoDialog(Lizzie.frame);
            if ("write".equals(mode)) {
              d.cboType[1][1].setSelectedIndex(2);
              if (d.cboEngine[1][1].getItemCount() > 2) d.cboEngine[1][1].setSelectedIndex(2);
              d.txtAiTime[1][1].setText("7");
              d.txtKomi.setText("6.5");
              d.chkPure.setSelected(true);
              d.rdoProb.setSelected(true);
              d.txtProbBlack.setText("90");
              d.txtProbWhite.setText("35");
              d.refreshProb();
              d.remember();
            }
            if (!shot.isEmpty() && "write".equals(mode)) {
              d.setLocationRelativeTo(Lizzie.frame);
              javax.swing.Timer shotTimer =
                  new javax.swing.Timer(
                      1500,
                      ev -> {
                        ((javax.swing.Timer) ev.getSource()).stop();
                        try {
                          java.awt.image.BufferedImage img =
                              new java.awt.image.BufferedImage(
                                  Math.max(1, d.getWidth()),
                                  Math.max(1, d.getHeight()),
                                  java.awt.image.BufferedImage.TYPE_INT_ARGB);
                          java.awt.Graphics2D gg = img.createGraphics();
                          d.paint(gg);
                          gg.dispose();
                          javax.imageio.ImageIO.write(img, "png", new java.io.File(shot));
                        } catch (Exception ex) {
                          // 截图失败不影响配置校验
                        }
                        d.setVisible(false);
                        d.dispose();
                        writeDialogTest(d, mode, out);
                        System.exit(0);
                      });
              shotTimer.setRepeats(false);
              shotTimer.start();
              d.setVisible(true);
              return;
            }
            d.dispose();
            writeDialogTest(d, mode, out);
            System.exit(0);
              } catch (Throwable t) {
                t.printStackTrace();
                System.exit(3);
              }
              });
        });
    boot.setRepeats(false);
    boot.start();
  }

  private static void writeDialogTest(NewPairGoDialog d, String mode, String out) {
    try {
      java.io.PrintWriter pw = new java.io.PrintWriter(new java.io.FileWriter(out, false), true);
      pw.println("mode=" + mode);
      pw.println("b1type=" + d.cboType[0][0].getSelectedIndex());
      pw.println("w1type=" + d.cboType[1][0].getSelectedIndex());
      pw.println("w2type=" + d.cboType[1][1].getSelectedIndex());
      pw.println("w2engine=" + d.cboEngine[1][1].getSelectedIndex());
      pw.println("w2aiTime=" + d.txtAiTime[1][1].getText());
      pw.println("komi=" + d.txtKomi.getText());
      pw.println("pure=" + d.chkPure.isSelected());
      pw.println("gameMode=" + (d.rdoProb.isSelected() ? "prob" : "seq"));
      pw.println("probBlack=" + d.txtProbBlack.getText());
      pw.println("probWhite=" + d.txtProbWhite.getText());
      pw.println("hasLast=" + hasLast);
      pw.println(
          "persisted="
              + (Lizzie.config != null
                  && Lizzie.config.persisted != null
                  && Lizzie.config.persisted.optJSONObject("pairgo-room") != null));
      pw.close();
    } catch (Exception e) {
      // 结果写不出来不影响进程退出
    }
  }
}
