﻿param(
    [string]$Dir = "",
    [switch]$Quiet
)
# ============================================================
#  多人联棋插件自动更新
#  读取同目录「更新地址.txt」里的 version.json：
#    { "version": "1.0.0",
#      "downloadUrl": ".../lizzie-multiplayer-plugin.zip",
#      "updateLog": "更新说明" }
#  downloadUrl 可以是 zip（里面任意位置放 pairgo-plugin.jar）或单个 jar。
#  只在版本变化时更新；旧 jar 自动备份，保留最近 3 份。
# ============================================================
if (-not $Dir) { $Dir = $PSScriptRoot }
$log = Join-Path $Dir 'pairgo-update.log'
function Log($m) {
    try { Add-Content -LiteralPath $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $m) -Encoding UTF8 } catch {}
}
function Say($m) { if (-not $Quiet) { Write-Host $m } }

# 版本比较：a < b 返回 $true；解析失败则按“不同就算新版本”
function IsOlder($a, $b) {
    $pa = @($a -split '[^0-9]+' | Where-Object { $_ -ne '' })
    $pb = @($b -split '[^0-9]+' | Where-Object { $_ -ne '' })
    if ($pa.Count -eq 0 -or $pb.Count -eq 0) { return $true }
    $n = [Math]::Max($pa.Count, $pb.Count)
    for ($i = 0; $i -lt $n; $i++) {
        $x = if ($i -lt $pa.Count) { [int]$pa[$i] } else { 0 }
        $y = if ($i -lt $pb.Count) { [int]$pb[$i] } else { 0 }
        if ($x -lt $y) { return $true }
        if ($x -gt $y) { return $false }
    }
    return $false
}

$cfg = Join-Path $Dir '更新地址.txt'
if (-not (Test-Path -LiteralPath $cfg)) { Say '没有「更新地址.txt」，跳过自动更新。'; exit 0 }
$url = ''
foreach ($line in (Get-Content -LiteralPath $cfg -Encoding UTF8)) {
    $t = $line.Trim()
    if ($t -and -not $t.StartsWith('#')) { $url = $t; break }
}
if (-not $url -or $url -notmatch '^https?://') { Say '更新地址为空或格式不对，跳过自动更新。'; exit 0 }

$verFile = Join-Path $Dir 'plugin-version.txt'
$local = '0.0'
if (Test-Path -LiteralPath $verFile) { $local = (Get-Content -LiteralPath $verFile -TotalCount 1).Trim() }
if (-not $local) { $local = '0.0' }

try {
    # 按 UTF-8 读取 JSON：Gitee/静态托管不一定带 charset，Invoke-RestMethod 可能把中文解成乱码。
    $resp = Invoke-WebRequest -Uri $url -TimeoutSec 8 -UseBasicParsing
    $jsonText = [System.Text.Encoding]::UTF8.GetString($resp.RawContentStream.ToArray())
    $meta = $jsonText | ConvertFrom-Json
} catch {
    Say ('检查更新失败（网络或地址不可用）：' + $_.Exception.Message)
    Log ('check failed: ' + $_.Exception.Message)
    exit 0
}
if (-not $meta -or -not $meta.version) { Say 'version.json 内容不完整，跳过。'; exit 0 }

$remote = [string]$meta.version
if ($remote -eq $local) { Say ('已是最新版本：' + $local); exit 0 }
if (-not (IsOlder $local $remote)) {
    Say ('本地版本 ' + $local + ' 不低于线上 ' + $remote + '，跳过。')
    exit 0
}
Say ('发现新版本 ' + $remote + '（当前 ' + $local + '），开始更新…')
if ($meta.updateLog) { Say ('更新说明：' + $meta.updateLog) }
Log ('update ' + $local + ' -> ' + $remote + ' ' + [string]$meta.updateLog)

$dl = ''
if ($meta.downloadUrl) { $dl = [string]$meta.downloadUrl }
elseif ($meta.url) { $dl = [string]$meta.url }
if (-not $dl) { Say 'version.json 里没有 downloadUrl，跳过。'; exit 0 }

$tmpZip = Join-Path $Dir 'pairgo-download.zip'
try {
    Invoke-WebRequest -Uri $dl -OutFile $tmpZip -TimeoutSec 180 -UseBasicParsing
} catch {
    Say ('下载新版本失败：' + $_.Exception.Message)
    Log ('download failed: ' + $_.Exception.Message)
    Remove-Item -LiteralPath $tmpZip -Force -ErrorAction SilentlyContinue
    exit 1
}

# 判断下载到的是 zip 还是单个 jar
$isZip = $false
try {
    $fs = [System.IO.File]::OpenRead($tmpZip)
    $b1 = $fs.ReadByte(); $b2 = $fs.ReadByte()
    $fs.Close()
    if ($b1 -eq 0x50 -and $b2 -eq 0x4B) { $isZip = $true }
} catch {}

$newJar = Join-Path $Dir 'pairgo-plugin.jar.new'
Remove-Item -LiteralPath $newJar -Force -ErrorAction SilentlyContinue
if ($isZip) {
    $tmpDir = Join-Path $Dir 'pairgo-download-tmp'
    Remove-Item -LiteralPath $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
    try {
        Expand-Archive -LiteralPath $tmpZip -DestinationPath $tmpDir -Force
    } catch {
        Say ('解压更新包失败：' + $_.Exception.Message)
        Log ('unzip failed: ' + $_.Exception.Message)
        exit 1
    }
    $found = Get-ChildItem -LiteralPath $tmpDir -Recurse -Filter 'pairgo-plugin.jar' -File | Select-Object -First 1
    if (-not $found) {
        Say '更新包里没找到 pairgo-plugin.jar，已放弃。'
        Log 'no jar in zip'
        Remove-Item -LiteralPath $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $tmpZip -Force -ErrorAction SilentlyContinue
        exit 1
    }
    Move-Item -LiteralPath $found.FullName -Destination $newJar -Force
    Remove-Item -LiteralPath $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
} else {
    Move-Item -LiteralPath $tmpZip -Destination $newJar -Force
}
Remove-Item -LiteralPath $tmpZip -Force -ErrorAction SilentlyContinue

# 基本校验：必须是一个含联棋类的 jar
try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $z = [System.IO.Compression.ZipFile]::OpenRead($newJar)
    $ok = ($z.Entries | Where-Object { $_.FullName -eq 'featurecat/lizzie/analysis/PairGo.class' }).Count -gt 0
    $z.Dispose()
    if (-not $ok) { throw '缺少 PairGo.class' }
} catch {
    Say ('新版本校验失败：' + $_.Exception.Message)
    Log ('verify failed: ' + $_.Exception.Message)
    Remove-Item -LiteralPath $newJar -Force -ErrorAction SilentlyContinue
    exit 1
}

if ($meta.md5) {
    $md5 = (Get-FileHash -LiteralPath $newJar -Algorithm MD5).Hash
    if ($md5 -ne ([string]$meta.md5).ToUpper()) {
        Say '下载文件校验失败（MD5 不一致），已放弃。'
        Log ('md5 mismatch got=' + $md5 + ' want=' + $meta.md5)
        Remove-Item -LiteralPath $newJar -Force -ErrorAction SilentlyContinue
        exit 1
    }
}

$jar = Join-Path $Dir 'pairgo-plugin.jar'
if (Test-Path -LiteralPath $jar) {
    try {
        $bak = $jar + '.bak-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
        Move-Item -LiteralPath $jar -Destination $bak -Force
        Log ('backup ' + $bak)
        Get-ChildItem -LiteralPath $Dir -Filter 'pairgo-plugin.jar.bak-*' |
            Sort-Object LastWriteTime -Descending |
            Select-Object -Skip 3 |
            Remove-Item -Force -ErrorAction SilentlyContinue
    } catch {
        Say ('旧版本被占用，无法替换：' + $_.Exception.Message)
        Log ('replace failed: ' + $_.Exception.Message)
        Remove-Item -LiteralPath $newJar -Force -ErrorAction SilentlyContinue
        exit 1
    }
}
Move-Item -LiteralPath $newJar -Destination $jar -Force
Set-Content -LiteralPath $verFile -Value $remote -Encoding ASCII
Say ('更新完成：' + $remote)
Log ('updated to ' + $remote)
exit 0
